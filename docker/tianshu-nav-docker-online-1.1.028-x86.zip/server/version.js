/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';






















function parseVer(v) {
  return String(v == null ? '' : v).replace(/^v/i, '').split('.').map((s) => {
    const n = parseInt(s, 10);
    return Number.isFinite(n) ? n : 0;
  });
}

// a > b 返回 1；a < b 返回 -1；相等返回 0
function compareVer(a, b) {
  const pa = parseVer(a);
  const pb = parseVer(b);
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const x = pa[i] || 0;
    const y = pb[i] || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

function isGreater(a, b) { return compareVer(a, b) > 0; }
function isSame(a, b) { return compareVer(a, b) === 0; }

// 正式版判定：规格书规定正式发布版为 v1.0.0，测试版（< 1.0.0）不写版本日志
function isFormalVersion(v) { return compareVer(v, '1.0.0') >= 0; }

module.exports = { parseVer, compareVer, isGreater, isSame, isFormalVersion };
