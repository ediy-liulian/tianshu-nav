#!/bin/bash
# 天枢导航 docker 离线部署（arm 架构，v1.00.009）
set -e
IMG="tianshu-nav:runtime"
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /var/lib/tianshu-nav-instance
docker load -i "$DIR/tianshu-nav-image-arm.tar"
cd "$DIR" && docker compose up -d
echo "启动完成：http://<IP>:16080  默认账号 admin，首次登录请修改默认密码"
echo "覆盖安装/升级保留数据；卸载清空数据、重装即全新（卸载前如需保留数据请先备份）"
