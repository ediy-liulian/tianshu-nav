/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 迁移 006：R133-B5（审计 B-5）已撤销 token 持久化
//
// 事故背景：revokedTokens 此前是**进程内 Map**，服务一重启就清空 ⇒ 攻击者拿到的旧 token
// 在「用户登出 + 服务重启」后重新生效（最长可再用 12 小时）。
// 本迁移建表把撤销记录落盘；server.js 启动时把未过期项载回内存，登出即写库，双写保证一致。
//
// 无副作用：首次升级时表为空，等同于原「无撤销记录」状态。
module.exports = {
  version: '006',
  up(db) {
    db.exec(`
      CREATE TABLE IF NOT EXISTS revoked_tokens (
        token TEXT PRIMARY KEY,
        exp   INTEGER NOT NULL DEFAULT 0
      );
      CREATE INDEX IF NOT EXISTS idx_revoked_tokens_exp ON revoked_tokens(exp);
    `);
  }
};
