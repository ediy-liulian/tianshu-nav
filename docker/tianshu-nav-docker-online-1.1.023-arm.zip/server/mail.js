/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 天枢导航 · 邮件发送模块（nodemailer + SMTP 可配）
const nodemailer = require('nodemailer');
const { getSetting } = require('./db');

let transporter = null;
function getTransporter() {
  const host = getSetting('smtp_host');
  if (!host) return null;
  if (transporter) return transporter;
  transporter = nodemailer.createTransport({
    host,
    port: parseInt(getSetting('smtp_port') || '465', 10),
    secure: getSetting('smtp_secure') === '1',
    auth: getSetting('smtp_user') ? { user: getSetting('smtp_user'), pass: getSetting('smtp_pass') } : undefined,
    tls: { rejectUnauthorized: false }
  });
  return transporter;
}

async function sendMail(to, subject, html) {
  const tr = getTransporter();
  if (!tr) {
    const err = new Error('SMTP 未配置');
    err.code = 'SMTP_NOT_CONFIGURED';
    throw err;
  }
  const from = getSetting('smtp_from') || (getSetting('smtp_user') ? getSetting('smtp_user') : 'tianshu@local');
  return tr.sendMail({ from: `"${getSetting('panel_name') || '天枢导航'}" <${from}>`, to, subject, html });
}

module.exports = { sendMail };
