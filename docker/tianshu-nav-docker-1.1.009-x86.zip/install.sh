#!/bin/sh
# 天枢导航 · Docker 离线部署（v1.1.009）
# 用法：解压后在本目录执行  sh install.sh
set -e
IMG=tianshu-nav-image-x86.tar
[ -f "$IMG" ] || IMG=tianshu-nav-image-arm.tar
[ -f "$IMG" ] || { echo "找不到镜像文件 tianshu-nav-image-*.tar"; exit 1; }
echo "[1/3] 导入镜像（约 1-2 分钟）..."
docker load -i "$IMG"
mkdir -p ./data
echo "[2/3] 清理同名旧容器..."
docker rm -f tianshu-nav >/dev/null 2>&1 || true
echo "[3/3] 启动容器..."
docker run -d --name tianshu-nav -p 16080:8080 -v "$PWD/data":/app/data --restart unless-stopped tianshu-nav:runtime
echo "已启动：http://<本机IP>:16080  （数据保存在 ./data）"
