#!/bin/bash
# 天枢导航 docker 在线/离线升级（x86 架构，v1.00.009，升级保留数据）
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
mkdir -p /var/lib/tianshu-nav-instance
docker load -i "$DIR/tianshu-nav-image-x86.tar"
cd "$DIR" && docker compose up -d --force-recreate
echo "升级完成：容器已重建，数据与实例标识保留"
