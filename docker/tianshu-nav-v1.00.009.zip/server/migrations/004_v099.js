'use strict';
// 迁移 004：v0.99.0 结构变更
//  groups.admin_only     管理员专属分组（1=仅管理员可见，普通用户/访客不可见）
//  groups.is_recommend   推荐分组标记（首页「推荐」模块优先展示）
//  settings 广告位钩子（默认关闭）+ 开发者信息 + 示例数据标记
module.exports = {
  version: '004',
  up(db) {
    const addCol = (sql) => { try { db.exec(sql); } catch (e) { if (!/duplicate column/i.test(e.message)) throw e; } };
    addCol('ALTER TABLE groups ADD COLUMN admin_only INTEGER NOT NULL DEFAULT 0');
    addCol('ALTER TABLE groups ADD COLUMN is_recommend INTEGER NOT NULL DEFAULT 0');
    const st = db.prepare('INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)');
    st.run('ad_text_top', '');        // 顶部文字广告（留空关闭）
    st.run('ad_image_top', '');       // 顶部图片广告 URL（留空关闭）
    st.run('ad_image_link', '');      // 图片广告跳转链接
    st.run('ad_popup_enabled', '0');  // 右下角弹窗广告开关
    st.run('ad_popup_text', '');      // 弹窗广告内容（HTML）
    st.run('ad_enabled', '1');        // 广告总开关（管理员可关闭；付费订阅用户自动隐藏）
    st.run('ad_remote_url', '');      // 远端广告接口（留空=使用本地配置；配合授权服务器推送广告）
    st.run('dev_wechat', 'LiuLian-8090');
    st.run('dev_email', '13002501616@163.com');
    st.run('dev_home', 'https://nav.ediy.net');
    st.run('sample_seeded', '0');     // 示例数据是否已初始化
  }
};
