/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 迁移 003：v1.5.9 内外网地址"各存各的"
// 原 schema sites.intranet_url NOT NULL（依赖"缺失项自动同址"填充），
// 现改为允许 NULL：纯外网站点只填外网地址、纯内网站点只填内网地址，
// 修改后按实际填写生效，不再自动双向填充。
// SQLite 不支持 ALTER COLUMN，采用"建新表→拷贝→删除→改名"重建。
module.exports = {
  version: '003',
  up(db) {
    db.exec('PRAGMA foreign_keys = OFF;');
    try {
      db.exec('BEGIN;');
      db.exec(`CREATE TABLE sites_new (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        group_id     INTEGER NOT NULL,
        name         TEXT NOT NULL,
        icon_type    TEXT NOT NULL DEFAULT 'auto',
        icon_ref     TEXT,
        icon_auto    TEXT,
        intranet_url TEXT,
        extranet_url TEXT,
        sort         INTEGER NOT NULL DEFAULT 0,
        remark       TEXT,
        open_mode    TEXT NOT NULL DEFAULT 'new',
        status       TEXT NOT NULL DEFAULT 'active',
        net_flag     TEXT NOT NULL DEFAULT 'auto',
        net_flag_val TEXT,
        visibility   TEXT NOT NULL DEFAULT 'public',
        created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
        FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE
      );`);
      // 兼容旧库（可能缺 002 新增列），拷贝时按实际列兜底
      const cols = db.prepare('PRAGMA table_info(sites)').all().map((c) => c.name);
      const has = (n) => cols.includes(n);
      // sec-ok: 插值内容是 has() 三元表达式，只产出固定列名或字面量，不含外部输入
      db.exec(`INSERT INTO sites_new(id, group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode, status, net_flag, net_flag_val, visibility, created_at)
        SELECT id, group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode, status,
        ${has('net_flag') ? 'net_flag' : "'auto'"}, ${has('net_flag_val') ? 'net_flag_val' : 'NULL'}, ${has('visibility') ? 'visibility' : "'public'"}, created_at FROM sites;`);
      db.exec('DROP TABLE sites;');
      db.exec('ALTER TABLE sites_new RENAME TO sites;');
      db.exec('COMMIT;');
    } catch (e) {
      try { db.exec('ROLLBACK;'); } catch {}
      throw e;
    } finally {
      db.exec('PRAGMA foreign_keys = ON;');
    }
  }
};
