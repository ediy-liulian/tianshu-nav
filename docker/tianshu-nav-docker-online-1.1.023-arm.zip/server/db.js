/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 天枢导航 · 数据库模块（node:sqlite，Node>=22.13 内置，零外部依赖）
const { DatabaseSync } = require('node:sqlite');
const fs = require('fs');
const path = require('path');

const DATA_DIR_IN = process.env.DATA_DIR || path.join(__dirname, '..', 'data');
// 解析为物理路径：项目目录可能位于 Windows Junction 下，libsqlite 在 junction 路径上事务异常
fs.mkdirSync(DATA_DIR_IN, { recursive: true });
const DATA_DIR = fs.realpathSync(DATA_DIR_IN);
const DB_PATH = path.join(DATA_DIR, 'tianshu.db');
// R121：记录「本次启动前数据库是否已存在」——供启动自检区分全新初始化与数据目录异常重置
// （全新：db 与 .secret 均为本次创建，无历史数据；重置：db 是旧文件但 .secret 被删/丢失）
const DB_PREEXISTED = fs.existsSync(DB_PATH);

fs.mkdirSync(path.join(DATA_DIR, 'icons'), { recursive: true });
fs.mkdirSync(path.join(DATA_DIR, 'backups'), { recursive: true });
fs.mkdirSync(path.join(DATA_DIR, 'cache'), { recursive: true });

// R122：数据库连接健康化改造——
// 1) journal_mode 改为 DELETE：数据实时落主文件，消除 WAL 伴生文件（-wal/-shm）在容器可写层
//    （overlayfs）上一致性失效后被 SQLite 回退 4KB 空主文件的隐患。真机实证：登录后 ~30s 账号消失、
//    token 401、重登报「账号不存在」，而磁盘库文件完好、新连接可读（WAL 数据在）——旧连接因 WAL
//    校验失效长期读空库，容器重启（重开连接）即暂时恢复、过一阵再坏。
// 2) 连接健康自检：每 30 秒探活 + users 表哨兵，异常自动重开连接（30 秒内自愈，不再长期带病运行）。
// 3) 存量 WAL 库在切换 journal_mode 或重开时由 SQLite 自动 checkpoint 合并进主文件，数据无损。
function createDb() {
  const ndb = new DatabaseSync(DB_PATH);
  ndb.exec('PRAGMA journal_mode = DELETE;');
  ndb.exec('PRAGMA foreign_keys = ON;');
  return ndb;
}
const _conn = { current: createDb() };
function reopenDb(reason) {
  try { _conn.current.close(); } catch (e) {}
  _conn.current = createDb();
  console.log('[db] 检测到数据库连接异常，已自动重开连接' + (reason ? '（' + reason + '）' : ''));
}
// R127：连接「读空库」防呆公共入口——磁盘库文件存在且非空，但当前连接读到 0 个用户时，
// 判定为连接读空库（R122 真机实证场景：读空库不抛异常，SELECT 1 成功、COUNT 返回 0），
// 自动重开连接（指向磁盘真实文件）后由调用方重试。返回 true 表示已重开。
// 全新初始化窗口（启动 90 秒内）由调用方自行判断是否调用，本函数不做时间判断。
function reopenIfEmptyDb(context) {
  try {
    const row = _conn.current.prepare('SELECT COUNT(*) c FROM users').get();
    if (Number(row ? row.c : 0) === 0) {
      let size = 0;
      try { size = fs.statSync(DB_PATH).size; } catch (e) {}
      if (size > 0) {
        console.log('[db] ' + (context || '业务') + '：当前连接读到空 users 表（磁盘库文件 %d 字节），自动重开连接', size);
        reopenDb(context || '空库防呆');
        return true;
      }
    }
  } catch (e) {}
  return false;
}
// Proxy 转发：重开后 server.js 等消费方持有的 db 引用自动指向新连接
const db = new Proxy({}, {
  get(_t, p) {
    const v = _conn.current[p];
    return typeof v === 'function' ? v.bind(_conn.current) : v;
  },
  set(_t, p, v) { _conn.current[p] = v; return true; }
});
// 连接健康自检（30 秒）：探活 + users 表哨兵（防回退空库后长期带病运行，30 秒内自动重开恢复）
// R127（空库哨兵）：R122 实证「读空库」不抛异常——SELECT 1 成功、COUNT(*) 返回 0，
//   旧连接可长期读空库导致「登录后莫名被踢 + 账号不存在」误报，而磁盘库文件完好、新连接可读。
//   故 COUNT===0 且磁盘库文件存在且非空时，判定连接读空库 → 立即重开自愈。
//   豁免：进程启动后 90 秒内不触发（全新初始化建库/建表/建管理员期间 users 表可能短暂为空）。
const START_AT = Date.now();
setInterval(() => {
  try {
    _conn.current.prepare('SELECT 1').get();
    const row = _conn.current.prepare('SELECT COUNT(*) c FROM users').get();
    const c = row ? Number(row.c) : 0;
    if (c === 0 && Date.now() - START_AT > 90 * 1000) {
      let size = 0;
      try { size = fs.statSync(DB_PATH).size; } catch (e) {}
      if (size > 0) {
        console.log('[db] 当前连接读到空 users 表但磁盘库文件存在（%d 字节），判定连接读空库，自动重开连接', size);
        reopenDb('空库哨兵');
      }
    }
  } catch (e) {
    reopenDb('连接异常: ' + (e && e.message ? e.message : String(e)));
  }
}, 30 * 1000);

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id            INTEGER PRIMARY KEY AUTOINCREMENT,
  email         TEXT UNIQUE NOT NULL,
  username      TEXT NOT NULL,
  password_hash TEXT NOT NULL,
  salt          TEXT NOT NULL,
  role          TEXT NOT NULL DEFAULT 'user',          -- superadmin / admin / user（超管唯一：激活时绑定账号即实例唯一超管）
  perms         TEXT NOT NULL DEFAULT '[]',            -- JSON: 普通管理员可访问模块（超管忽略；敏感模块固定超管专属）
  status        TEXT NOT NULL DEFAULT 'active',        -- active / disabled
  favorites     TEXT NOT NULL DEFAULT '[]',            -- JSON: [{site_id,name,sort}]
  view_mode     TEXT NOT NULL DEFAULT 'auto',          -- auto / intranet / extranet
  created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  last_login_at TEXT,
  pwd_default   INTEGER NOT NULL DEFAULT 1             -- R112：1=仍为默认密码（强制首登引导）；0=已改密
);
CREATE TABLE IF NOT EXISTS invite_codes (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  code       TEXT UNIQUE NOT NULL,
  max_uses   INTEGER NOT NULL DEFAULT 1,
  used_count INTEGER NOT NULL DEFAULT 0,
  status     TEXT NOT NULL DEFAULT 'active',           -- active / disabled
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS groups (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  icon       TEXT NOT NULL DEFAULT 'folder',
  sort       INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  scene      TEXT NOT NULL DEFAULT '',
  show_in_nav INTEGER NOT NULL DEFAULT 1,
  admin_only INTEGER NOT NULL DEFAULT 0,
  is_recommend INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS sites (
  id           INTEGER PRIMARY KEY AUTOINCREMENT,
  group_id     INTEGER NOT NULL,
  name         TEXT NOT NULL,
  icon_type    TEXT NOT NULL DEFAULT 'auto',           -- library / url / auto
  icon_ref     TEXT,                                   -- 图库引用文件名 或 URL
  icon_auto    TEXT,                                   -- 自动拉取到的图标文件
  intranet_url TEXT,                                   -- 可空：纯外网站点仅填外网地址（v1.5.9 各存各的）
  extranet_url TEXT,
  sort         INTEGER NOT NULL DEFAULT 0,
  remark       TEXT,
  open_mode    TEXT NOT NULL DEFAULT 'new',            -- new / self / modal
  status       TEXT NOT NULL DEFAULT 'active',         -- active / disabled
  created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  FOREIGN KEY (group_id) REFERENCES groups(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS icons (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  name       TEXT NOT NULL,
  filename   TEXT UNIQUE NOT NULL,
  category   TEXT NOT NULL DEFAULT '通用',
  uploaded_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS notices (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  title      TEXT NOT NULL,
  content    TEXT NOT NULL,
  level      TEXT NOT NULL DEFAULT 'info',             -- info / warn / important
  pinned     INTEGER NOT NULL DEFAULT 0,
  published  INTEGER NOT NULL DEFAULT 1,
  created_by INTEGER,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS notice_reads (
  notice_id INTEGER NOT NULL,
  user_id   INTEGER NOT NULL,
  read_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  PRIMARY KEY (notice_id, user_id)
);
CREATE TABLE IF NOT EXISTS settings (
  key   TEXT PRIMARY KEY,
  value TEXT
);
CREATE TABLE IF NOT EXISTS version_log (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  version    TEXT NOT NULL,
  log        TEXT NOT NULL,
  date       TEXT NOT NULL DEFAULT '',
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);`)
// R97：兼容既有库（旧表无 date 列）——补列失败说明列已存在，忽略
try { db.prepare("ALTER TABLE version_log ADD COLUMN date TEXT NOT NULL DEFAULT ''").run(); } catch (e) {}
// R112：兼容既有库（旧表无 pwd_default 列）。
// 第 104 轮：存量账号默认 0（不强制引导）——仅「邮箱或密码仍是默认值」的账号才引导（登录/me 动态判定），
// 已改过资料/密码的存量客户升级后不再误弹首登引导；新库建表仍 DEFAULT 1（新装初始超管引导）。
try { db.prepare("ALTER TABLE users ADD COLUMN pwd_default INTEGER NOT NULL DEFAULT 0").run(); } catch (e) {}
// R125（审计 P0 整改）：删除原「R104 存量残留修正」段——启动时按邮箱是否默认强制清 pwd_default 属于越权写入：
//   pwd_default 语义 =「密码是否仍为默认」，只能由登录动作（isDefaultPwd 判明文后置 1）与改密/重置（置 0）维护，
//   不能用邮箱字段推断。原逻辑（db.js:153-156）还会误伤「密码仍默认但邮箱已改」的账号（清 0 后不再触发改密引导），
//   且 _DEF_EMAIL 读 env 与 server.js isDefaultEmail 判定分叉，属 R-C 根因之一。该账号登录时 isDefaultPwd 会自动重新置 1。
db.exec(`CREATE TABLE IF NOT EXISTS operation_logs (
  id         INTEGER PRIMARY KEY AUTOINCREMENT,
  user_id    INTEGER,
  username   TEXT,
  action     TEXT NOT NULL,
  detail     TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS site_applications (
  id          INTEGER PRIMARY KEY AUTOINCREMENT,
  name        TEXT NOT NULL,
  url         TEXT NOT NULL,
  group_name  TEXT,
  note        TEXT,
  user_id     INTEGER,
  username    TEXT,
  status      TEXT NOT NULL DEFAULT 'pending',   -- pending / approved / rejected
  reason      TEXT,
  created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  reviewed_at TEXT
);
CREATE TABLE IF NOT EXISTS schema_meta (
  id      INTEGER PRIMARY KEY CHECK(id=1),
  version TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS orders (
  order_no   TEXT PRIMARY KEY,
  tier       TEXT NOT NULL DEFAULT 'year',
  label      TEXT,
  qty        INTEGER NOT NULL DEFAULT 1,
  amount     TEXT,
  account    TEXT,
  status     TEXT NOT NULL DEFAULT 'pending',   -- pending / submitting / paid / canceled
  code       TEXT,
  created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
  updated_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
`);

// R103C：存量库（R103C 之前版本）users 表无 perms 列，此处补列，保证角色三档化迁移可执行（不破坏用户数据）
try { db.prepare("ALTER TABLE users ADD COLUMN perms TEXT NOT NULL DEFAULT '[]'").run(); } catch (e) {}
// R126（审计 R-D5 改密统一吊销会话）：users 表补 session_version——改密/重置密码/改邮箱时自增，
//   旧 token（sv 落后）即刻全部失效；正常登录重签新 token（sv 同步），当前设备不受影响
try { db.prepare("ALTER TABLE users ADD COLUMN session_version INTEGER NOT NULL DEFAULT 0").run(); } catch (e) {}
// R126（R113-B3 客户端适配）：本地 orders 表补 query_token——下单成功后将云端返回的一次性查询凭证落库，
//   「我的订单」查询时从本地表取凭证透传云端 /pay/query（纯断网场景本地兜底展示仍可用）
try { db.prepare("ALTER TABLE orders ADD COLUMN query_token TEXT NOT NULL DEFAULT ''").run(); } catch (e) {}

// ---------- 默认配置 ----------
const DEFAULT_SETTINGS = {
  panel_name: '天枢导航',
  intro: '内网服务器导航门户：统一入口、内外网自适应、简约设计。',
  about_text: '天枢导航（Tianshu Nav）是一款面向内网服务器环境的网址导航门户，可部署于飞牛 fnOS、群晖、威联通等 NAS 的 Docker 中，为家庭与企业内网提供统一的服务入口。\n\n核心特性：\n· 内外网地址双配置与自动切换，一处收藏、随处可达；\n· 用户注册登录（邮箱验证码 / 邀请码）、个人收藏与自定义视图；\n· 分组管理、公共图库、站点图标自动拉取与手动上传；\n· 站内通知（本站管理员发布）与系统通知（开发者全站推送，首页广播按钮展示）；\n· 系统升级、数据导入导出、操作日志；\n· 深色 / 浅色双主题，适配 Windows、macOS、安卓等多终端。\n\n本站由 EDIY 工作室开发维护，持续迭代中。',
  icp: '',
  register_open: '1',            // 开放注册
  invite_required: '0',          // 注册是否必须邀请码（0=邮箱即可，1=必须邀请码）
  verify_email: '1',             // 注册邮箱验证码校验
  allow_guest: '1',              // 允许访客浏览导航页（只读）
  smtp_host: '', smtp_port: '465', smtp_user: '', smtp_pass: '', smtp_from: '', smtp_secure: '1',
  weather_provider: 'wttr',      // wttr / he
  weather_key: '', weather_city: '南京',
  intranet_segments: '127.0.0.0/8,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,100.64.0.0/10',
  intranet_domains: '',          // 逗号分隔，访问这些域名视为内网
  update_url: '',
  token_ttl_days: '7',
  login_max_fail: '5',
  login_lock_minutes: '15',
  footer_text: '天枢导航 · EDIY 出品',
  copyright: '© 2026 EDIY 工作室',
  notify_sound: '1',    // 系统通知声音提醒（管理后台注册与访问可关；R103 纳入公开设置读取链路）
  license_key: '',      // 授权钩子：激活码（仅存储与状态展示，不做强制校验）
  license_type: '',     // 授权类型：permanent / yearly
  license_expire: '',
  ddns_cfg: ''          // DDNS 动态域名配置（JSON 字符串，凭据 AES-256-GCM 加密；R98 新增）
};

function ensureDefaults() {
  const st = db.prepare('INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)');
  for (const [k, v] of Object.entries(DEFAULT_SETTINGS)) st.run(k, v);
}
ensureDefaults();

// ---------- 版本化数据库迁移 ----------
// 迁移脚本位于 server/migrations/，命名 <3位序号>_<说明>.js，
// 导出 { version: '00N', up(db) }。服务启动时按序执行未应用的迁移（幂等）。
const MIGRATIONS_DIR = path.join(__dirname, 'migrations');
function runMigrations() {
  db.exec('CREATE TABLE IF NOT EXISTS schema_meta (id INTEGER PRIMARY KEY CHECK(id=1), version TEXT NOT NULL);');
  const row = db.prepare('SELECT version FROM schema_meta WHERE id = 1').get();
  const current = row ? row.version : null;
  if (!fs.existsSync(MIGRATIONS_DIR)) return current;
  const files = fs.readdirSync(MIGRATIONS_DIR)
    .filter((f) => /^\d{3}_.+\.js$/.test(f))
    .sort();
  let cur = current;
  for (const f of files) {
    const num = parseInt(f.slice(0, 3), 10);
    if (cur !== null && num <= parseInt(cur, 10)) continue;
    const mig = require(path.join(MIGRATIONS_DIR, f));
    if (typeof mig.up !== 'function') throw new Error('迁移脚本缺少 up(): ' + f);
    mig.up(db);
    db.prepare('INSERT INTO schema_meta(id, version) VALUES(1, ?) ON CONFLICT(id) DO UPDATE SET version=excluded.version').run(mig.version);
    console.log('[migrate] applied', f, '-> schema', mig.version);
    cur = mig.version;
  }
  return cur;
}
try { runMigrations(); } catch (e) { console.error('[migrate] 迁移失败:', e.message); throw e; }

function getSetting(key) {
  const row = db.prepare('SELECT value FROM settings WHERE key = ?').get(key);
  return row ? row.value : (DEFAULT_SETTINGS[key] ?? '');
}
function getSettings() {
  const rows = db.prepare('SELECT key, value FROM settings').all();
  const out = { ...DEFAULT_SETTINGS };
  for (const r of rows) out[r.key] = r.value;
  return out;
}
function setSetting(key, value) {
  db.prepare('INSERT INTO settings(key, value) VALUES(?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value').run(key, String(value));
}
function setSettings(obj) {
  for (const [k, v] of Object.entries(obj)) setSetting(k, v);
}

// 种子：初始管理员（env ADMIN_EMAIL / ADMIN_PASSWORD，默认 admin / admin@ediy666.net / ediy666）
// R103C：角色三档化——默认账号 username=admin、email=admin@ediy666.net、role=superadmin（实例唯一超管）
function seedAdmin() {
  const email = process.env.ADMIN_EMAIL || 'admin@ediy666.net';
  const count = db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
  if (count === 0) {
    const crypto = require('crypto');
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(process.env.ADMIN_PASSWORD || 'ediy666', salt, 64).toString('hex');
    db.prepare('INSERT INTO users(email, username, password_hash, salt, role, perms) VALUES(?, ?, ?, ?, ?, ?)')
      .run(email, 'admin', hash, salt, 'superadmin', '[]');
    console.log('[init] 已创建初始超级管理员:', email, '(默认密码 ediy666，首次登录请修改)');
    return;
  }
  // 旧默认密码迁移：内置 admin 仍使用上一代默认密码 admin123 时，自动升级为新默认 ediy666（自定义过密码的不动）
  // R99-B3：WHERE 放宽为「默认超管邮箱 OR 用户名=admin 的管理员/超管」——历史版本 email 可能非邮箱格式（如 'admin'），
  // 只按邮箱查将漏掉真实存量形态，导致该形态无法享受密码自动迁移。
  try {
    const crypto = require('crypto');
    const u = db.prepare("SELECT * FROM users WHERE (LOWER(email) = LOWER(?) OR (LOWER(username) = ? AND role IN ('admin','superadmin'))) ORDER BY id ASC LIMIT 1")
      .get(email, 'admin');
    if (u && u.password_hash && u.salt) {
      const oldHash = crypto.scryptSync('admin123', u.salt, 64).toString('hex');
      if (oldHash === u.password_hash) {
        const salt = crypto.randomBytes(16).toString('hex');
        const hash = crypto.scryptSync('ediy666', salt, 64).toString('hex');
        db.prepare('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?').run(hash, salt, u.id);
        console.log('[init] 已迁移默认管理员密码 admin123 → ediy666（账号', email + '）');
      }
    }
  } catch (e) { /* 迁移失败不阻断启动 */ }
  // R103C：存量角色三档化迁移——role='admin' 的现有管理员：id 最小的升为 superadmin（实例唯一超管），
  // 其余转普通管理员并默认授予全部可勾选模块（功能不丢，超管可后续调整）；敏感模块不授予。
  try {
    const admins = db.prepare('SELECT * FROM users WHERE role = ? ORDER BY id ASC').all('admin');
    if (admins.length > 0) {
      const ALLOC_PERMS = JSON.stringify(['sites', 'groups', 'icons', 'notices', 'apply', 'orders', 'contact']);
      // 已存在 superadmin 时（重复初始化），现有 admin 全部转普通管理员（全授），不再额外产生超管
      const hasSuper = db.prepare('SELECT COUNT(*) AS c FROM users WHERE role = ?').get('superadmin').c > 0;
      admins.forEach((u, i) => {
        if (!hasSuper && i === 0) {
          db.prepare("UPDATE users SET role = 'superadmin', perms = '[]' WHERE id = ?").run(u.id);
          console.log('[init] 存量管理员已升级为超级管理员:', u.email || u.username);
        } else {
          db.prepare('UPDATE users SET role = ?, perms = ? WHERE id = ?').run('admin', ALLOC_PERMS, u.id);
          console.log('[init] 存量管理员已转为普通管理员（权限默认全授）:', u.email || u.username);
        }
      });
    }
  } catch (e) { /* 迁移失败不阻断启动 */ }
  // R99-B3：存量超管邮箱规格化——历史版本 email 可能非邮箱格式（如 'admin'），
  // 不规格化将陷入死锁：激活因非邮箱被拒、改邮箱被「已激活才锁」前的无条件守卫拦截、首登引导不弹出（last_login_at 有值）。
  // 规格化写回默认超管邮箱并清空 last_login_at（触发一次首登引导），解除死锁且不破坏用户数据。
  try {
    const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    // R125：与 server.js isDefaultEmail 收敛——出厂默认邮箱固定字面量，不读 env（ADMIN_EMAIL 仅建库初始邮箱，不参与默认判定）
  // R126（O-E）：规格化只改邮箱、保留 last_login_at——首登引导判定已统一为 needGuide（pwd_default!==0 || !isDefaultEmail，
  //   server.js L49-57），不再依赖 last_login_at；清空它会误弹引导、对已改密用户造成死锁（改邮箱被「已激活才锁」守卫拦截）
    const DEF_EMAIL = 'admin@ediy666.net';
    const supers = db.prepare("SELECT * FROM users WHERE role = 'superadmin' ORDER BY id ASC").all();
    supers.forEach((u) => {
      if (!u.email || !EMAIL_RE.test(u.email)) {
        const dup = db.prepare('SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND id <> ?').get(DEF_EMAIL, u.id);
        if (!dup) {
          db.prepare("UPDATE users SET email = ? WHERE id = ?").run(DEF_EMAIL, u.id);
          console.log('[init] 存量超管邮箱已规格化:', (u.email || '(空)'), '→', DEF_EMAIL, '（登录后按密码状态决定是否引导）');
        } else {
          // R100-B3：冲突时不要保留非邮箱原值——派生确定性唯一邮箱写回。
          // R125（审计 P0 整改）：移除原「强制置 pwd_default=1」——pwd_default 只能由登录/改密动作维护，
          //   冲突修复仅改邮箱；若密码仍为默认，登录时 isDefaultPwd 会自动置 1 触发引导，不再需要越权预置。
          const domain = DEF_EMAIL.split('@')[1] || 'ediy666.net';
          const fb = 'admin+' + u.id + '@' + domain;
          db.prepare("UPDATE users SET email = ? WHERE id = ?").run(fb, u.id);
          console.log('[init] 存量超管邮箱冲突，已派生唯一邮箱:', (u.email || '(空)'), '→', fb, '（登录后按密码状态决定是否引导）');
        }
      }
    });
  } catch (e) { /* 迁移失败不阻断启动 */ }
}
seedAdmin();

function logOp(user, action, detail) {
  db.prepare('INSERT INTO operation_logs(user_id, username, action, detail) VALUES(?, ?, ?, ?)')
    .run(user ? user.id : null, user ? user.username : '系统', action, detail || '');
}

// 版本日志（规则：版本日志只在正式版 v1.0.0 起记录，测试版不写入；seedVersionLog 幂等，同版本不重复）
// 历史版本补种：正式版发布后，升级用户也能看到完整版本演进
// R97：记录追加「更新日期」字段 [版本号, 更新说明, 更新日期]
// R115：日志文案统一「新增」「修复」两段式（不加类字，有则写无则省，言简意赅）；1.0.0 起全量刷新；
// 注意：客户端可见文本，严禁出现 8 个敏感词（打包脚本 C9 全量扫描，含注释）
const VERSION_HISTORY = [
  ['1.0.0', '功能更新：正式版发布，站点分组导航、搜索、管理后台、授权订阅全量上线 ｜ 修复：无', '2026-10-03'],
  ['1.00.001', '功能更新：版本日志、登录二次验证、表格列宽拖拽 ｜ 修复：ZIP 中文文件名乱码、广告开关失效', '2026-10-14'],
  ['1.00.002', '功能更新：站点表单改造与图标在线下载、系统设置分模块保存、关键操作二次验证 ｜ 修复：表格列宽与拖拽手柄不统一', '2026-10-15'],
  ['1.00.003', '功能更新：通知声音提醒与开关、弹窗回车提交 ｜ 修复：控件高度、菜单顺序与操作按钮不统一', '2026-10-16'],
  ['1.00.004', '功能更新：账号体系重构（邮箱登录、首登引导改密）、管理员分级与模块权限 ｜ 修复：设备心跳不符未自动降级', '2026-10-17'],
  ['1.00.005', '功能更新：双架构安装包与离线部署包、首登强制改密、管理端会话安全 ｜ 修复：卸载重装后数据与授权丢失', '2026-10-18'],
  ['1.00.006', '功能更新：推广返佣体系、部署包在线离线分类、运营驾驶舱图表化 ｜ 修复：首页横幅默认展示、同版本覆盖安装失败、推广页打开报错', '2026-10-18'],
  ['1.00.007', '功能更新：无 ｜ 修复：首登引导状态回退、推广令牌可被离线伪造、部署包文案未区分', '2026-10-20'],
  ['1.00.008', '功能更新：无 ｜ 修复：首登引导保存后进后台不稳定、改授权邮箱后授权状态误判', '2026-10-20'],
  ['1.00.009', '功能更新：无 ｜ 修复：只改邮箱会清掉默认密码标记、登出后旧登录令牌仍有效', '2026-10-20'],
  ['1.00.010', '功能更新：无 ｜ 修复：支付订单可被匿名枚举与投毒、微信回调解析失效、永久档时长被截断', '2026-10-22'],
  ['1.00.011', '功能更新：无 ｜ 修复：支付回调吞单（发码入口与金额校验）、订单查询凭证、响应格式不统一', '2026-10-22'],
  ['1.00.012', '功能更新：无 ｜ 修复：登录无故被踢、改密后其他会话不下线、升级包路径穿越与验证码暴破', '2026-10-22'],
  ['1.1.000', '功能更新：导航每行固定 6 列、界面规范补认证页、落地页配图按新界面重截 ｜ 修复：后台登录卡片宽度、危险操作红实心按钮、图表越界配色', '2026-10-25'],
  ['1.1.001', '功能更新：管理后台信息架构重组（菜单 5 组 15 项、右栏全页常驻、驾驶舱柱状图、顶栏分类搜索） ｜ 修复：手机端侧栏未隐藏、审计时间乱码、7 天到期数恒为 0', '2026-10-26'],
  ['1.1.002', '功能更新：宽表操作列钉在右边缘、订单表按状态重排 ｜ 修复：行内删除为红实心按钮、操作按钮被挤出屏幕、打包链路缺语法门禁', '2026-10-26'],
  ['1.1.003', '功能更新：无 ｜ 修复：同机多套实例标识撞号可一码双开、云端同机实例互相删除记录', '2026-10-26'],
  ['1.1.004', '功能更新：版本日志改「功能更新 / 修复」两栏总结式、管理后台显示部署槽位、撞号告警发邮件 ｜ 修复：升级包解压未拒绝路径穿越、落地页页脚留白、云端依赖安全告警、桌面图标仍显示旧标志', '2026-10-29'],
  ['1.1.005', '功能更新：下载库标注「当前版本 / 历史版本」，历史包降色并打红色警示 ｜ 修复：包内图片被换行归一化损坏致示例广告空白、首页与后台内容区宽度不统一、后台表格列被截断、弹窗广告混入后台、下载库文件名被折断', '2026-10-29'],
  ['1.1.006', '功能更新：按钮令牌统一、推广配置四列网格、下载区一键下架历史版本、升级包 Ed25519 验签 ｜ 修复：对比度不足 7 类、小字、横向滚动条、长版本号溢出、左缘错位、深色广告隐形、亮色令牌与主站不一致', '2026-10-30'],
  ['1.1.007', '功能更新：首页收进版心、后台改宽屏、版本日志三列表格可搜索筛选、推广配置三段式、favicon 统一 ｜ 修复：支付宝当面付拿不到二维码、只填私钥被判未配置、命令条按钮贴死、品牌块冗余、模板腔文案', '2026-10-31'],
  ['1.1.008', '功能更新：全部交付包按整包覆盖部署重出，消除同版本号不同内容 ｜ 修复：检查更新弹窗显示上一轮说明（改为从版本记录生成）', '2026-10-31'],
  ['1.1.009', '功能更新：首页版心回到 1.0 的 1440，宽屏不再局促 ｜ 修复：顶部与底部占位横幅缺「广告」角标、角标会叠压占位图文案', '2026-10-31'],
  ['1.1.010', '功能更新：落地页版心统一 1440、后台顶栏与内容左右对齐、侧栏底部精简为版本与版权两行、推广配置改用客户端同款拨动开关 ｜ 修复：删除过期订单与确认到账全部失败、吊销授权码失败', '2026-10-31'],
  ['1.1.011', '功能更新：客户端登录页、管理后台、关于我们与浏览器扩展新标签页统一换用新版品牌 LOGO ｜ 修复：勾选「记住我」后刷新浏览器仍需重新登录、后台开启二次验证后登录页没有输入动态验证码的位置', '2026-10-31'],
  ['1.1.012', '功能更新：超管进后台自动检测新版本并弹窗提醒，可选立即升级、稍后提醒或忽略此版本；系统设置新增「自动检查更新」开关 ｜ 修复：更新源不可达改为静默、首登引导与升级提醒弹窗互盖、重复检测改为缓存 6 小时', '2026-10-31'],
  ['1.1.013', '功能更新：导航卡片改为横排并显示域名，悬停有光条；提示移到右下角，按成功失败分色；必填项统一加红星 ｜ 修复：落地页明暗截图错位；登录页脚显示不全', '2026-11-01'],
  ['1.1.014', '功能更新：升级结束后直接告知结果，成功自动刷新，未生效说明原因 ｜ 修复：在线升级后服务反复重启；后台一直停在重启画面；版本提示文字精简', '2026-11-01'],
  ['1.1.015', '功能更新：升级提示的说明改为一屏讲清，改了什么、要多久、数据是否受影响一眼可见 ｜ 修复：更新说明过长时文字挤在一起，现在只显示要点，需要时展开全文', '2026-11-01'],
  ['1.1.016', '功能更新：官网的产品界面预览全部复拍，明暗交错排布，看点更清楚 ｜ 修复：预览图里还带着广告位，与「专业版自动隐藏广告」的说法对不上', '2026-11-01'],
  ['1.1.017', '功能更新：升级成功后自动停在在线升级页，直接看到从哪个版本升到哪个版本 ｜ 修复：升级其实已经成功，却提示「版本仍是旧版」，要多刷一次才看到新版', '2026-11-01'],
  ['1.1.018', '功能更新：首页加了一层科技感底纹；授权订阅页重排，授权状态、三档订阅、我的订单、额度用量一屏看完 ｜ 修复：激活后顶栏不显示专业版；授权失效看不到原因', '2026-11-01'],
  ['1.1.019', '功能更新：无 ｜ 修复：个别公网站点被误判为内网，自动取图标取不到；外链在新窗口打开时不再影响原页面', '2026-11-01'],
  ['1.1.020', '功能更新：取消全站方格底纹；授权订阅页改为单列排版并去掉重复的订单卡 ｜ 修复：免费版额度文案显示 null；加入QQ群按钮各页大小不一', '2026-11-01'],
  ['1.1.021', '功能更新：全站取消方格底纹，背景统一为纯净渐变 ｜ 修复：无', '2026-11-01'],
  ['1.1.022', '功能更新：后台「授权与订单」拆分为授权订阅 / 我的订单 / 推广返利 / 设备与安全四项，授权订阅页恢复铺满，全后台小节标题竖线统一 ｜ 修复：授权页右侧留白、标题竖线有无不一', '2026-11-01'],
  ['1.1.023', '功能更新：授权订阅页去掉多余入口，历史授权回到本页；「设备与安全」更名「移机换绑」；状态卡改为会员卡渐变；站内购买可按后台开关选支付宝 / 微信 / 人工 ｜ 修复：工作室链接指错站点、人工收款二维码被联动设置清空', '2026-11-01'],
];
// 版本比较：唯一实现在 ./version.js（R133 / B-14：此前本文件另写一份 cmpVersion，只比前 3 段，
// 与 server.js / 云端 api.js 口径不一致，导致 1.00.012.1 被判等于 1.00.012）
const { compareVer, isFormalVersion } = require('./version');
function seedVersionLog(version, log) {
  if (!isFormalVersion(version)) return;
  // R95：清理历史占位记录（早期「修复已知BUG或问题」自动文案）与同版本重复记录（根因=补种后已读集合未刷新）
  db.prepare("DELETE FROM version_log WHERE log LIKE '%修复已知BUG%'").run();
  const dupRows = db.prepare('SELECT id, version FROM version_log ORDER BY id').all();
  const seen = {};
  for (const r of dupRows) {
    if (seen[r.version]) db.prepare('DELETE FROM version_log WHERE id = ?').run(r.id);
    else seen[r.version] = 1;
  }
  // R115：存量文本按版本覆盖刷新——已存在版本但文案与 VERSION_HISTORY 不同（旧长句流水账）时 UPDATE 为新分类文案，
  // 满足「从 1.0.0 开始的日志全部重新刷新」；同版本重复记录去重逻辑保持
  const existRows = db.prepare('SELECT id, version, log FROM version_log ORDER BY id').all();
  const existMap = {};
  for (const r of existRows) { if (!existMap[r.version]) existMap[r.version] = { id: r.id, log: r.log }; }
  const exist = new Set();  // R95：已读集合（防同版本重复插入；断言特征 exist.add）
  const ins = db.prepare('INSERT INTO version_log(version, log, date) VALUES(?, ?, ?)');
  const upd = db.prepare('UPDATE version_log SET log = ?, date = ? WHERE id = ?');
  // 版本比较统一走 ./version.js（R133 / B-14），仅补种 <= 当前版本的历史条目
  // （正式版规则：VERSION_HISTORY 只保留已发布版本，未来记录全部丢弃；此过滤作防御，即便将来误加未来条目也不会提前写入）
  for (const [v, l, d] of VERSION_HISTORY) {
    if (compareVer(v, version) <= 0) {
      const ex = existMap[v];
      if (!ex) { ins.run(v, l, d || ''); existMap[v] = { id: 0, log: l }; }
      else if (ex.log !== l) { upd.run(l, d || '', ex.id); ex.log = l; }
      exist.add(v);
    }
  }
  // R95：log 省略/为空时不再写占位文案——说明一律取自 VERSION_HISTORY 真实记录，保证言简意赅
  const finalLog = (log && String(log).trim()) ? String(log).trim() : '';
  if (version && finalLog && !existMap[version]) ins.run(version, finalLog, new Date().toISOString().slice(0, 10));
}

module.exports = { db, DATA_DIR, DB_PATH, DB_PREEXISTED, reopenDb, reopenIfEmptyDb, getSetting, getSettings, setSetting, setSettings, logOp, seedVersionLog };
