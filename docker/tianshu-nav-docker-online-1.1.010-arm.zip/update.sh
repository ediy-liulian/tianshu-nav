#!/bin/sh
# 天枢导航 · Docker 在线包升级（v1.1.010，数据在 ./data，不会删除数据目录）
set -e
docker compose down >/dev/null 2>&1 || true
docker compose build --no-cache
docker compose up -d
echo "升级完成：http://<本机IP>:16080"
