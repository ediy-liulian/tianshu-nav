'use strict';
// 迁移 005：v0.99.28 全站永久域名统一——旧默认链接（https://www.ediy.net[/tianshu-nav]）幂等替换为 https://nav.ediy.net
// 仅覆盖旧默认值；用户自定义数据不受影响
module.exports = {
  version: '005',
  up(db) {
    const OLD1 = 'https://www.ediy.net/tianshu-nav';
    const OLD2 = 'https://www.ediy.net';
    const NEW = 'https://nav.ediy.net';
    const updExact = db.prepare('UPDATE settings SET value=? WHERE key=? AND value=?');
    updExact.run(NEW, 'ad_image_link', OLD1);
    updExact.run(NEW, 'ad_footer_link', OLD1);
    updExact.run(NEW, 'dev_home', OLD2);
    const keys = ['ad_popup_text', 'ad_img_cols', 'ad_cols', 'ad_text_rows', 'ad_between', 'ad_image_top'];
    for (const k of keys) {
      const row = db.prepare('SELECT value FROM settings WHERE key=?').get(k);
      if (row && typeof row.value === 'string' && (row.value.indexOf(OLD1) >= 0 || row.value.indexOf(OLD2) >= 0)) {
        const v = row.value.split(OLD1).join(NEW).split(OLD2).join(NEW);
        db.prepare('UPDATE settings SET value=? WHERE key=?').run(v, k);
      }
    }
  }
};
