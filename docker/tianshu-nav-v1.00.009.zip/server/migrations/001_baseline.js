'use strict';
// 迁移 001：基线。为旧库（v1.4.0 及更早，无 schema_meta）建立版本标记。
// 新库在 db.js 建表时已含 schema_meta（幂等），此处同样安全。
module.exports = {
  version: '001',
  up(db) {
    db.exec('CREATE TABLE IF NOT EXISTS schema_meta (id INTEGER PRIMARY KEY CHECK(id=1), version TEXT NOT NULL);');
    db.prepare('INSERT INTO schema_meta(id, version) VALUES(1, ?) ON CONFLICT(id) DO UPDATE SET version=excluded.version').run('001');
  }
};
