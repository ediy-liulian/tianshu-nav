/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
/*!
 * 天枢导航 TIANSHU NAV · 内网服务器导航门户
 * Copyright (c) 2026 EDIY工作室 · https://www.ediy.net
 * 版权归 EDIY工作室 所有；未经授权不得复制、分发或用于商业用途。
 */
'use strict';
// 天枢导航（Tianshu Nav）· 内网服务器导航门户 —— 后端主服务
// 部署：飞牛 fnOS Docker（对外建议映射 5 位高位端口，如 16080）
const express = require('express');
// R126（审计 R-D1）：pwd_default 唯一写入口——全站禁止散落 UPDATE users SET pwd_default，见 userState.js
const userState = require('./userState');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const { execFileSync } = require('child_process');
const zlib = require('zlib');

const { db, DATA_DIR, DB_PATH, DB_PREEXISTED, reopenDb, reopenIfEmptyDb, getSetting, getSettings, setSetting, setSettings, logOp, seedVersionLog } = require('./db');
const { sendMail } = require('./mail');
const { ensureIcon, serveIcon, probeSite } = require('./icons');
const { getWeather } = require('./weather');
const { createLicense } = require('./license');
const integrity = require('./integrity');   // 防篡改自校验（安全强化④）
const { createDdns } = require('./ddns');    // DDNS 动态域名（R98 新增，10 家服务商）

const APP_NAME = '天枢导航';
const APP_VERSION = '1.1.023';
// v0.99.53：在线演示模式（DEMO=1）——只读试用，除登录外禁止一切写操作；
// 数据目录由部署方指向临时目录（如 tmpfs），容器/进程重启即还原初始示例数据
const DEMO = process.env.DEMO === '1';
const APP_BUILD = '2026-11-02';
const APP_HOME = 'https://nav.ediy.net';
// R183：工作室主站。产品页（APP_HOME=nav.ediy.net）与工作室主站是两个地址，此前混用成一个：
// 页脚版权「© 2026 EDIY 工作室」和「关于我们 → 官网」都指向 nav.ediy.net，点进去还是本产品自己。
// 产品方要求「EDIY 工作室 的超链接应改为 EDIY 工作室的主站」——凡是以工作室名义出现的链接走 APP_SITE。
const APP_SITE = 'https://www.ediy.net';
const APP_EMAIL = '13002501616@163.com';
const APP_COPYRIGHT = '© 2026 EDIY 工作室';
const APP_DEV = { wechat: 'LiuLian-8090', email: APP_EMAIL, home: APP_SITE, qqGroup: '1107374637' };

// R183：工作室链接归一化。为什么需要这一步——「官网」有两个来源，都可能是脏的：
//   ① 云端 /remote/config 的 devInfo.site / home：1.1.022 之前云端默认值就是产品页 nav.ediy.net，
//      老库还会一直带着这个值，客户端升级了也照旧收到（远端覆盖本地是规格行为，不能靠调云端掩盖）；
//   ② 本地 settings.dev_home：迁移 004 种成 nav.ediy.net、005 又主动把历史值改回 nav.ediy.net（007 已纠正，但只改默认值那一类）。
// 两个地址语义不同：nav.ediy.net = 本产品页，www.ediy.net = 工作室主站。凡是「以工作室名义」出现的链接必须走主站，
// 所以这里把「指向产品页」当成「未配置」，回落到 APP_SITE —— 而不是把产品页当官网渲染出去。
// 注意只拦截这两个已知产品页地址，管理员自填的第三方域名一律原样放行（不擅自改人配置）。
function devSite(v) {
  const t = String(v || '').trim().replace(/\/+$/, '');
  if (!t) return '';
  if (t === APP_HOME || t === 'https://nav.ediy.net' || t === 'https://demo.nav.ediy.net') return '';
  return t;
}

// 授权与远端联动（激活码在线激活、版本徽标、免费配额、远端配置）
const lic = createLicense({ getSetting, setSetting, db, APP_VERSION, APP_NAME, dataDir: DATA_DIR });

// R113/A7：超管资料锁定收敛为「已激活才锁」——真实 pro 授权才锁用户名/邮箱；
// 未激活实例允许调整资料，解除存量非法邮箱（激活/改邮箱/提权三路全封）死锁；换超管仍须解绑迁移
function superAdminLocked(u) {
  if (!u || u.role !== 'superadmin') return false;
  const s = lic.state();
  return !!(s && s.licensed && s.type === 'pro');
}

// R100-B2：默认密码判定（全站 6 处统一，杜绝改一漏五）
function isDefaultPwd(p) { return String(p || '') === 'ediy666'; }
// 第 104 轮 + R116：默认邮箱判定——只判「出厂内置默认邮箱」。
// R116 修复：此前把环境变量 ADMIN_EMAIL 也纳入「默认」判定，导致用户部署时若把 ADMIN_EMAIL 配成自己的邮箱，
// 该邮箱永远被判「默认未改」，首登引导死循环（每次进后台都弹「邮箱仍为默认值」），且保存后无法解除。
// 环境变量 ADMIN_EMAIL 只用于首次建库时的初始管理员邮箱（用户主动指定的邮箱即「已改」），不参与默认判定。
function isDefaultEmail(e) { return String(e || '').trim().toLowerCase() === 'admin@ediy666.net'; }
// R104-B3：首登引导唯一求值函数——「密码已改 AND 邮箱非默认」才算完成引导。
// 全站（登录 must_change / me / forceGuide）统一调用此处，禁止在调用点散落叠加判断（此前登录置位掺入邮箱判定，
// 把改密成果 pwd_default=1 冲掉造成引导死锁，R104 通知单 G9 铁证）。
function needGuide(u) {
  if (!u) return false;
  const pwdOk = (u.pwd_default || 0) === 0;   // 已改密（pwd_default=1 表示「仍需强制改密」）
  const mailOk = !isDefaultEmail(u.email);    // 邮箱非出厂占位
  return !(pwdOk && mailOk);
}

// v0.99.72：在线演示（DEMO=1）云端联动本地模拟——返回「演示标记」的模拟成功结果，
// 让潜在客户可完整体验「站内购买 / 激活 / 解绑迁移 / 问题反馈」等流程，但数据绝不上送线上服务器
// （配合 license.js remoteBase() 在 DEMO 下返回空的双重防线，防止任何漏网请求打到线上运维数据库）。
function demoMock(extra) {
  return Object.assign({ ok: true, demo: true, note: '在线演示环境：已模拟成功，数据不会提交，关闭页面后自动还原' }, extra || {});
}

const ROOT = path.join(__dirname, '..');
const PUBLIC_DIR = path.join(ROOT, 'public');
const ICON_AUTO_DIR = path.join(DATA_DIR, 'icons', 'auto');
const ICON_LIB_DIR = path.join(DATA_DIR, 'icons', 'library');
const ICON_UPLOAD_DIR = path.join(DATA_DIR, 'icons', 'upload');
// 持久化升级目录（数据卷内）：上传的升级包先写入此处，容器重启/重建后由启动流程自动应用，升级不因容器重建丢失
const UPGRADE_DIR = path.join(DATA_DIR, 'upgrade');
const UPGRADE_FILES = path.join(UPGRADE_DIR, 'files');
const UPGRADE_META = path.join(UPGRADE_DIR, 'meta.json');
for (const d of [ICON_AUTO_DIR, ICON_LIB_DIR, ICON_UPLOAD_DIR]) fs.mkdirSync(d, { recursive: true });

// ---------- 会话令牌（HMAC-SHA256 自签名） ----------
function loadSecret() {
  const p = path.join(DATA_DIR, '.secret');
  if (fs.existsSync(p)) return fs.readFileSync(p, 'utf8').trim();
  const s = crypto.randomBytes(32).toString('hex');
  fs.writeFileSync(p, s, { mode: 0o600 });
  // R121：启动自检——.secret 缺失但数据库是本次启动前已存在的旧库，说明数据目录被重置/清空后重建
  // （卸载重装、清空数据卷、异常覆盖）。所有历史登录态与令牌即刻全部失效，需重新登录。
  // 打警告日志供运维定位，避免「登录后莫名被登出/账号时有时无」无从查起。
  // 全新初始化（db 与 .secret 均为本次创建）不警告。
  try {
    if (DB_PREEXISTED) {
      console.error('⚠ [启动自检] 检测到 .secret 缺失但数据库为旧库：数据目录疑似被重置/清空（卸载重装或数据卷异常），历史会话与令牌已全部失效，需重新登录。');
    }
  } catch (e) {}
  return s;
}
const SECRET = loadSecret();
// DDNS 动态域名实例（依赖 SECRET 加密凭据，故在 SECRET 初始化后创建）
const ddns = createDdns({ getSetting, setSetting, logOp, secret: SECRET, isDemo: () => DEMO });
// 防篡改自校验状态：启动时对核心文件做 HMAC 比对，结果暴露给管理后台提示（不阻断启动）
// v0.99.72：在线演示（DEMO=1）环境跳过完整性校验——演示实例由服务器端自动拉起、随升级包同步覆盖，
// 每次同步后文件哈希会变化，若按正式客户端规则校验会误报「程序文件可能被篡改」，故演示环境直接判定 ok。
let integrityState = null;
function runIntegrityCheck() {
  try {
    if (DEMO) {
      integrityState = { ok: true, checked: 0, failed: [], note: 'demo-skip' };
      return integrityState;
    }
    integrityState = integrity.check(ROOT);
    if (integrityState && !integrityState.ok) {
      console.error('⚠ [安全] 文件完整性校验未通过，检测到文件可能被篡改：', (integrityState.failed || []).join(', '));
      console.error('⚠ [安全] 若为手动改动请重新打包部署；否则请立即联系开发者核查服务器安全。');
    }
  } catch (e) { integrityState = null; }
  return integrityState;
}

function sign(payload) {
  const b64 = Buffer.from(JSON.stringify(payload)).toString('base64url');
  const sig = crypto.createHmac('sha256', SECRET).update(b64).digest('base64url');
  return `${b64}.${sig}`;
}
function verify(token) {
  try {
    const [b64, sig] = token.split('.');
    const expect = crypto.createHmac('sha256', SECRET).update(b64).digest('base64url');
    // v0.99.72（O-D）：签名比较改恒定时间比较，杜绝时序侧信道（原 `sig !== expect` 字符串比较）。
    // timingSafeEqual 要求等长 Buffer，长度不一致直接判失败。
    const a = Buffer.from(String(sig || ''));
    const b = Buffer.from(String(expect || ''));
    if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
    const payload = JSON.parse(Buffer.from(b64, 'base64url').toString('utf8'));
    if (payload.exp && payload.exp < Date.now()) return null;
    return payload;
  } catch { return null; }
}
// R128（登录被踢根治）：有效期算法收敛为唯一真源——此前 issueToken 的 remember 形参被四处调用硬编码 false，
// 「记住我」永久无效、登录固定 12 小时到期即被踢（真机实测 remember=true/false 均返回 12.00 小时）。
// 约定：remember=true → 取设置 token_ttl_days（默认 7 天，与 db 初始值一致；钳制 1~365），叠加滑动续期后
//       只要在有效期内用过一次就永不断线；remember=false → 12 小时（公共电脑场景）。
const TOKEN_TTL_DEFAULT_DAYS = 7;
const TOKEN_TTL_SHORT_MS = 12 * 3600 * 1000;
function tokenTtlMs(remember) {
  if (!remember) return TOKEN_TTL_SHORT_MS;
  const raw = parseInt(getSetting('token_ttl_days') || String(TOKEN_TTL_DEFAULT_DAYS), 10);
  const days = Math.min(Math.max(Number.isFinite(raw) ? raw : TOKEN_TTL_DEFAULT_DAYS, 1), 365);
  return days * 24 * 3600 * 1000;
}
function issueToken(user, remember) {
  // R126（R-D5）：token 携带会话版本 sv——改密/重置密码时 session_version 自增，旧 sv token 即刻失效
  // R128：新增 rm 标志，供滑动续期按原意图续签（旧 token 无 rm 字段按「不记住」处理，兼容升级前会话）
  return sign({ uid: user.id, sv: (user.session_version || 0), rm: remember ? 1 : 0, exp: Date.now() + tokenTtlMs(remember) });
}
// R105-O4：登出后旧 token 立即失效。
// R133-B5（审计 B-5）：原实现是**进程内 Map**，服务重启即清空 ⇒ 已登出的旧 token 会「复活」，
// 最长可再用 12 小时。现改为「内存缓存 + 落库」双写：撤销即写 revoked_tokens 表，
// 启动时把未过期项载回内存；表由 migrations/006_v100012.js 建立。
const revokedTokens = new Map(); // token -> exp(0 表示未设置)
function loadRevokedTokens() {
  try {
    const now = Date.now();
    db.prepare('DELETE FROM revoked_tokens WHERE exp > 0 AND exp < ?').run(now);
    const rows = db.prepare('SELECT token, exp FROM revoked_tokens').all();
    revokedTokens.clear();
    for (const r of rows) revokedTokens.set(r.token, r.exp || 0);
    if (rows.length) console.log('[revoke] 已从库载入 %d 条撤销记录', rows.length);
  } catch (e) { console.error('[revoke] 载入撤销表失败（降级为内存态）:', e.message); }
}
function revokeToken(token) {
  const p = verify(token);
  if (!p) return;
  revokedTokens.set(token, p.exp || 0);
  try {
    db.prepare('INSERT OR REPLACE INTO revoked_tokens(token, exp) VALUES(?, ?)').run(token, p.exp || 0);
  } catch (e) { /* 落库失败不影响本次登出：内存态仍然生效 */ }
  const now = Date.now();
  for (const [k, e] of revokedTokens) { if (e && e < now) revokedTokens.delete(k); }
  try { db.prepare('DELETE FROM revoked_tokens WHERE exp > 0 AND exp < ?').run(now); } catch (e) {}
}
// R126（R-D5）：改密统一吊销会话——自增 session_version 使该用户全部旧 token 失效；
// 当前设备在改密成功后重签新 token（带新 sv）保持登录，其余设备强制重新登录。
function revokeAllSessions(userId) {
  try { db.prepare('UPDATE users SET session_version = session_version + 1 WHERE id = ?').run(userId); } catch (e) {}
}

// R133-B9（审计 B-9）：cookie 缺 secure 标志。
// ⚠️ 关键判断：**不能无条件加 secure**。本产品主打内网 HTTP 访问（http://10.0.0.x:16080），
// 一旦写成 secure:true，浏览器在 http:// 下完全不回传 cookie ⇒ 登录直接失效，比原漏洞更严重。
// 正确口径：仅当本次请求确实走 HTTPS（直连 TLS，或反代透传 X-Forwarded-Proto=https）时才置 secure。
function cookieOpt(req, maxAgeMs) {
  const xf = String((req && req.headers && req.headers['x-forwarded-proto']) || '').split(',')[0].trim().toLowerCase();
  const https = !!(req && (req.secure || xf === 'https'));
  const o = { httpOnly: true, sameSite: 'lax' };
  if (https) o.secure = true;
  if (maxAgeMs) o.maxAge = maxAgeMs;
  return o;
}

// ---------- 认证中间件 ----------
function getUserFromReq(req) {
  const h = req.headers.authorization || '';
  // R133-B6：不再接受 ?token= 传参（审计 B-6）——token 一旦落进访问日志/浏览器历史/反代日志即等于泄漏凭证。
  // 仅认 Authorization: Bearer 与 httpOnly cookie 两条通道；前端已确认无 query token 依赖。
  const token = h.startsWith('Bearer ') ? h.slice(7) : (req.cookies ? req.cookies.ts_token : null);
  if (!token) return null;
  const p = verify(token);
  if (!p) return null;
  if (revokedTokens.has(token)) return null; // R105-O4：已登出 token 立即失效
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(p.uid) || null;
  // R126（R-D5）：会话版本不一致（改密/重置/改邮箱后被吊销）→ 旧 token 失效；
  // 兼容升级前旧 token：未携带 sv 时不校验，按原有效期自然失效
  if (u && p.sv !== undefined && p.sv !== (u.session_version || 0)) return null;
  // R127：连接读空库防呆——磁盘库文件存在但当前连接查到 0 用户（R122 场景：读空库不抛错），
  // 重开连接后重查一次，杜绝「登录后莫名被踢」（401）误报；用户真被删除时重查结果同样为 null，行为不变。
  // 不做启动豁免：触发条件（COUNT=0 且磁盘文件>0）已足够精确——全新初始化 seedAdmin 后 users 即有记录。
  if (!u && reopenIfEmptyDb('鉴权')) {
    u = db.prepare('SELECT * FROM users WHERE id = ?').get(p.uid) || null;
    if (u && p.sv !== undefined && p.sv !== (u.session_version || 0)) return null;
  }
  return u;
}
function reqToken(req) {
  const h = req.headers.authorization || '';
  return h.startsWith('Bearer ') ? h.slice(7) : ((req.cookies ? req.cookies.ts_token : null) || null);
}
// R128：读取当前请求 token 的「记住我」意图，供改密/改资料重签时保持一致（否则改完密码会被降级成 12 小时）
function tokenRemembered(req) {
  try {
    const p = verify(reqToken(req) || '');
    return !!(p && p.rm === 1);
  } catch (e) { return false; }
}
// R128（滑动续期）：剩余寿命不足 1/3 时自动续签，通过 X-Renewed-Token 响应头与 cookie 双通道下发。
// 目的：让「持续在用」的会话永不因到期被踢（此前只有固定 12 小时死线，用户白天登录、晚上就被弹回登录页）。
// 安全边界：只有已通过 sv 校验的 token 才续签；改密/重置后 sv 不匹配，旧 token 拿不到续签。
function maybeRenewToken(req, res, user) {
  try {
    const token = reqToken(req);
    if (!token) return;
    const p = verify(token);
    if (!p || !p.exp) return;
    const remembered = p.rm === 1;
    const ttl = tokenTtlMs(remembered);
    if ((p.exp - Date.now()) > ttl / 3) return;   // 剩余充裕，不续签，避免每请求刷新
    const fresh = issueToken(user, remembered);
    res.setHeader('X-Renewed-Token', fresh);
    res.cookie('ts_token', fresh, cookieOpt(req, remembered ? ttl : 0));   // R133-B9
  } catch (e) { /* 续签失败不影响主流程 */ }
}
function requireAuth(req, res, next) {
  const user = getUserFromReq(req);
  if (!user) return res.status(401).json({ ok: false, error: '未登录或会话已过期' });
  if (user.status !== 'active') return res.status(403).json({ ok: false, error: '账号已被禁用' });
  req.user = user;
  maybeRenewToken(req, res, user);   // R128：滑动续期
  next();
}
function requireAdmin(req, res, next) {
  requireAuth(req, res, () => {
    if (req.user.role !== 'superadmin' && req.user.role !== 'admin') return res.status(403).json({ ok: false, error: '需要管理员权限' });
    // R112：首登深度强制——管理员账号仍为默认密码时，管理操作一律拦截（资料/密码修改与退出放行，见 requireAuth 路由）
    // R116：DEMO 环境豁免此拦截——与登录/me 响应的 !DEMO 豁免一致；否则 demo 前端不弹引导（pwd_default 已掩盖）而后端仍按 DB 拦截 403，
    //       导致系统设置等页面数据 undefined、前端 .filter/.logo 崩溃白屏、广告开关无法操作
    if (!DEMO && (req.user.pwd_default || 0) === 1) return res.status(403).json({ ok: false, error: '请先完成初始资料修改与密码设置后再操作' });
    next();
  });
}
// R103C：超级管理员专属中间件（远端服务只认超管；绑定账号/激活/敏感模块均锁定超管）
function requireSuper(req, res, next) {
  requireAuth(req, res, () => {
    if (req.user.role !== 'superadmin') return res.status(403).json({ ok: false, error: '仅超级管理员可操作' });
    // R116：DEMO 环境豁免首登强制拦截（同 requireAdmin，见上）
    if (!DEMO && (req.user.pwd_default || 0) === 1) return res.status(403).json({ ok: false, error: '请先完成初始资料修改与密码设置后再操作' });
    next();
  });
}
// R103C：普通管理员模块权限校验——超管放行；普通管理员须勾选对应模块权限
const PERM_MODULES = ['sites', 'groups', 'icons', 'notices', 'apply', 'orders', 'contact', 'users', 'settings', 'data', 'upgrade', 'logs'];
function safePerms(u) {
  try { return JSON.parse((u && u.perms) || '[]'); } catch (e) { return []; }
}
function isSuper(u) { return !!(u && u.role === 'superadmin'); }
function requirePerm(module) {
  return (req, res, next) => {
    requireAdmin(req, res, () => {
      if (req.user.role === 'superadmin') return next();
      let perms = [];
      try { perms = JSON.parse(req.user.perms || '[]'); } catch (e) { perms = []; }
      if (!perms.includes(module)) return res.status(403).json({ ok: false, error: '无权访问该模块，请联系超级管理员开通权限' });
      next();
    });
  };
}
// 简易 cookie 解析（不引第三方）
function cookieParser(req, res, next) {
  const c = req.headers.cookie || '';
  const map = {};
  for (const part of c.split(';')) {
    const i = part.indexOf('=');
    if (i > 0) map[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  }
  req.cookies = map;
  next();
}

// ---------- 验证码与防爆破 ----------
const codeStore = new Map();   // `${email}|${scene}` -> {code, exp, tries, lastSent}
const failStore = new Map();   // `ip|email` -> {fails, lockUntil}（v0.99.72 O-B：叠加 IP 维度，防对单一账号的多源爆破/对 admin 的 DoS）
const codeIpRate = new Map();  // `ip|scene` -> {cnt, resetAt}（v0.99.72 O-C：验证码发送 IP 级限频，防邮件轰炸/用户枚举）

// v0.99.72（O-B/O-C）：请求来源 IP——客户端不设 trust proxy，socket.remoteAddress 即真实来源
// （局域网直连；XFF 不采信，杜绝伪造头绕过账号锁定/发送限频）
function reqIp(req) {
  return String((req.socket && req.socket.remoteAddress) || '').replace(/^::ffff:/, '') || 'unknown';
}

function genCode() { return String(crypto.randomInt(100000, 1000000)); }
function maskEmail(email) { return email.replace(/^(.).*(@.+)$/, (m, a, b) => a + '****' + b); }

function sendCodeCore(email, scene, ip) {
  const key = `${email}|${scene}`;
  const now = Date.now();
  const rec = codeStore.get(key);
  if (rec && now - rec.lastSent < 60 * 1000) {
    return { ok: false, error: '发送过于频繁，请 60 秒后再试', wait: Math.ceil((60 * 1000 - (now - rec.lastSent)) / 1000) };
  }
  // v0.99.72（O-C）：同一来源 IP 每分钟最多发 5 次验证码（跨邮箱合并计数，防邮件轰炸/账号枚举）
  const ipKey = `${ip || 'unknown'}|${scene}`;
  const ipRec = codeIpRate.get(ipKey);
  if (ipRec && ipRec.resetAt > now) {
    if (ipRec.cnt >= 5) {
      return { ok: false, error: '发送过于频繁，请稍后再试', wait: Math.ceil((ipRec.resetAt - now) / 1000) };
    }
    ipRec.cnt += 1;
  } else {
    codeIpRate.set(ipKey, { cnt: 1, resetAt: now + 60 * 1000 });
  }
  if (codeIpRate.size > 5000) { for (const [k, v] of codeIpRate) { if (v.resetAt <= now) codeIpRate.delete(k); } }
  const code = genCode();
  codeStore.set(key, { code, exp: now + 5 * 60 * 1000, tries: 0, lastSent: now });
  return { ok: true, code };
}

// ---------- 验证码校验（R133-B2 单一真源） ----------
// 事故背景（审计 B-2）：此前 register 与 forgot 各自写一份校验，两处都是「先比 code、tries 只读不自增」，
// 所谓「5 次尝试上限」永远不会触发 ⇒ 6 位验证码可无限次爆破任意账号（含超管）的改密流程。
// 本函数把规则收成一份：① 先判次数（已用尽立即拒）；② 再比对；③ 比对失败即计次；④ 用尽作废。
const CODE_MAX_TRIES = 5;
function verifyCodeOnce(email, scene, code) {
  const key = `${email}|${scene}`;
  const rec = codeStore.get(key);
  if (!rec) return { ok: false, error: '验证码错误或已过期' };
  if (rec.exp < Date.now()) { codeStore.delete(key); return { ok: false, error: '验证码错误或已过期' }; }
  if (rec.tries >= CODE_MAX_TRIES) return { ok: false, error: '验证码尝试次数过多，请重新发送' };
  if (rec.code !== String(code == null ? '' : code)) {
    rec.tries += 1;                       // ★ 关键：失败一次计一次，此前缺这一行
    if (rec.tries >= CODE_MAX_TRIES) {
      codeStore.delete(key);              // 用尽即作废，必须重新发码
      return { ok: false, error: '验证码尝试次数过多，请重新发送' };
    }
    codeStore.set(key, rec);
    return { ok: false, error: '验证码错误或已过期' };
  }
  return { ok: true };
}

// ---------- 内外网识别 ----------
function ipInCidr(ip, cidr) {
  try {
    const [net, bitsStr] = cidr.split('/');
    const bits = parseInt(bitsStr || '32', 10);
    const toInt = (s) => s.split('.').reduce((a, b) => (a << 8) + parseInt(b, 10), 0) >>> 0;
    const ipInt = toInt(ip);
    const mask = bits === 0 ? 0 : (0xffffffff << (32 - bits)) >>> 0;
    return (ipInt & mask) === (toInt(net) & mask);
  } catch { return false; }
}
function detectMode(req) {
  const manual = req.user ? req.user.view_mode : (req.cookies.ts_mode || 'auto');
  if (manual !== 'auto') return manual;
  let ip = req.headers['x-forwarded-for'] ? req.headers['x-forwarded-for'].split(',')[0].trim() : (req.socket.remoteAddress || '').replace(/^::ffff:/, '');
  const segments = (getSetting('intranet_segments') || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (ip === '::1') ip = '127.0.0.1';
  if (segments.some((c) => ipInCidr(ip, c))) return 'intranet';
  const host = req.headers.host || '';
  const domains = (getSetting('intranet_domains') || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  if (domains.some((d) => host.toLowerCase().endsWith(d))) return 'intranet';
  return 'extranet';
}
// 站点网络属性（徽标）：intranet_only 纯内网 / dual 内外网 / extranet_only 纯外网
function hostIsIntranet(host) {
  const h = (host || '').toLowerCase();
  const segments = (getSetting('intranet_segments') || '').split(',').map((s) => s.trim()).filter(Boolean);
  if (segments.some((c) => ipInCidr(h, c))) return true;
  const domains = (getSetting('intranet_domains') || '').split(',').map((s) => s.trim().toLowerCase()).filter(Boolean);
  return domains.some((d) => h.endsWith(d));
}
function siteNetVal(intra, extra) {
  if (intra && extra && extra !== intra) return 'dual';
  const u = intra || extra || '';
  const host = u.replace(/^https?:\/\//i, '').split('/')[0].split(':')[0];
  return hostIsIntranet(host) ? 'intranet_only' : 'extranet_only';
}
function applyNetFlag(b) {
  if (b.net_flag === 'manual') return { net_flag: 'manual', net_flag_val: b.net_flag_val || 'intranet_only' };
  return { net_flag: 'auto', net_flag_val: siteNetVal((b.intranet_url || '').trim(), (b.extranet_url || '').trim()) };
}

// 判断是否内网/局域网地址（IP 或局域网主机名）
function isLanAddr(host) {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(host)
    || /^(localhost|nas|router|home|dsm|freenas|truenas|synology)$/i.test(host)
    || host.endsWith('.local') || host.endsWith('.lan') || host.endsWith('.home')
    || host.startsWith('192.168.') || host.startsWith('10.') || host.startsWith('172.16.')
    || host.startsWith('172.17.') || host.startsWith('172.18.') || host.startsWith('172.19.')
    || host.startsWith('172.2') || host.startsWith('172.3') || host.split('.').length === 1;
}
// URL 规范化：裸域名自动补协议——IP / 局域网主机名补 http://，公网域名补 https://
function normalizeUrl(raw) {
  let u = String(raw || '').trim();
  if (!u) return '';
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(u)) {
    const hostPart = u.split('/')[0].split(':')[0];
    u = (isLanAddr(hostPart) ? 'http://' : 'https://') + u;
  }
  try {
    const p = new URL(u);
    if (!p.hostname) return '';
    return u;
  } catch { return ''; }
}

// ---------- 首页数据 ----------
function navPayload(user, req) {
  const mode = detectMode(req);
  const isAdmin = user && (user.role === 'admin' || user.role === 'superadmin');
  // 普通用户/访客不可见「管理员专属」分组（admin_only=1）
  const groups = isAdmin
    ? db.prepare('SELECT * FROM groups ORDER BY sort ASC, id ASC').all()
    : db.prepare('SELECT * FROM groups WHERE admin_only = 0 ORDER BY sort ASC, id ASC').all();
  // 私密站点仅管理员可见（接口层过滤）
  const sites = isAdmin
    ? db.prepare('SELECT * FROM sites WHERE status = ? ORDER BY sort ASC, id ASC').all('active')
    : db.prepare('SELECT * FROM sites WHERE status = ? AND visibility = ? ORDER BY sort ASC, id ASC').all('active', 'public');
  const favRows = user ? JSON.parse(user.favorites || '[]') : [];
  const favIds = new Set(favRows.map((f) => f.site_id));
  const fmt = (s) => ({
    id: s.id, group_id: s.group_id, name: s.name, icon_type: s.icon_type, icon_ref: s.icon_ref, icon_auto: s.icon_auto,
    url: mode === 'intranet' ? (s.intranet_url || s.extranet_url) : (s.extranet_url || s.intranet_url),
    intranet_url: s.intranet_url, extranet_url: s.extranet_url || '',
    open_mode: s.open_mode, remark: s.remark || '', fav: favIds.has(s.id),
    net_flag: s.net_flag || 'auto', net_flag_val: s.net_flag_val || siteNetVal(s.intranet_url, s.extranet_url),
    visibility: s.visibility || 'public'
  });
  const favorites = favRows.map((f) => {
    const s = sites.find((x) => x.id === f.site_id);
    return s ? { ...fmt(s), fav_name: f.name || s.name, fav_sort: f.sort } : null;
  }).filter(Boolean);
  return {
    mode, mode_manual: req.user ? req.user.view_mode : (req.cookies.ts_mode || 'auto'),
    is_admin: !!isAdmin,
    groups: groups.map((g) => ({ id: g.id, name: g.name, icon: g.icon, sort: g.sort, scene: g.scene || '', show_in_nav: g.show_in_nav === undefined ? 1 : g.show_in_nav, is_recommend: g.is_recommend === undefined ? 0 : g.is_recommend, admin_only: g.admin_only === undefined ? 0 : g.admin_only })),
    sites: sites.map(fmt), favorites,
    settings: publicSettings(), user: user ? { id: user.id, username: user.username, email: maskEmail(user.email), role: user.role } : null
  };
}
function publicSettings() {
  const s = getSettings();
  // v0.99.72：演示（DEMO=1）环境将线上拉取的广告配置并入远端缓存，使平台广告开关/内容即时生效；
  // 正式客户端维持原逻辑（lic.cached() 的远端配置覆盖）
  const rc = DEMO ? (demoAdsCache ? { ...(lic.cached() || {}), ads: demoAdsCache } : lic.cached()) : lic.cached(); // 远端配置缓存（版权/开发者信息/公告/广告远端覆盖）
  const licenseState = lic.state();
  // 广告位：优先接受服务器端远端推送（规格 3.2.2：远端覆盖本地默认值），本地出厂默认兜底；付费订阅用户由前端自动隐藏
  // 远端 ads 结构：{ enabled, slots: { text:{t,url,color,bold,italic,startAt,endAt}, textCols[], imgCols[], popup:{html,startAt,endAt}, footer:{image,link,html,startAt,endAt} } }
  // 起止时间已在服务器端 /remote/config 下发时按当前时间过滤，客户端直接展示
  const rads = (rc && rc.ads && rc.ads.enabled) ? (rc.ads.slots || {}) : null;
  return {
    panel_name: s.panel_name, intro: s.intro, about_text: s.about_text, icp: s.icp,
    version: APP_VERSION,
    // v0.99.57：公开设置携带演示环境标记，前端登录页据此展示演示账号提示（账号与口令见安装向导）
    demo: !!DEMO,
    // R151：演示账号提示改由服务端下发（仅 DEMO 有值），避免默认口令写进前端公开静态资源
    demo_tip: DEMO ? ('在线演示环境：账号 admin / 密码 ' + ('edi' + 'y666') + '，功能完整可体验，数据重启后自动还原') : '',
    register_open: s.register_open, invite_required: s.invite_required,
    verify_email: s.verify_email, allow_guest: s.allow_guest || '1', footer_text: s.footer_text,
    // R103：系统通知声音提醒开关纳入公开设置读取链路（前端 playSysNoticeSound 依此静音）
    notify_sound: s.notify_sound,
    copyright: (rc && rc.copyright) || APP_COPYRIGHT,   // 版权默认固定（EDIY 工作室），远端可覆盖推送
    weather_city: s.weather_city, weather_provider: s.weather_provider,
    // 授权徽标：免费版中性 / 专业版强调色
    badge: licenseState.badge, licenseType: licenseState.type,
    // 文件完整性状态（安全强化④）：ok=正常 / fail=检测到文件可能被篡改，管理后台展示提示
    integrity: integrityState ? (integrityState.ok ? 'ok' : 'fail') : 'ok',
    // 开发者信息（远端可单独推送 / 随升级推送）
    devInfo: {
      wechat: ((rc && rc.devInfo) ? rc.devInfo.wechat : '') || s.dev_wechat || APP_DEV.wechat,
      email: ((rc && rc.devInfo) ? rc.devInfo.email : '') || s.dev_email || APP_DEV.email,
      // R183：云端面板「官网」保存的字段是 devInfo.site，老字段是 home；两者都认，免得面板改了不生效
      // R183：再用 devSite() 归一一次——远端若仍把产品页当官网（老云端默认值），回落工作室主站
      home: devSite((rc && rc.devInfo) ? (rc.devInfo.home || rc.devInfo.site) : '') || devSite(s.dev_home) || APP_SITE,
      qqGroup: ((rc && rc.devInfo) ? rc.devInfo.qqGroup : '') || s.dev_qq_group || APP_DEV.qqGroup,
      qqGroups: (((rc && rc.devInfo && rc.devInfo.qqGroups) ? rc.devInfo.qqGroups : []) || []).length
        ? rc.devInfo.qqGroups : [s.dev_qq_group || APP_DEV.qqGroup].filter(Boolean)
    },
    // 广告位钩子：优先接受服务器端远端推送（规格 3.2.2：远端覆盖本地默认值），本地出厂默认兜底；付费订阅用户由前端自动隐藏
    // ① 首页顶部横幅广告（1200×50，远端 slots.top 图片/HTML 优先；本地 ad_image_top 兜底）
    ad_top_banner: ((rads && rads.top && (rads.top.image || rads.top.html)) ? { image: rads.top.image || '', html: rads.top.html || '', link: rads.top.link || '', startAt: rads.top.startAt || 0, endAt: rads.top.endAt || 0 } : (s.ad_image_top ? { image: s.ad_image_top, link: s.ad_image_link || '', html: '', startAt: 0, endAt: 0 } : null)),
    ad_image_top: (rads && rads.image) || s.ad_image_top || '', ad_image_link: (rads && rads.imageLink) || s.ad_image_link || '',
    ad_popup_enabled: rads ? ((rads.popup && rads.popup.html) ? '1' : (s.ad_popup_enabled || '0')) : (s.ad_popup_enabled || '0'),
    // 弹窗内容：云端 popup 有内容用云端；否则用本地出厂占位（免费版默认弹窗必现，用户 C1 复测项）
    ad_popup_text: (rads && rads.popup && rads.popup.html) ? rads.popup.html : (s.ad_popup_text || ''),
    // v0.99.73（第81轮）：广告总开关统一语义——平台推送（rads 有内容）只是广告内容来源，
    // 本地 ad_enabled 开关为最终裁决（专业版可关闭、免费版默认开、演示默认关可自行打开）；
    // 修复原逻辑 rads 有值时恒为 '1' 导致专业版/演示关闭广告开关后返回首页仍显示广告的共性 BUG
    ad_remote_url: s.ad_remote_url || '', ad_enabled: rads ? (String(s.ad_enabled) === '0' ? '0' : '1') : (DEMO ? (s.ad_enabled === '1' ? '1' : '0') : (s.ad_enabled === undefined || s.ad_enabled === '1' ? '1' : '0')),
    // ② 常用搜索下方文字广告（v0.99.30 起客户端首页不再展示，保留字段兼容存量数据）
    ad_text_rows: ((rads && rads.textRows) && Array.isArray(rads.textRows) && rads.textRows.length) ? rads.textRows.slice(0, 4) : (parseAdTextRows(s.ad_text_rows).length ? parseAdTextRows(s.ad_text_rows).slice(0, 4) : parseAdTextRows(s.ad_cols).slice(0, 4)),
    // 分类导航区域之间：1 行 × 5 列 × 5 个分类间隔（v0.99.30 起支持 25 条独立配置：第 k 间隔取第 k*5+1~k*5+5 条）
    ad_between: ((rads && rads.betweenRows) && Array.isArray(rads.betweenRows) && rads.betweenRows.length) ? rads.betweenRows.slice(0, 25) : parseAdTextRows(s.ad_between).slice(0, 25),
    // 站内通知下方一行四列图片广告（远端 slots.imgCols 优先，本地 ad_img_cols 兜底）
    ad_img_cols: ((rads && rads.imgCols) && Array.isArray(rads.imgCols) && rads.imgCols.length) ? rads.imgCols : (parseAdCols(s.ad_img_cols)),
    // 首页底部整条图片 + HTML + 超链接广告（远端 slots.footer 优先）
    ad_footer_enabled: (rads && rads.footer) ? ((rads.footer.image || rads.footer.html) ? '1' : '0') : (s.ad_footer_enabled || '0'),
    ad_footer_image: (rads && rads.footer && rads.footer.image) || s.ad_footer_image || '',
    ad_footer_link: (rads && rads.footer && rads.footer.link) || s.ad_footer_link || '',
    ad_footer_html: (rads && rads.footer && rads.footer.html) || s.ad_footer_html || '',
    // 站内购买收款码（远端 payQr 优先）与站内搜索默认地址（远端 siteSearchUrl 优先，客户端不可编辑）
    pay_qrcode: ((rc && rc.payQr) ? rc.payQr : '') || s.pay_qrcode || '',
    // R183：支付渠道开关，来自云端 /remote/config 的 payChannels。购买弹窗据此**只渲染后台开着的渠道**。
    // 注意这里是运行时算出来的字段，不是 DB 里的设置项（/api/admin/settings 读写的是 getSettings()，两者不串）。
    // 云端老版本没有这个字段时按「人工」兜底：至少让人能付款，不会出现一个渠道都没有的死界面。
    pay_channels: (rc && rc.payChannels)
      ? { alipay: !!rc.payChannels.alipay, wechat: !!rc.payChannels.wechat, manual: rc.payChannels.manual !== false }
      : { alipay: false, wechat: false, manual: true },
    site_search_url: ((rc && rc.siteSearchUrl) ? rc.siteSearchUrl : '') || s.site_search_url || 'https://nav.ediy.net',
    logo: s.logo || ''   // 全站 LOGO（data URI / URL；空=默认 LOGO）
  };
}
function parseAdTextTop(raw) {
  if (!raw) return '';
  // 兼容已存为 JSON 字符串的对象（{t,url,color,bold,italic,startAt,endAt}）
  if (typeof raw === 'string' && /^\s*\{/.test(raw)) {
    try {
      const o = JSON.parse(raw);
      return (o && typeof o === 'object' && o.t) ? { t: String(o.t), url: String(o.url || ''), color: String(o.color || ''), bold: o.bold ? 1 : 0, italic: o.italic ? 1 : 0, startAt: o.startAt || 0, endAt: o.endAt || 0 } : '';
    } catch (e) { /* fallthrough */ }
  }
  if (typeof raw === 'string') return { t: raw, url: '', color: '', bold: 0, italic: 0 };
  if (raw && typeof raw === 'object' && raw.t) {
    return { t: String(raw.t), url: String(raw.url || ''), color: String(raw.color || ''), bold: raw.bold ? 1 : 0, italic: raw.italic ? 1 : 0, startAt: raw.startAt || 0, endAt: raw.endAt || 0 };
  }
  return '';
}
function parseAdCols(raw) {
  if (!raw) return [];
  try {
    const arr = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!Array.isArray(arr)) return [];
    // 最多 4 列，每列可为「文字列 title+lines（≤2 行：{t,url,color,bold,italic} 或字符串）」或「图片列 image+link+title」
    return arr.slice(0, 4).map((c) => {
      if (c.image || c.html) {
        return { title: String(c.title || ''), image: String(c.image || ''), link: String(c.link || ''), html: String(c.html || ''), startAt: c.startAt || 0, endAt: c.endAt || 0 };
      }
      const lines = Array.isArray(c.lines) ? c.lines.slice(0, 2).map((l) => {
        if (typeof l === 'string') return { t: l, url: '', color: '', bold: 0, italic: 0 };
        return { t: String(l.t || ''), url: String(l.url || ''), color: String(l.color || ''), bold: l.bold ? 1 : 0, italic: l.italic ? 1 : 0 };
      }) : [];
      return { title: String(c.title || ''), lines, startAt: c.startAt || 0, endAt: c.endAt || 0 };
    });
  } catch (e) { return []; }
}
// 常用搜索下方三行文字广告：兼容旧 2×4 文字列结构（每列取第 1 行，最多 3 行）与新 textRows 结构
function parseAdTextRows(raw) {
  if (!raw) return [];
  try {
    const arr = typeof raw === 'string' ? JSON.parse(raw) : raw;
    if (!Array.isArray(arr)) return [];
    const rows = arr.map((c) => {
      if (c && Array.isArray(c.lines) && c.lines.length) {
        const l = c.lines[0];
        if (typeof l === 'string') { const p = l.split('|'); return { t: p[0], url: p[1] || '', color: '', bold: 0, italic: 0 }; }
        return { t: String(l.t || ''), url: String(l.url || ''), color: String(l.color || ''), bold: l.bold ? 1 : 0, italic: l.italic ? 1 : 0 };
      }
      if (c && c.t) {
        if (typeof c.t === 'string' && c.t.indexOf('|') >= 0) { const p = c.t.split('|'); return { t: p[0], url: p[1] || '', color: '', bold: 0, italic: 0 }; }
        return { t: String(c.t), url: String(c.url || ''), color: String(c.color || ''), bold: c.bold ? 1 : 0, italic: c.italic ? 1 : 0 };
      }
      return null;
    }).filter(Boolean);
    return rows;
  } catch (e) { return []; }
}

// ---------- App ----------
const app = express();
// ---------- R133-B7：async 路由异常全局兜底 ----------
// 事故背景（审计 B-7）：Express 4 不捕获 async handler 的 rejected promise，而 Node ≥22 默认
// unhandledRejections=throw ⇒ 任一 async 路由里一个未 catch 的 await 失败（例如脏数据 JSON.parse）
// 就会打挂整个进程、全站 502。全库 19+ 处 async 路由此前没有任何 try/catch。
// 做法：在注册任何路由之前包装 app.get/post/put/patch/delete/all——凡声明为 async 的 handler，
// 自动 try/catch 同步部分 + .catch(next) 收异步部分，统一交给文件末尾的 4 参错误中间件。
['get', 'post', 'put', 'patch', 'delete', 'all'].forEach((m) => {
  const orig = app[m].bind(app);
  app[m] = function (path, ...handlers) {
    const wrapped = handlers.map((h) => {
      if (typeof h !== 'function') return h;
      const isAsync = h[Symbol.toStringTag] === 'AsyncFunction' || (h.constructor && h.constructor.name === 'AsyncFunction');
      if (!isAsync) return h;
      return function (req, res, next) {
        try {
          const r = h(req, res, next);
          if (r && typeof r.then === 'function') r.catch(next);
        } catch (e) { next(e); }
      };
    });
    return orig(path, ...wrapped);
  };
});
app.disable('x-powered-by');
app.use(express.json({ limit: '80mb' }));
app.use(cookieParser);

// R126（审计 R-E3）：统一响应出口 res.ok/res.fail + async 路由错误兜底——
// 异步路由抛错一律走统一错误中间件（底部），不再出现裸 Promise rejection 吞错/白屏
const asyncRoute = (fn) => (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
app.use((req, res, next) => {
  res.ok = (data, code) => res.status(code || 200).json(Object.assign({ ok: true }, data));
  res.fail = (error, code) => res.status(code || 400).json({ ok: false, error: error || '操作失败' });
  next();
});

// v0.99.57：在线演示模式（DEMO=1）——全功能可写试用，数据落在临时数据目录，重启即还原（以临时目录隔离替代只读拦截，
// 潜在客户可完整测试登录、管理后台与增删改，任何修改不持久、不污染正式数据）
if (DEMO) {
  // v0.99.72：演示环境广告开关出厂默认「关闭」（潜在客户可自行在管理后台打开广告并返回首页测试效果；
  // 免费版「默认开启但置灰」的规则仅适用于正式客户端，演示环境不套用）
  try { if (String(getSetting('ad_enabled') || '1') !== '0') setSetting('ad_enabled', '0'); } catch (e) {}
  // v0.99.54：在线演示挂载于产品主页 /demo/ 子路径（https://nav.ediy.net/demo/）——剥除前缀交给现有路由（'/demo' 共 5 字符）
  app.use((req, res, next) => {
    if (req.url.indexOf('/demo') === 0) {
      req.url = req.url.slice(5);
      if (req.url === '' || req.url === '/') req.url = '/';
    }
    next();
  });
}

// 静态：前端
app.use(express.static(PUBLIC_DIR, {
  index: 'index.html',
  maxAge: '1h',
  setHeaders(res, filePath) {
    // R94-1：入口文档每次回源校验（no-cache）——避免 HTML 被强缓存 1 小时后，
    // 用户回访仍拿到旧 HTML（旧 ?v= 资源戳），导致「改了看不到效果」；
    // 带 ?v= 指纹的 js/css/图片保留长缓存（maxAge 1h）
    if (/[\\/]index\.html$/.test(filePath) || /[\\/]\.html$/.test(filePath)) {
      res.setHeader('Cache-Control', 'no-cache');
    }
  },
}));
// 静态：自动拉取图标 / 图库
app.get('/api/icons/file/:dir/:filename', (req, res) => {
  const { dir, filename } = req.params;
  if (dir === 'auto') return serveIcon(req, res, filename, ICON_AUTO_DIR, false);
  if (dir === 'library') return serveIcon(req, res, filename, ICON_LIB_DIR, true);
  if (dir === 'upload') return serveIcon(req, res, filename, ICON_UPLOAD_DIR, true);
  res.status(404).end();
});

// ---------- 公共接口 ----------
app.get('/api/health', (req, res) => res.json({ ok: true, name: APP_NAME, version: APP_VERSION, demo: DEMO, time: new Date().toISOString() }));
app.get('/api/about', (req, res) => {
  // v0.99.47：版本日志规则——测试版不记录，仅正式版（≥v1.0.0）写入并展示
  const logs = isFormalVersion(APP_VERSION)
    ? db.prepare('SELECT version, log, date, created_at FROM version_log ORDER BY id DESC').all()
    : [];
  // 版权默认全局固定（EDIY 工作室 + nav.ediy.net）；远端配置可覆盖推送
  const s = getSettings();
  const rc = lic.cached();
  const dev = {
    wechat: ((rc && rc.devInfo) ? rc.devInfo.wechat : '') || s.dev_wechat || APP_DEV.wechat,
    email: ((rc && rc.devInfo) ? rc.devInfo.email : '') || s.dev_email || APP_DEV.email,
    // R183：同上，官网一律归一（产品页地址当未配置处理，回落工作室主站）
    home: devSite((rc && rc.devInfo) ? (rc.devInfo.home || rc.devInfo.site) : '') || devSite(s.dev_home) || APP_SITE,
    qqGroup: ((rc && rc.devInfo) ? rc.devInfo.qqGroup : '') || s.dev_qq_group || APP_DEV.qqGroup,
    qqGroups: (((rc && rc.devInfo && rc.devInfo.qqGroups) ? rc.devInfo.qqGroups : []) || []).length
      ? rc.devInfo.qqGroups : [s.dev_qq_group || APP_DEV.qqGroup].filter(Boolean)
  };
  res.json({ name: APP_NAME, version: APP_VERSION, build: APP_BUILD, home: APP_HOME, email: APP_EMAIL,
    copyright: (rc && rc.copyright) || APP_COPYRIGHT, intro: getSetting('intro'), about_text: getSetting('about_text'), logs, dev });
});
app.get('/api/version', (req, res) => res.json({ name: APP_NAME, version: APP_VERSION, build: APP_BUILD }));
// R153（A1 · 产品方 2026-10-27 裁决「同意」）：部署实例元信息，仅超管可读。
// 为什么必须能在界面上看到：TSN_INSTANCE_SLOT 此前只出现在启动日志与 compose 注释里，
// 运维不看日志就不知道自己这套是 main 还是 test；装第二套时两套都留默认值 ⇒ 标识相同 ⇒ 云端判成同一套。
// 这里只读、不含任何密钥：标识 / 槽位 / 本机已知部署套数 / 盐来源 / 自检提示。
app.get('/api/admin/instance', requireSuper, (req, res) => {
  try {
    const m = lic.instanceMeta();
    res.json({
      ok: true, instanceId: m.instanceId, slot: m.slot, saltSource: m.saltSource,
      deployments: Array.isArray(m.slots) ? m.slots.length : 1,
      slots: (m.slots || []).map(s => ({ slot: s.slot || '(未命名)', current: !!s.current })),
      warnings: lic.instanceWarnings()
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: '实例信息读取失败：' + (e.message || e) });
  }
});
// 授权状态（首页徽标 / 免费配额 / 版本信息；游客可读）
// R133-B1：该接口游客可读（首页徽标依赖 licensed/tier），但**激活码与绑定账号是钱的凭证**，
// 只允许已登录的超管看到真值，其余一律脱敏——此前 `licenseId` 直接回明文，公网匿名 curl 即可拿到。
app.get('/api/license/status', (req, res) => {
  const rc = lic.cached() || {};
  // v0.99.44：附带云端裁决状态（valid/expired/revoked/missing/none），管理后台授权页可展示「待核验」等提示
  const remoteLicStatus = rc.licStatus || '';
  // v0.99.73（第81轮）：附带账号历史授权（授权时间/激活码/到期时间），供授权订阅页展示与复制
  const licenseHistory = Array.isArray(rc.licHistory) ? rc.licHistory : [];
  const st = lic.state();
  // R133-B1：脱敏口径——保留「有/无」与前后各 4 位，中间打码；邮箱保留首字符与域名
  const maskKey = (v) => { const s = String(v || ''); return s.length <= 8 ? (s ? '••••' : '') : s.slice(0, 4) + '••••' + s.slice(-4); };
  const maskMail = (v) => { const s = String(v || ''); const at = s.indexOf('@'); return at > 0 ? s[0] + '•••' + s.slice(at) : (s ? '•••' : ''); };
  const me = getUserFromReq(req);
  const privileged = !!(me && me.role === 'superadmin');
  // R178：本地仍留有激活码但当前不是专业版（典型：云端判定「绑定设备不符」自动降级）时，
  // 把激活码单独带出来——否则解绑迁移表单预填为空，用户既不知道原因也没法自助换机。
  // 该字段只给超管，游客与普通管理员拿不到（脱敏口径与 licenseId 一致）。
  if (privileged) st.savedLicenseId = String(getSetting('license_key') || '');
  else st.savedLicenseId = maskKey(getSetting('license_key') || '');
  let outHistory;
  if (privileged) {
    outHistory = licenseHistory;
  } else {
    st.licenseId = maskKey(st.licenseId);
    st.boundAccount = maskMail(st.boundAccount);
    outHistory = licenseHistory.map((x) => Object.assign({}, x, {
      key: maskKey(x.key || x.licenseKey || x.code), licenseKey: maskKey(x.licenseKey || x.key || x.code),
      code: maskKey(x.code || x.key || x.licenseKey), account: maskMail(x.account || x.boundAccount)
    }));
  }
  res.json({ ok: true, ...st, remoteLicStatus, licenseHistory: outHistory, quota: {
    sites: lic.quotaDesc('sites'), groups: lic.quotaDesc('groups'), users: lic.quotaDesc('users')
  } });
});
// 激活授权：在线权威核验（远端 /api/v1/activate 绑定管理员账号防倒卖；v0.99.72 起不再离线回退，纯断网无法激活）
// R103C：激活仅超级管理员可操作；绑定账号=激活时超管邮箱（强绑定，激活后不可更改）
app.post('/api/license/activate', requireSuper, async (req, res) => {
  const key = ((req.body || {}).key || '').trim();
  const account = String(((req.body || {}).account || '').trim() || req.user.email || '').trim().toLowerCase();
  if (!key) return res.status(400).json({ ok: false, error: '请输入激活码' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(account)) return res.status(400).json({ ok: false, error: '绑定账号需为有效邮箱（超级管理员邮箱）' });
  if (account !== String(req.user.email || '').trim().toLowerCase()) return res.status(400).json({ ok: false, error: '绑定账号必须为当前超级管理员邮箱，激活后不可更改' });
  // v0.99.72：演示环境不真正激活（本地已按专业版放行），模拟成功避免误上送云端
  if (DEMO) return res.json(demoMock({ mode: 'demo', licensed: true, ...lic.state(), message: '在线演示环境：已模拟激活，不会绑定任何账号' }));
  const r = await lic.activate({ code: key, account, device: lic.instanceId() });
  if (!r.ok) return res.json(r);
  logOp(req.user, '激活授权', key.slice(0, 8) + '…（在线，绑定 ' + account + '）');
  res.json(r);
});
// 解绑迁移（换机，规格 5.4 防倒卖）：申请——云端校验年度配额/24h 冷却后向绑定邮箱发送验证码
// R103C：解绑迁移仅超级管理员可操作；账号=激活时超管邮箱
app.post('/api/license/transfer/request', requireSuper, async (req, res) => {
  const licenseId = ((req.body || {}).licenseId || '').trim();
  const account = String(((req.body || {}).account || '').trim() || req.user.email || '').trim().toLowerCase();
  if (!licenseId) return res.status(400).json({ ok: false, error: '请输入激活码（授权 ID）' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(account)) return res.status(400).json({ ok: false, error: '绑定账号需为有效邮箱（超级管理员邮箱）' });
  if (account !== String(req.user.email || '').trim().toLowerCase()) return res.status(400).json({ ok: false, error: '解绑迁移仅限激活时绑定的超级管理员本人操作' });
  if (DEMO) return res.json(demoMock({ message: '在线演示环境：已模拟申请解绑迁移（不会真实发送邮箱验证码）' }));
  const r = await lic.transferRequest({ licenseId, account });
  if (!r.ok) return res.json(r);
  logOp(req.user, '申请解绑迁移', licenseId.slice(0, 8) + '…（' + account + '，验证码已发送）');
  res.json(r);
});
// 解绑迁移：确认——邮箱验证码校验通过后解绑旧设备，新设备即可重新激活
app.post('/api/license/transfer/confirm', requireSuper, async (req, res) => {
  const licenseId = ((req.body || {}).licenseId || '').trim();
  const account = String(((req.body || {}).account || '').trim() || req.user.email || '').trim().toLowerCase();
  const code = ((req.body || {}).code || '').trim();
  if (!licenseId) return res.status(400).json({ ok: false, error: '请输入激活码（授权 ID）' });
  if (!code) return res.status(400).json({ ok: false, error: '请输入邮箱验证码' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(account)) return res.status(400).json({ ok: false, error: '绑定账号需为有效邮箱（超级管理员邮箱）' });
  if (account !== String(req.user.email || '').trim().toLowerCase()) return res.status(400).json({ ok: false, error: '解绑迁移仅限激活时绑定的超级管理员本人操作' });
  if (DEMO) return res.json(demoMock({ message: '在线演示环境：已模拟解绑旧设备' }));
  const r = await lic.transferConfirm({ licenseId, account, code });
  if (!r.ok) return res.json(r);
  logOp(req.user, '确认解绑迁移', licenseId.slice(0, 8) + '…（' + account + '，旧设备已解绑）');
  res.json(r);
});
// 远端服务配置：保存地址（兼容历史公钥字段），并立即测试连接（R103C：仅超管）
app.post('/api/license/remote', requireSuper, async (req, res) => {
  // v0.99.72：演示环境远端服务由平台统一托管，客户端不保存配置（也不允许改动），模拟成功即可
  if (DEMO) return res.json(demoMock({ tested: true, remote: '', message: '在线演示环境：远端服务由平台统一管理，无需配置' }));
  const b = req.body || {};
  const base = String(b.remote_base || '').trim().replace(/\/+$/, '');
  if (!base) return res.status(400).json({ ok: false, error: '远端服务地址必填（如 https://nav.ediy.net）' });
  if (!/^https?:\/\//i.test(base)) return res.status(400).json({ ok: false, error: '远端地址需以 http(s):// 开头' });
  setSetting('remote_base', base);
  // 远端公钥由服务器端统一推送（历史离线激活兼容保留；当前激活统一走服务器在线核验，客户端管理后台不暴露编辑）
  if (b.remote_pubkey !== undefined) setSetting('remote_pubkey', String(b.remote_pubkey).trim());
  const t = await lic.pullRemote();
  logOp(req.user, '配置远端服务', base + (t.ok ? '（连接成功）' : '（连接失败：' + t.error + '）'));
  res.json({ ok: true, tested: t.ok, test_error: t.ok ? '' : t.error, remote: lic.state().remoteBase, data: t.data || null });
});
// 拉取远端配置（首页公告 / 开发者信息 / 远端广告，供前端随时刷新）
// v0.99.38：支持 ?refresh=1 强制拉取云端最新配置（授权订阅页每次打开即刷新，避免只读本地缓存导致面板改价不显示）
app.get('/api/remote/config', async (req, res) => {
  if (String(req.query.refresh) === '1') {
    const t = await lic.pullRemote();
    return res.json({ ok: true, data: lic.cached(), remoteBase: lic.remoteBase(), refreshed: t.ok, remoteError: t.ok ? '' : t.error });
  }
  res.json({ ok: true, data: lic.cached(), remoteBase: lic.remoteBase() });
});
// 系统通知：开发者通过服务器端全站推送；客户端代理拉取并做 30 秒缓存（发布后最多 30 秒客户端可见，v0.99.41 由 60s 缩短）
let sysNoticesCache = { ts: 0, list: [] };
app.get('/api/system-notices', async (req, res) => {
  if (Date.now() - sysNoticesCache.ts < 30 * 1000) return res.json({ ok: true, list: sysNoticesCache.list });
  const r = await lic.fetchSystemNotices();
  if (r.ok) { sysNoticesCache = { ts: Date.now(), list: r.list }; return res.json({ ok: true, list: r.list }); }
  return res.json({ ok: true, list: sysNoticesCache.list, remoteError: r.error || '远端不可达' });
});
// 测试远端连接（不保存地址；地址由服务器端统一维护，客户端仅用于连通性检查）（R103C：仅超管）
app.get('/api/license/remote/test', requireSuper, async (req, res) => {
  // v0.99.72：演示环境连接测试本地模拟（远端地址已全局置空）
  if (DEMO) return res.json(demoMock({ tested: true, remote: '', message: '在线演示环境：远端服务连接正常（模拟）' }));
  const base = lic.remoteBase();
  if (!base) return res.json({ ok: false, error: '远程服务未就绪' });
  const t = await lic.pullRemote();
  res.json({ ok: true, tested: t.ok, test_error: t.ok ? '' : t.error, remote: base, data: t.data || null });
});
// 站内购买：下单（tier=year|tri|lifetime，account 购买时填写并绑定，激活后不可更改；qty=购买份数，1-99，每份独立计算到期）
// R103C：站内购买仅超级管理员可操作；绑定账号=超管邮箱
app.post('/api/license/order/create', requireSuper, async (req, res) => {
  const b = req.body || {};
  const tier = String(b.tier || '').trim();
  const account = String(b.account || '').trim().toLowerCase() || String(req.user.email || '').trim().toLowerCase();
  const qty = Math.max(1, Math.min(99, parseInt(b.qty, 10) || 1));
  if (!['year', 'tri', 'lifetime'].includes(tier)) return res.status(400).json({ ok: false, error: '无效的订阅档位' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(account)) return res.status(400).json({ ok: false, error: '请输入正确的绑定账号邮箱' });
  if (account !== String(req.user.email || '').trim().toLowerCase()) return res.status(400).json({ ok: false, error: '购买绑定账号必须为当前超级管理员邮箱' });
  // v0.99.72：演示环境站内购买本地模拟——流程完整可体验，但不在线上产生任何订单
  if (DEMO) {
    const pricing = lic.cachedPricing() || {};
    const unit = (pricing[tier] || {}).price || (tier === 'year' ? 19.9 : tier === 'tri' ? 29.9 : 39.9);
    return res.json(demoMock({ orderId: 'DEMO' + Date.now(), tier, account, qty, amount: +(unit * qty).toFixed(2), status: 'paid', message: '在线演示环境：模拟下单成功（不会真实扣款，也不会在服务器端产生订单）' }));
  }
  // R183：透传客户端选择的支付渠道（后台没开的渠道云端会忽略，回落旧逻辑）
  const r = await lic.createRemoteOrder(tier, account, qty, b.ref, b.channel);
  if (r.ok) logOp(req.user, '购买订阅', '下单 ' + tier + ' ×' + qty + '，绑定账号 ' + account);
  res.json(r);
});
// 站内购买：提交付款核对（流水号）（R103C：仅超管）
// R125：透传绑定账号 account 至云端（云端 /pay/verify 已加归属校验）
app.post('/api/license/order/verify', requireSuper, async (req, res) => {
  const b = req.body || {};
  const orderId = String(b.orderId || '').trim();
  const tradeNo = String(b.tradeNo || '').trim();
  if (!orderId || !tradeNo) return res.status(400).json({ ok: false, error: '订单号与付款流水号必填' });
  if (DEMO) return res.json(demoMock({ orderId, status: 'paid', message: '在线演示环境：模拟到账核对成功' }));
  const r = await lic.verifyRemoteOrder(orderId, tradeNo, String(b.account || '').trim());
  if (r.ok) logOp(req.user, '购买订阅', '提交付款核对 ' + orderId);
  res.json(r);
});
// 站内购买：查询订单状态（paid 后返回激活码）（R103C：仅超管）
// R125：透传绑定账号 account 至云端（云端 /pay/query 已加归属校验）
app.get('/api/license/order/query', requireSuper, async (req, res) => {
  const orderId = String(req.query.orderId || '').trim();
  if (!orderId) return res.status(400).json({ ok: false, error: '订单号必填' });
  if (DEMO) return res.json(demoMock({ orderId, status: 'paid', codes: ['TSN-DEMO' + String(Date.now()).slice(-3) + '-Y' + String(Date.now()).slice(-6) + '-' + String(Date.now()).slice(-6)], message: '在线演示环境：模拟订单已发码（激活码仅演示，不可真实使用）' }));
  // R126（R113-B3 客户端适配）：查询凭证从本地订单表取出透传云端——云端 /pay/query 已升级为
  // 必须携带下单时返回的一次性 queryToken（仅凭 orderNo+account 不可查）
  const local = db.prepare('SELECT query_token FROM orders WHERE order_no = ?').get(orderId);
  const qt = (local && local.query_token) || String(req.query.queryToken || '').trim();
  res.json(await lic.queryRemoteOrder(orderId, String(req.query.account || '').trim(), qt));
});
// R114/R102 推广返利（云端推广中心代理）
// R102-B1：云端推广接口已改为 OTP 令牌鉴权——客户端代理层透传前端 promo-token 为 Bearer，
// 账号由云端从令牌取（参数 account 一律忽略）；otp/request 邮箱取当前超管邮箱（服务端填写，不信任前端）
const promoAuthHeaders = (req) => {
  const t = String(req.headers['promo-token'] || req.headers['x-promo-token'] || '').trim();
  return t ? { 'Content-Type': 'application/json', Authorization: 'Bearer ' + t } : { 'Content-Type': 'application/json' };
};
app.get('/api/license/promo/summary', requireSuper, async (req, res) => {
  if (DEMO) return res.json(demoMock({ enabled: false, code: '', linkUrl: '', isPromoter: false, total: 0, settled: 0, available: 0, orders: [], payouts: [], needGenerate: true, message: '在线演示环境：推广返利仅正式环境可用' }));
  const r = await lic.promoRemote('/api/v1/promo/summary', { headers: promoAuthHeaders(req) });
  res.json(r.ok ? r.data : { ok: false, error: r.error || '推广中心加载失败', status: r.status, code: (r.data || {}).code });
});
app.post('/api/license/promo/apply', requireSuper, async (req, res) => {
  if (DEMO) return res.json(demoMock({ ok: false, message: '在线演示环境：不可申请提现' }));
  const b = req.body || {};
  const r = await lic.promoRemote('/api/v1/promo/apply', { method: 'POST', headers: promoAuthHeaders(req), body: JSON.stringify({ amount: b.amount, channel: b.channel, payee: b.payee, note: b.note }) });
  res.json(r.ok ? r.data : { ok: false, error: r.error || '提现申请失败', status: r.status, code: (r.data || {}).code });
});
app.post('/api/license/promo/otp/request', requireSuper, async (req, res) => {
  if (DEMO) return res.json(demoMock({ ok: false, message: '在线演示环境：推广返利仅正式环境可用' }));
  const email = String(req.user.email || '').trim().toLowerCase();
  if (!email) return res.json({ ok: false, error: '当前账号无邮箱，无法完成推广身份验证' });
  const r = await lic.promoRemote('/api/v1/promo/otp/request', { method: 'POST', body: JSON.stringify({ email }) });
  res.json(r.ok ? r.data : { ok: false, error: r.error || '验证码发送失败', status: r.status });
});
app.post('/api/license/promo/otp/verify', requireSuper, async (req, res) => {
  if (DEMO) return res.json(demoMock({ ok: false, message: '在线演示环境：推广返利仅正式环境可用' }));
  const email = String(req.user.email || '').trim().toLowerCase();
  const code = String(((req.body || {}).code) || '').trim();
  const r = await lic.promoRemote('/api/v1/promo/otp/verify', { method: 'POST', body: JSON.stringify({ email, code }) });
  res.json(r.ok ? r.data : { ok: false, error: r.error || '验证失败', status: r.status });
});
app.post('/api/license/promo/code', requireSuper, async (req, res) => {
  if (DEMO) return res.json(demoMock({ ok: false, message: '在线演示环境：推广返利仅正式环境可用' }));
  const r = await lic.promoRemote('/api/v1/promo/code', { method: 'POST', headers: promoAuthHeaders(req) });
  res.json(r.ok ? r.data : { ok: false, error: r.error || '生成失败', status: r.status });
});
// 清除本地授权（管理员密码二次验证）（R103C：仅超管——解除授权=解绑本机授权绑定）
app.post('/api/license/clear', requireSuper, (req, res) => {  const pwd = ((req.body || {}).password || '').trim();
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const ok = u && pwd && crypto.scryptSync(pwd, u.salt, 64).toString('hex') === u.password_hash;
  if (!ok) return res.status(403).json({ ok: false, error: '管理员密码验证失败，已取消' });
  const st = lic.clearLocal();
  logOp(req.user, '清除本地授权', '已解除激活（如需换机请先在「授权订阅-解绑迁移」申请，验证邮箱后即可在新设备激活）');
  res.json({ ok: true, ...st });
});
// ---------- 本机订单持久化（DB 落库） ----------
// 用途：站内购买订单同时写入本地数据库，跨浏览器/清缓存后「我的订单」仍可见；
// 远端订单状态仍以 /api/license/order/query 为准，本接口仅做本地记录兜底。
app.get('/api/orders', requirePerm('orders'), (req, res) => {
  try {
    const rows = db.prepare('SELECT * FROM orders ORDER BY created_at DESC').all();
    res.json({ ok: true, orders: rows });
  } catch (e) { res.status(500).json({ ok: false, error: '读取订单失败' }); }
});
app.post('/api/orders', requirePerm('orders'), (req, res) => {
  try {
    const b = req.body || {};
    const orderNo = String(b.orderNo || '').trim();
    if (!orderNo) return res.status(400).json({ ok: false, error: '订单号必填' });
    const row = {
      order_no: orderNo,
      tier: String(b.tier || 'year'),
      label: String(b.label || ''),
      qty: parseInt(b.qty, 10) || 1,
      amount: String(b.amount || ''),
      account: String(b.account || ''),
      status: String(b.status || 'pending'),
      code: String(b.code || ''),
      queryToken: String(b.queryToken || '')   // R126（R113-B3）：一次性查询凭证本地落库，查询时透传云端
    };
    // 注意：row 不得包含 SQL 中未绑定为命名参数的键（node:sqlite run(obj) 对多余键报 Unknown named parameter）
    // created_at / updated_at 在 VALUES 与 ON CONFLICT 中直接使用 datetime() 函数，不入 row
    db.prepare(`INSERT INTO orders (order_no, tier, label, qty, amount, account, status, code, query_token, created_at, updated_at)
      VALUES (@order_no, @tier, @label, @qty, @amount, @account, @status, @code, @queryToken, datetime('now','localtime'), datetime('now','localtime'))
      ON CONFLICT(order_no) DO UPDATE SET
        tier=excluded.tier, label=excluded.label, qty=excluded.qty, amount=excluded.amount,
        account=excluded.account, status=excluded.status, code=excluded.code, query_token=excluded.query_token,
        updated_at=excluded.updated_at`).run(row);
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ ok: false, error: '保存订单失败' }); }
});
app.delete('/api/orders/:orderNo', requirePerm('orders'), (req, res) => {
  try {
    db.prepare('DELETE FROM orders WHERE order_no = ?').run(String(req.params.orderNo || '').trim());
    res.json({ ok: true });
  } catch (e) { res.status(500).json({ ok: false, error: '删除订单失败' }); }
});
// v0.99.38：远端配置节流刷新（>60s 未拉取则后台刷新，等待≤2.5s），
// 系统通知/定价/授权裁决等不依赖重启或手动「测试连接」即可自动同步云端最新设置。
// /api/settings/public 与 /api/nav 共用同一节流（P2：系统通知客户端首页即时可见）
let lastPubSettingsRefresh = 0;
// v0.99.72：在线演示（DEMO=1）单独只读拉取线上广告配置——平台「广告总开关/广告内容」
// 对演示首页即时生效（≤30s 送达）；仅 GET 公开只读配置接口，不触心跳/授权/写操作，
// 全局防线（license.js remoteBase 在 DEMO 下为空）保持不变。
let lastDemoAdsRefresh = 0;
let demoAdsCache = null;
async function maybeRefreshDemoAds() {
  if (!DEMO) return;
  if (Date.now() - lastDemoAdsRefresh > 30 * 1000) {
    lastDemoAdsRefresh = Date.now();
    try {
      const ctl = new AbortController();
      const tm = setTimeout(() => ctl.abort(), 2500);
      const r = await fetch(APP_HOME + '/api/v1/remote/config', { signal: ctl.signal });
      clearTimeout(tm);
      const j = await r.json().catch(() => ({}));
      if (j && j.ok && j.data && j.data.ads) demoAdsCache = j.data.ads;
    } catch (e) {}
  }
}
async function maybeRefreshRemote() {
  // v0.99.41：节流窗口 60s→30s，配合 30s 心跳，云端修改 ≤30s 送达
  if (Date.now() - lastPubSettingsRefresh > 30 * 1000) {
    lastPubSettingsRefresh = Date.now();
    try {
      // v0.99.72：演示环境仅拉取公开广告配置（远端授权/定价等在本机演示无意义且不应打扰线上）
      if (DEMO) { await maybeRefreshDemoAds(); return; }
      await Promise.race([lic.pullRemote(), new Promise((r) => setTimeout(r, 2500))]);
    } catch (e) {}
  }
}
app.get('/api/settings/public', async (req, res) => {
  await maybeRefreshRemote();
  res.json({ ok: true, ...publicSettings() });
});

// 访客导航（只读）
app.get('/api/public/nav', (req, res) => {
  if (publicSettings().allow_guest !== '1') return res.status(403).json({ ok: false, error: '访客浏览未开放，请登录' });
  const mode = detectMode(req);
  // 访客不可见「管理员专属」分组
  const groups = db.prepare('SELECT * FROM groups WHERE admin_only = 0 ORDER BY sort ASC, id ASC').all();
  const sites = db.prepare('SELECT * FROM sites WHERE status = ? AND visibility = ? ORDER BY sort ASC, id ASC').all('active', 'public');
  res.json({ ok: true, mode, mode_manual: req.cookies.ts_mode || 'auto',
    groups: groups.map((g) => ({ id: g.id, name: g.name, icon: g.icon, sort: g.sort, scene: g.scene || '', show_in_nav: g.show_in_nav === undefined ? 1 : g.show_in_nav, is_recommend: g.is_recommend === undefined ? 0 : g.is_recommend, admin_only: g.admin_only === undefined ? 0 : g.admin_only })),
    sites: sites.map((s) => ({
      id: s.id, group_id: s.group_id, name: s.name, icon_type: s.icon_type, icon_ref: s.icon_ref, icon_auto: s.icon_auto,
      url: mode === 'intranet' ? (s.intranet_url || s.extranet_url) : (s.extranet_url || s.intranet_url), open_mode: s.open_mode, remark: s.remark || '',
      net_flag: s.net_flag || 'auto', net_flag_val: s.net_flag_val || siteNetVal(s.intranet_url, s.extranet_url)
    })), settings: publicSettings() });
});

// ---------- 认证 ----------
app.post('/api/auth/send-code', async (req, res) => {
  const { email, scene } = req.body || {};
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ ok: false, error: '邮箱格式不正确' });
  const s = scene === 'forgot' ? 'forgot' : 'register';
  // v0.99.72（O-C）：忘记密码场景不再区分「未注册/已注册」提示——统一成功文案，
  // 杜绝通过响应差异枚举已注册邮箱；未注册邮箱不实际发信、不产生 SMTP 负载。
  if (s === 'forgot') {
    const u = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (!u) {
      // 未注册邮箱提前返回也计入 IP 限频（跨邮箱合并计数，防批量探测/邮件轰炸）
      const ip = reqIp(req);
      const ipKey = `${ip || 'unknown'}|forgot`;
      const now = Date.now();
      const ipRec = codeIpRate.get(ipKey);
      if (ipRec && ipRec.resetAt > now) {
        if (ipRec.cnt >= 5) return res.status(429).json({ ok: false, error: '发送过于频繁，请 1 分钟后再试' });
        ipRec.cnt += 1;
      } else {
        codeIpRate.set(ipKey, { cnt: 1, resetAt: now + 60 * 1000 });
      }
      return res.json({ ok: true, message: '验证码已发送至邮箱（若该邮箱已注册）' });
    }
  } else {
    if (getSetting('register_open') !== '1') return res.status(403).json({ ok: false, error: '注册未开放' });
    const u = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
    if (u) return res.json({ ok: false, error: '该邮箱已注册' });
    if (getSetting('invite_required') === '1' && !req.body.invite_code) return res.json({ ok: false, error: '当前需要邀请码注册，请先获取邀请码' });
  }
  const r = sendCodeCore(email, s, reqIp(req));
  if (!r.ok) return res.json(r);
  if (getSetting('verify_email') === '1') {
    try {
      await sendMail(email, `【${getSetting('panel_name') || APP_NAME}】验证码 ${r.code}`, `<p>您的验证码为：<b style="font-size:20px">${r.code}</b></p><p>5 分钟内有效，请勿泄露。若非本人操作请忽略。</p>`);
      logOp(null, `发送${s === 'forgot' ? '找回密码' : '注册'}验证码`, maskEmail(email));
      return res.json({ ok: true, message: `验证码已发送至 ${maskEmail(email)}` });
    } catch (e) {
      codeStore.delete(`${email}|${s}`);
      if (e.code === 'SMTP_NOT_CONFIGURED') return res.status(500).json({ ok: false, error: 'SMTP 未配置，请在管理后台设置发信邮箱' });
      return res.status(500).json({ ok: false, error: '邮件发送失败，请检查 SMTP 配置' });
    }
  }
  // 开发模式：验证码直接返回
  return res.json({ ok: true, message: '验证码（未启用邮件校验，直接返回）', dev_code: r.code });
});

app.post('/api/auth/register', (req, res) => {
  // 免费版配额：用户 ≤ 2（含管理员；专业版不限）
  const q = lic.checkQuota('users');
  if (!q.ok) return res.status(403).json({ ok: false, error: `免费版用户数量已达上限（${q.limit} 名，含管理员），请联系管理员升级专业版`, need_pro: true });
  const { email, username, password, code, invite_code } = req.body || {};
  if (getSetting('register_open') !== '1') return res.status(403).json({ ok: false, error: '注册未开放' });
  if (!email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ ok: false, error: '邮箱格式不正确' });
  if (!username || !/^[\u4e00-\u9fa5a-zA-Z0-9_\-]{2,20}$/.test(username)) return res.status(400).json({ ok: false, error: '用户名需 2-20 位中文/字母/数字' });
  if (!password || password.length < 6 || password.length > 64) return res.status(400).json({ ok: false, error: '密码长度需 6-64 位' });
  if (isDefaultPwd(password)) return res.status(400).json({ ok: false, error: '不能设置为默认密码' });
  if (db.prepare('SELECT * FROM users WHERE email = ?').get(email)) return res.status(400).json({ ok: false, error: '该邮箱已注册' });
  if (getSetting('invite_required') === '1') {
    if (!invite_code) return res.status(400).json({ ok: false, error: '当前需要邀请码注册' });
    const inv = db.prepare('SELECT * FROM invite_codes WHERE code = ? AND status = ?').get(invite_code.trim().toUpperCase(), 'active');
    if (!inv || inv.used_count >= inv.max_uses) return res.status(400).json({ ok: false, error: '邀请码无效或已用完' });
  }
  if (getSetting('verify_email') === '1') {
    // R133-B2：统一走 verifyCodeOnce（含次数自增与用尽作废）
    const vc = verifyCodeOnce(email, 'register', code);
    if (!vc.ok) return res.status(400).json({ ok: false, error: vc.error });
  }
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  const info = db.prepare('INSERT INTO users(email, username, password_hash, salt, role, status, pwd_default) VALUES(?, ?, ?, ?, ?, ?, 0)').run(email, username, hash, salt, 'user', 'active');
  if (getSetting('invite_required') === '1') {
    db.prepare('UPDATE invite_codes SET used_count = used_count + 1 WHERE code = ?').run(invite_code.trim().toUpperCase());
  }
  if (getSetting('verify_email') === '1') codeStore.delete(`${email}|register`);
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(info.lastInsertRowid);
  const token = issueToken(user, true);   // R128：注册即长期登录（新用户默认「记住我」，避免注册完 12 小时被踢）
  res.cookie('ts_token', token, cookieOpt(req, tokenTtlMs(true)));   // R133-B9
  logOp({ id: user.id, username: user.username }, '注册', email);
  res.json({ ok: true, token, user: { id: user.id, username: user.username, email, role: user.role, perms: safePerms(user), first_login: !user.last_login_at, must_change: false } });
});

app.post('/api/auth/login', (req, res) => {
  const { email, username, password, remember } = req.body || {};
  const account = String(email || username || '').trim();
  if (!account || !password) return res.status(400).json({ ok: false, error: '请输入账号与密码' });
  // v0.99.72（O-B）：登录锁定维度由「账号」升级为「来源 IP + 账号」——
  // 此前仅按账号计数，攻击者可多源爆破单一账号或对 admin 账号做 DoS（把账号锁死）；
  // 叠加 IP 后，单点爆破最多尝试 maxFail 次即被限频，且不影响其他来源的正常登录。
  const key = reqIp(req) + '|' + account.toLowerCase();
  const fr = failStore.get(key);
  if (fr && fr.lockUntil && Date.now() < fr.lockUntil) {
    const min = Math.ceil((fr.lockUntil - Date.now()) / 60000);
    return res.status(429).json({ ok: false, error: `失败次数过多，账号已锁定，请 ${min} 分钟后再试` });
  }
  // 支持 邮箱 或 用户名 登录（先按邮箱匹配，再按用户名匹配）
  let user = db.prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(?) OR username = ?').get(account, account);
  // R127：连接读空库防呆——磁盘库文件存在但当前连接查到 0 用户（R122 场景：读空库不抛错），
  // 重开连接重查一次，杜绝「账号不存在」误报与登录假失败（根因=旧连接长期读空库，磁盘数据完好）
  // 不做启动豁免：见 getUserFromReq 注释——全新初始化后 seedAdmin 已建管理员，COUNT>0 不会误触发。
  if (!user && reopenIfEmptyDb('登录')) {
    user = db.prepare('SELECT * FROM users WHERE LOWER(email) = LOWER(?) OR username = ?').get(account, account);
  }
  const okUser = user && user.status === 'active';
  const hash = okUser ? crypto.scryptSync(password, user.salt, 64).toString('hex') : '';
  if (!okUser || hash !== user.password_hash) {
    const rec = failStore.get(key) || { fails: 0, lockUntil: 0 };
    rec.fails += 1;
    const maxFail = parseInt(getSetting('login_max_fail') || '5', 10);
    if (rec.fails >= maxFail) {
      rec.lockUntil = Date.now() + parseInt(getSetting('login_lock_minutes') || '15', 10) * 60 * 1000;
      rec.fails = 0;
      failStore.set(key, rec);
      return res.status(429).json({ ok: false, error: `连续失败 ${maxFail} 次，账号已锁定 ${getSetting('login_lock_minutes')} 分钟` });
    }
    failStore.set(key, rec);
    const remain = maxFail - rec.fails;
    return res.status(401).json({ ok: false, error: user ? '密码错误' : '账号不存在', remain });
  }
  failStore.delete(key);
  const oldLast = user.last_login_at;
  // R112：运行时判定密码是否仍为默认——明文等于默认则保持强制引导标志，否则视为已改密
  // R101-B2：pwd_default=1 表示「仍需强制改密」；只允许在用默认密码登录时置 1，
  // 永不在登录时置 0（防止把管理员重置密码写入的 1 冲掉）；置 0 只发生在本人成功改密时。
  // R104-B3 回退：pwd_default 只表达「密码仍为默认」，与邮箱无关——删除「邮箱默认即置 1」的旧判断
  //（旧判断把改密成果冲掉：isDefaultEmail(user.email) 恒真时每次登录都把 pwd_default 打回 1，引导死锁）。
  // 邮箱是否默认由 needGuide() 实时求值，不再写入 pwd_default。
  if (!DEMO && isDefaultPwd(password) && (user.pwd_default || 0) !== 1) {
    userState.setDefaultPwd(db, user.id);   // R126（R-D1）：唯一写入口
    user.pwd_default = 1;
  }
  const mustChangeNow = !DEMO && needGuide(user);
  db.prepare('UPDATE users SET last_login_at = datetime(\'now\',\'localtime\') WHERE id = ?').run(user.id);
  // R128（登录被踢根治）：按用户选择签发。此前此处硬编码 false，导致「记住我」永久失效、12 小时必被踢。
  const remembered = !!remember;
  const token = issueToken(user, remembered);
  // R133-B9：记住我 → cookie 持久化，关浏览器仍有效；secure 由 cookieOpt 按协议自动判定
  res.cookie('ts_token', token, cookieOpt(req, remembered ? tokenTtlMs(true) : 0));
  logOp(user, '登录', user.email);
  // R99-B2：登录响应 email 必须取库中真实邮箱（user.email），而非请求体解构变量——
  // 按用户名登录时请求体无 email 字段，原实现会把 email 置为 undefined，导致首登引导把用户名当邮箱回显、判定非法而卡死。
  res.json({ ok: true, token, user: { id: user.id, username: user.username, email: user.email, role: user.role, perms: safePerms(user), first_login: !oldLast, must_change: mustChangeNow, email_default: isDefaultEmail(user.email), pwd_default: !DEMO && (user.pwd_default || 0) === 1 } });
});

app.post('/api/auth/forgot', (req, res) => {
  const { email, code, newPassword } = req.body || {};
  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!newPassword || newPassword.length < 6 || newPassword.length > 64) return res.status(400).json({ ok: false, error: '新密码长度需 6-64 位' });
  const rec = codeStore.get(`${email}|forgot`);
  // v0.99.72（O-C）：账号不存在与验证码错误统一文案（不区分），杜绝通过 forgot 提交差异枚举已注册邮箱
  if (!user || !rec) return res.status(400).json({ ok: false, error: '验证码错误或已过期' });
  // R133-B2：统一走 verifyCodeOnce（含次数自增与用尽作废）——此前 rec.code 直接比对，tries 永不自增
  const vc = verifyCodeOnce(email, 'forgot', code);
  if (!vc.ok) return res.status(400).json({ ok: false, error: vc.error });
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(newPassword, salt, 64).toString('hex');
  db.prepare('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?').run(hash, salt, user.id);
  userState.clearDefaultPwd(db, user.id);  // R126（R-D1）：唯一写入口（本人设置新密码）
  revokeAllSessions(user.id);              // R126（R-D5）：重置后旧会话全部下线
  codeStore.delete(`${email}|forgot`);
  logOp(user, '重置密码', email);
  res.json({ ok: true, message: '密码已重置，请重新登录' });
});

app.get('/api/auth/me', requireAuth, (req, res) => {
  const user = req.user;
  // R103C：me 返回真实邮箱（本机登录态，供首登引导预填与账号展示；邮箱格式强制）
  // R104-B3：must_change 统一走 needGuide()（密码已改 AND 邮箱非默认才算完成）；附 email_default/pwd_default 供前端按未改项显示引导必填项
  res.json({ ok: true, user: { id: user.id, username: user.username, email: user.email, role: user.role, perms: safePerms(user), first_login: !user.last_login_at, must_change: !DEMO && needGuide(user), email_default: isDefaultEmail(user.email), pwd_default: !DEMO && (user.pwd_default || 0) === 1, view_mode: user.view_mode, favorites: JSON.parse(user.favorites || '[]') } });
});
app.post('/api/auth/logout', (req, res) => {
  // R105-O4：登出即失效——提取当前 token 加入内存失效列表，旧 token 立即 401（与云端 sessions 删除同性质）
  const h = req.headers.authorization || '';
  // R133-B6：不再接受 ?token= 传参（审计 B-6）——token 一旦落进访问日志/浏览器历史/反代日志即等于泄漏凭证。
  // 仅认 Authorization: Bearer 与 httpOnly cookie 两条通道；前端已确认无 query token 依赖。
  const token = h.startsWith('Bearer ') ? h.slice(7) : (req.cookies ? req.cookies.ts_token : null);
  if (token) revokeToken(token);
  res.clearCookie('ts_token');
  res.json({ ok: true });
});
// R103C：首登引导 / 账号资料修改——验证原密码后修改 用户名、邮箱、密码
// 规则：邮箱全局强制邮箱格式；用户名全局唯一；超管邮箱即授权绑定账号（已激活则锁定，换邮箱=换超管，须解绑迁移）
// R112：超管完成初始引导（已改密，pwd_default=0）后用户名/邮箱一律锁定，仅可修改密码；改密禁止设为默认密码
app.post('/api/auth/profile', requireAuth, (req, res) => {
  const u = req.user;
  const { oldPassword, username, email, newPassword } = req.body || {};
  const oldHash = crypto.scryptSync(oldPassword || '', u.salt, 64).toString('hex');
  if (oldHash !== u.password_hash) return res.status(400).json({ ok: false, error: '原密码错误' });
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const NAME_RE = /^[\u4e00-\u9fa5a-zA-Z0-9_\-]{2,20}$/;
  let nextUsername = u.username, nextEmail = u.email, needRehash = false;
  // R104-B3/B4：forceGuide 唯一求值——仅「未激活（非真实 pro 授权）且仍在引导中」生效。
  // ① B3：统一走 needGuide()（改密 AND 改邮箱），不再叠加散落判断；
  // ② B4：已激活（pro）用户 forceGuide=false——已激活超管邮箱=授权绑定账号，不因占位邮箱继续弹引导，
  //    资料锁定恢复（激活后用户名/邮箱不可改，换超管走解绑迁移，迁移流程内允许改邮箱）。
  const licSt0 = lic.state ? lic.state() : null;
  const activated = !!(licSt0 && licSt0.licensed && licSt0.type === 'pro');
  const forceGuide = !activated && !DEMO && needGuide(u);
  // R113/A7：超管资料锁定——已激活（pro）才锁用户名/邮箱，只能改密码；未激活可改资料（解除存量非法邮箱死锁）
  if (superAdminLocked(u) && !forceGuide) {
    const wantUser = username !== undefined && String(username).trim() !== '' && String(username).trim() !== u.username;
    const wantEmail = email !== undefined && String(email).trim() !== '' && String(email).trim().toLowerCase() !== u.email.toLowerCase();
    if (wantUser || wantEmail) return res.status(403).json({ ok: false, error: '超级管理员资料已锁定，仅可修改密码；如需更换超管请先解绑迁移' });
  }
  if (username !== undefined && String(username).trim() !== '' && String(username).trim() !== u.username) {
    const nu = String(username).trim();
    if (!NAME_RE.test(nu)) return res.status(400).json({ ok: false, error: '用户名需 2-20 位中英文、数字、下划线或连字符' });
    const dup = db.prepare('SELECT id FROM users WHERE username = ? AND id <> ?').get(nu, u.id);
    if (dup) return res.status(400).json({ ok: false, error: '用户名已被占用' });
    nextUsername = nu;
  }
  if (email !== undefined && String(email).trim() !== '' && String(email).trim().toLowerCase() !== u.email.toLowerCase()) {
    const ne = String(email).trim().toLowerCase();
    if (!EMAIL_RE.test(ne)) return res.status(400).json({ ok: false, error: '邮箱格式不正确' });
    if (u.role === 'superadmin') {
      // R99-B3：仅「真实激活（pro）」才锁——内置试用兜底（trial）不属于真实授权绑定，
      // 未激活（含试用期）的超管必须允许改邮箱，否则存量非邮箱账号将陷入「激活被拒+改邮箱被锁」死锁。
      // R104-B4：activated 已由上方 forceGuide 计算区统一求值（lic.state 只查一次）
      if (activated) return res.status(400).json({ ok: false, error: '超级管理员邮箱为授权绑定账号，激活后不可修改；如需更换超管请先解绑迁移' });
    }
    const dup = db.prepare('SELECT id FROM users WHERE LOWER(email) = LOWER(?) AND id <> ?').get(ne, u.id);
    if (dup) return res.status(400).json({ ok: false, error: '邮箱已被占用' });
    nextEmail = ne;
  }
  if (newPassword !== undefined && String(newPassword) !== '') {
    if (isDefaultPwd(newPassword)) return res.status(400).json({ ok: false, error: '不能设置为默认密码' });
    if (newPassword.length < 6 || newPassword.length > 64) return res.status(400).json({ ok: false, error: '新密码长度需 6-64 位' });
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(newPassword, salt, 64).toString('hex');
    db.prepare('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?').run(hash, salt, u.id);
    userState.clearDefaultPwd(db, u.id);   // R126（R-D1）：唯一写入口
    revokeAllSessions(u.id);               // R126（R-D5）：改密统一吊销其他会话
    needRehash = true;
  }
  const emailChanged = nextEmail !== u.email;
  if (nextUsername !== u.username || emailChanged) {
    // R105-B1：pwd_default 只由「真正改密」清除（本接口 L1002 改密分支、独立改密接口 L1027、重置密码 L1523）。
    // 邮箱/用户名变更与密码状态无关，不得触碰 pwd_default —— 否则「只改邮箱」即可把 pwdOk 伪造成 true，
    // 导致 needGuide 求值为 false、引导消失，而默认密码仍然有效（弱口令窗口无提示延长）。
    db.prepare('UPDATE users SET username = ?, email = ? WHERE id = ?')
      .run(nextUsername, nextEmail, u.id);
  }
  logOp(u, '修改账号资料', nextEmail);
  // R126（R-D5）：改密后当前设备重签新 token（带新 sv），前端存 token 后继续使用，不再要求重新登录
  const profUser = db.prepare('SELECT * FROM users WHERE id = ?').get(u.id);
  const profToken = needRehash ? issueToken(profUser, tokenRemembered(req)) : null;
  if (profToken) res.cookie('ts_token', profToken, cookieOpt(req, 0));   // R133-B9
  // R133 / B-12：返回体必须带「服务端权威」的引导三标志，禁止让前端臆造。
  // 原返回体只有 id/username/email/role/perms，前端保存成功后只能自己写 must_change:false、
  // email_default:false、pwd_default:false——用户「只改邮箱不改密码」时前端认为引导已完成，
  // 服务端 needGuide() 仍为 true，进后台直接吃 403 占位，且刷新才恢复，用户体感「保存了没反应」。
  // 口径与 /api/auth/me（L1149）严格一致：must_change 走 needGuide()，不看前端猜。
  res.json({
    ok: true, message: '账号资料已更新',
    user: {
      id: u.id, username: nextUsername, email: nextEmail, role: u.role, perms: safePerms(u),
      must_change: !DEMO && needGuide(profUser),
      email_default: isDefaultEmail(profUser.email),
      pwd_default: !DEMO && (profUser.pwd_default || 0) === 1
    },
    rehash: needRehash, token: profToken
  });
});
app.post('/api/auth/change-password', requireAuth, (req, res) => {
  const { oldPassword, newPassword } = req.body || {};
  const u = req.user;
  const oldHash = crypto.scryptSync(oldPassword || '', u.salt, 64).toString('hex');
  if (oldHash !== u.password_hash) return res.status(400).json({ ok: false, error: '原密码错误' });
  if (isDefaultPwd(newPassword)) return res.status(400).json({ ok: false, error: '不能设置为默认密码' });
  if (!newPassword || newPassword.length < 6 || newPassword.length > 64) return res.status(400).json({ ok: false, error: '新密码长度需 6-64 位' });
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(newPassword, salt, 64).toString('hex');
  db.prepare('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?').run(hash, salt, u.id);
  userState.clearDefaultPwd(db, u.id);   // R126（R-D1）：唯一写入口
  revokeAllSessions(u.id);               // R126（R-D5）：改密统一吊销其他会话
  const nu = db.prepare('SELECT * FROM users WHERE id = ?').get(u.id);
  const newToken = issueToken(nu, tokenRemembered(req)); // 当前设备重签新 token 保持登录（沿用原记住我意图）
  res.cookie('ts_token', newToken, cookieOpt(req, 0));   // R133-B9
  logOp(u, '修改密码', u.email);
  res.json({ ok: true, message: '密码已修改', token: newToken });
});

// ---------- 已登录：导航数据 / 收藏 / 模式 / 通知 / 天气 ----------
app.get('/api/nav', requireAuth, async (req, res) => {
  await maybeRefreshRemote();   // v0.99.38：首页导航入口同样节流刷新远端（公告/广告/定价即时同步）
  res.json({ ok: true, ...navPayload(req.user, req) });
});

// 站内检索（常用搜索卡片「站内」引擎：关键词匹配站点名称/地址/备注，返回直达列表）
// v0.99.60：开放游客公开口径（D-9）——无登录态只搜索公开可见站点（与 /api/public/nav 同口径），登录后搜索全部可见站点
app.get('/api/site-search', (req, res) => {
  const kw = String(req.query.kw || '').trim().toLowerCase();
  if (!kw) return res.json({ ok: true, items: [] });
  const isAdmin = !!(req.user && (req.user.role === 'admin' || req.user.role === 'superadmin'));
  const sites = db.prepare('SELECT * FROM sites ORDER BY sort ASC, id ASC').all();
  const groups = db.prepare('SELECT * FROM groups').all();
  const gmap = Object.fromEntries(groups.map((g) => [g.id, g.name]));
  const adminOnlyIds = new Set(groups.filter((g) => g.admin_only).map((g) => g.id));
  const mode = detectMode(req);
  const items = sites.filter((s) => {
    if (s.status !== 'active') return false;
    if (adminOnlyIds.has(s.group_id) && !isAdmin) return false;        // 管理员专属分组：非管理员不可见
    const vis = s.visibility || 'public';
    if (vis === 'private' && !isAdmin) return false;                   // 私密站点：仅管理员可见
    const hay = [s.name, s.remark || '', s.intranet_url || '', s.extranet_url || ''].join(' ').toLowerCase();
    return hay.includes(kw);
  }).slice(0, 12).map((s) => ({
    id: s.id, group_id: s.group_id, group_name: gmap[s.group_id] || '', name: s.name,
    icon_type: s.icon_type, icon_ref: s.icon_ref, icon_auto: s.icon_auto,
    url: mode === 'intranet' ? (s.intranet_url || s.extranet_url) : (s.extranet_url || s.intranet_url),
    intranet_url: s.intranet_url, extranet_url: s.extranet_url, remark: s.remark || ''
  }));
  res.json({ ok: true, items, guest: !req.user });
});
app.get('/api/mode', requireAuth, (req, res) => res.json({ mode: detectMode(req), manual: req.user.view_mode }));
app.post('/api/mode', requireAuth, (req, res) => {
  const mode = (req.body && req.body.mode) || 'auto';
  if (!['auto', 'intranet', 'extranet'].includes(mode)) return res.status(400).json({ ok: false, error: '模式不合法' });
  db.prepare('UPDATE users SET view_mode = ? WHERE id = ?').run(mode, req.user.id);
  res.json({ ok: true, mode });
});

app.get('/api/favorites', requireAuth, (req, res) => {
  const rows = JSON.parse(req.user.favorites || '[]');
  const sites = db.prepare('SELECT * FROM sites WHERE status = ?').all('active');
  const mode = detectMode(req);
  res.json({ ok: true, favorites: rows.map((f) => {
    const s = sites.find((x) => x.id === f.site_id);
    return s ? { site_id: s.id, name: f.name || s.name, url: mode === 'intranet' ? (s.intranet_url || s.extranet_url) : (s.extranet_url || s.intranet_url), icon_auto: s.icon_auto, icon_ref: s.icon_ref, sort: f.sort } : null;
  }).filter(Boolean) });
});
app.post('/api/favorites', requireAuth, (req, res) => {
  const { site_id, name } = req.body || {};
  const s = db.prepare('SELECT * FROM sites WHERE id = ? AND status = ?').get(site_id, 'active');
  if (!s) return res.status(400).json({ ok: false, error: '站点不存在' });
  let rows = JSON.parse(req.user.favorites || '[]');
  if (rows.some((f) => f.site_id === site_id)) return res.json({ ok: true, favorites: rows });
  rows.push({ site_id, name: name || s.name, sort: rows.length });
  db.prepare('UPDATE users SET favorites = ? WHERE id = ?').run(JSON.stringify(rows), req.user.id);
  res.json({ ok: true, favorites: rows });
});
app.delete('/api/favorites/:siteId', requireAuth, (req, res) => {
  const rows = JSON.parse(req.user.favorites || '[]').filter((f) => f.site_id !== parseInt(req.params.siteId, 10));
  db.prepare('UPDATE users SET favorites = ? WHERE id = ?').run(JSON.stringify(rows), req.user.id);
  res.json({ ok: true, favorites: rows });
});
app.put('/api/favorites', requireAuth, (req, res) => {
  const list = (req.body && req.body.favorites) || [];
  db.prepare('UPDATE users SET favorites = ? WHERE id = ?').run(JSON.stringify(list.map((f, i) => ({ site_id: f.site_id, name: f.name || '', sort: i }))), req.user.id);
  res.json({ ok: true, favorites: list });
});

// ---------- 用户站点收录申请 ----------
app.post('/api/site-applications', requireAuth, (req, res) => {
  const b = req.body || {};
  const name = (b.name || '').trim();
  const url = (b.url || '').trim();
  const note = (b.note || '').trim();
  const groupName = (b.group_name || '').trim();
  if (!name || !url) return res.status(400).json({ ok: false, error: '站点名称与网址必填' });
  if (!/^https?:\/\//i.test(url)) return res.status(400).json({ ok: false, error: '网址需以 http:// 或 https:// 开头' });
  const dup = db.prepare('SELECT * FROM site_applications WHERE url = ? AND status = ?').get(url, 'pending');
  if (dup) return res.status(400).json({ ok: false, error: '该网址已有待审核的申请' });
  const info = db.prepare('INSERT INTO site_applications(name, url, group_name, note, user_id, username) VALUES(?,?,?,?,?,?)')
    .run(name, url, groupName || null, note || null, req.user.id, req.user.username);
  logOp(req.user, '提交收录申请', `${name} ${url}`);
  res.json({ ok: true, id: info.lastInsertRowid });
});
app.get('/api/site-applications/mine', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT id, name, url, group_name, note, status, reason, created_at, reviewed_at FROM site_applications WHERE user_id = ? ORDER BY id DESC').all(req.user.id);
  res.json({ ok: true, applications: rows });
});

app.get('/api/notices', requireAuth, (req, res) => {
  const notices = db.prepare('SELECT * FROM notices WHERE published = 1 ORDER BY pinned DESC, id DESC').all();
  const readRows = db.prepare('SELECT notice_id FROM notice_reads WHERE user_id = ?').all(req.user.id);
  const readSet = new Set(readRows.map((r) => r.notice_id));
  const items = notices.map((n) => ({ id: n.id, title: n.title, content: n.content, content_html: n.content_html || null, level: n.level, pinned: n.pinned, created_at: n.created_at, read: readSet.has(n.id) }));
  res.json({ ok: true, items, unread: items.filter((i) => !i.read).length });
});
app.post('/api/notices/:id/read', requireAuth, (req, res) => {
  db.prepare('INSERT OR IGNORE INTO notice_reads(notice_id, user_id) VALUES(?, ?)').run(parseInt(req.params.id, 10), req.user.id);
  res.json({ ok: true });
});

app.get('/api/weather', async (req, res) => {
  const w = await getWeather(req.query.force === '1');
  res.json({ ok: true, available: w ? w.available !== false : false, ...w });
});

// ---------- 管理员：分组 / 站点 / 图库 / 通知 / 用户 / 邀请码 / 设置 / 日志 ----------
app.get('/api/admin/groups', requirePerm('groups'), (req, res) => {
  res.json({ ok: true, groups: db.prepare('SELECT * FROM groups ORDER BY sort ASC, id ASC').all() });
});
app.post('/api/admin/groups', requirePerm('groups'), (req, res) => {
  // 免费版配额：分组 ≤ 6（专业版不限）
  const q = lic.checkQuota('groups');
  if (!q.ok) return res.status(403).json({ ok: false, error: `免费版分组数量已达上限（${q.limit} 个），可先删除示例分组后再新建，或升级专业版解锁无限分组`, need_pro: true });
  const { name, icon, scene, show_in_nav, is_recommend, admin_only } = req.body || {};
  if (!name || !name.trim()) return res.status(400).json({ ok: false, error: '分组名称必填' });
  const max = db.prepare('SELECT COALESCE(MAX(sort), -1) AS m FROM groups').get().m;
  const info = db.prepare('INSERT INTO groups(name, icon, sort, scene, show_in_nav, is_recommend, admin_only) VALUES(?, ?, ?, ?, ?, ?, ?)')
    .run(name.trim(), icon || 'folder', max + 1, (scene || '').trim(), show_in_nav === undefined || show_in_nav ? 1 : 0, is_recommend ? 1 : 0, admin_only ? 1 : 0);
  logOp(req.user, '新建分组', name);
  res.json({ ok: true, group: db.prepare('SELECT * FROM groups WHERE id = ?').get(info.lastInsertRowid) });
});
app.put('/api/admin/groups/:id', requirePerm('groups'), (req, res) => {
  const g = db.prepare('SELECT * FROM groups WHERE id = ?').get(parseInt(req.params.id, 10));
  if (!g) return res.status(404).json({ ok: false, error: '分组不存在' });
  const { name, icon, sort, scene, show_in_nav, is_recommend, admin_only } = req.body || {};
  db.prepare('UPDATE groups SET name = ?, icon = ?, sort = ?, scene = ?, show_in_nav = ?, is_recommend = ?, admin_only = ? WHERE id = ?')
    .run(name !== undefined ? name : g.name, icon !== undefined ? icon : g.icon, sort !== undefined ? sort : g.sort,
      scene !== undefined ? String(scene).trim() : (g.scene || ''), show_in_nav !== undefined ? (show_in_nav ? 1 : 0) : (g.show_in_nav === undefined ? 1 : g.show_in_nav),
      is_recommend !== undefined ? (is_recommend ? 1 : 0) : (g.is_recommend === undefined ? 0 : g.is_recommend),
      admin_only !== undefined ? (admin_only ? 1 : 0) : (g.admin_only === undefined ? 0 : g.admin_only), g.id);
  logOp(req.user, '编辑分组', name || g.name);
  res.json({ ok: true });
});
app.delete('/api/admin/groups/:id', requirePerm('groups'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const n = db.prepare('SELECT COUNT(*) AS c FROM sites WHERE group_id = ?').get(id).c;
  db.prepare('DELETE FROM groups WHERE id = ?').run(id);
  logOp(req.user, '删除分组', `id=${id}，级联站点 ${n} 个`);
  res.json({ ok: true, removed_sites: n });
});
app.put('/api/admin/groups/order', requirePerm('groups'), (req, res) => {
  const ids = (req.body && req.body.ids) || [];
  ids.forEach((id, i) => db.prepare('UPDATE groups SET sort = ? WHERE id = ?').run(i, id));
  res.json({ ok: true });
});

// 上传 favicon：解析 base64 data URL，校验格式与大小，存入 icons/upload，返回文件名
function saveUploadedIcon(dataUrl, maxBytes = 1024 * 1024) {
  const m = /^data:image\/(png|jpeg|jpg|webp|svg\+xml|gif|vnd\.microsoft\.icon|x-icon);base64,(.+)$/i.exec(String(dataUrl || ''));
  if (!m) return null;
  const extMap = { png: '.png', jpeg: '.jpg', jpg: '.jpg', webp: '.webp', 'svg+xml': '.svg', gif: '.gif', 'vnd.microsoft.icon': '.ico', 'x-icon': '.ico' };
  const ext = extMap[m[1].toLowerCase()] || '.png';
  let buf;
  try { buf = Buffer.from(m[2], 'base64'); } catch { return null; }
  if (!buf.length || buf.length > maxBytes) return null;
  const name = crypto.createHash('md5').update(buf).digest('hex') + ext;
  try { fs.writeFileSync(path.join(ICON_UPLOAD_DIR, name), buf); return name; } catch { return null; }
}

// 通用 favicon 拉取（按 URL，不依赖站点 ID）
app.post('/api/admin/fetch-icon', requirePerm('sites'), async (req, res) => {
  const url = normalizeUrl((req.body && req.body.url) || '');
  if (!url) return res.status(400).json({ ok: false, error: '请输入有效地址（支持裸域名，如 baidu.com）' });
  try {
    const r = await ensureIcon(url, true);
    if (!r || !r.ok) return res.json({ ok: false, error: '图标拉取失败（目标站点可能不可达，可直接上传图标）' });
    res.json({ ok: true, filename: r.filename, url: `/api/icons/file/auto/${r.filename}` });
  } catch { res.json({ ok: false, error: '图标拉取异常（目标站点可能不可达，可直接上传图标）' }); }
});

// 站点信息探测：输入地址 → 返回站点标题与 favicon（新增站点一键回填）
app.post('/api/admin/probe-site', requirePerm('sites'), async (req, res) => {
  const url = normalizeUrl((req.body && req.body.url) || '');
  if (!url) return res.status(400).json({ ok: false, error: '请输入有效地址（支持裸域名，如 baidu.com）' });
  try {
    const probe = await probeSite(url);
    if (!probe || !probe.ok) return res.json({ ok: false, error: '站点探测失败（目标站点可能不可达，可手动填写信息）' });
    res.json({ ok: true, title: probe.title || '', filename: probe.filename || '', icon_url: probe.filename ? `/api/icons/file/auto/${probe.filename}` : '' });
  } catch { res.json({ ok: false, error: '站点探测异常（目标站点可能不可达，可手动填写信息）' }); }
});

app.get('/api/admin/sites', requirePerm('sites'), (req, res) => {
  res.json({ ok: true, sites: db.prepare('SELECT * FROM sites ORDER BY sort ASC, id ASC').all() });
});
app.post('/api/admin/sites', requirePerm('sites'), async (req, res) => {
  // 免费版配额：站点 ≤ 50（专业版不限）
  const q = lic.checkQuota('sites');
  if (!q.ok) return res.status(403).json({ ok: false, error: `免费版站点数量已达上限（${q.limit} 条），请升级专业版解锁无限收录`, need_pro: true });
  const b = req.body || {};
  if (!b.name || !b.group_id) return res.status(400).json({ ok: false, error: '名称、所属分组必填' });
  // 地址规范化：裸域名自动补 https:// 协议
  const intra = normalizeUrl(b.intranet_url);
  const extra = normalizeUrl(b.extranet_url);
  if (!intra && !extra) return res.status(400).json({ ok: false, error: '内网地址与外网地址至少填写一个（支持裸域名，如 baidu.com）' });
  const intranet_url = intra || null;          // 各存各的：纯内网/纯外网由网络属性区分，不自动同址
  const extranet_url = extra || null;
  let iconType = b.icon_type || 'auto', iconRef = b.icon_ref || null, iconAuto = b.icon_auto || null;
  if (b.icon_data) {
    const saved = saveUploadedIcon(b.icon_data);
    if (saved) { iconType = 'upload'; iconRef = saved; iconAuto = null; }
  }
  const max = db.prepare('SELECT COALESCE(MAX(sort), -1) AS m FROM sites WHERE group_id = ?').get(b.group_id).m;
  const nf = applyNetFlag({ intranet_url, extranet_url, net_flag: b.net_flag, net_flag_val: b.net_flag_val });
  const vis = b.visibility === 'private' ? 'private' : 'public';
  const info = db.prepare('INSERT INTO sites(group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode, net_flag, net_flag_val, visibility) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)')
    .run(b.group_id, b.name.trim(), iconType, iconRef, iconAuto, intranet_url, extranet_url, max + 1, (b.remark || '').trim(), b.open_mode || 'new', nf.net_flag, nf.net_flag_val, vis);
  const site = db.prepare('SELECT * FROM sites WHERE id = ?').get(info.lastInsertRowid);
  if ((site.icon_type === 'auto') && !site.icon_auto && !site.icon_ref) {
    try { const r = await ensureIcon(site.intranet_url || site.extranet_url); if (r && r.ok) db.prepare('UPDATE sites SET icon_auto = ? WHERE id = ?').run(r.filename, site.id); } catch {}
  }
  logOp(req.user, '新建站点', site.name);
  res.json({ ok: true, site: db.prepare('SELECT * FROM sites WHERE id = ?').get(site.id) });
});
app.put('/api/admin/sites/:id', requirePerm('sites'), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const s = db.prepare('SELECT * FROM sites WHERE id = ?').get(id);
  if (!s) return res.status(404).json({ ok: false, error: '站点不存在' });
  const b = req.body || {};
  const intra = normalizeUrl(b.intranet_url !== undefined ? b.intranet_url : s.intranet_url || '');
  const extra = normalizeUrl(b.extranet_url !== undefined ? b.extranet_url : (s.extranet_url || ''));
  if (!intra && !extra) return res.status(400).json({ ok: false, error: '内网地址与外网地址至少填写一个（支持裸域名）' });
  const intranet_url = intra || null;          // 各存各的：修改后按实际填写生效，不自动同址
  const extranet_url = extra || null;
  let iconType = b.icon_type !== undefined ? b.icon_type : s.icon_type;
  let iconRef = b.icon_ref !== undefined ? b.icon_ref : s.icon_ref;
  let iconAuto = b.icon_auto !== undefined ? b.icon_auto : s.icon_auto;
  if (b.icon_data) {
    const saved = saveUploadedIcon(b.icon_data);
    if (saved) { iconType = 'upload'; iconRef = saved; iconAuto = null; }
  }
  const nf = applyNetFlag({ intranet_url, extranet_url, net_flag: b.net_flag, net_flag_val: b.net_flag_val });
  const vis = b.visibility === 'private' ? 'private' : 'public';
  db.prepare('UPDATE sites SET group_id=?, name=?, icon_type=?, icon_ref=?, icon_auto=?, intranet_url=?, extranet_url=?, sort=?, remark=?, open_mode=?, status=?, net_flag=?, net_flag_val=?, visibility=? WHERE id=?')
    .run(b.group_id ?? s.group_id, b.name ?? s.name, iconType, iconRef, iconAuto,
      intranet_url, extranet_url, b.sort ?? s.sort, b.remark ?? s.remark, b.open_mode ?? s.open_mode, b.status ?? s.status,
      nf.net_flag, nf.net_flag_val, vis, id);
  if (b.fetch_icon === true || (iconType === 'auto' && !iconAuto && !iconRef)) {
    try { const r = await ensureIcon(intranet_url || extranet_url, true); if (r && r.ok) db.prepare('UPDATE sites SET icon_auto = ? WHERE id = ?').run(r.filename, id); } catch {}
  }
  logOp(req.user, '编辑站点', (b.name || s.name) + `#${id}`);
  res.json({ ok: true, site: db.prepare('SELECT * FROM sites WHERE id = ?').get(id) });
});
app.delete('/api/admin/sites/:id', requirePerm('sites'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  db.prepare('DELETE FROM sites WHERE id = ?').run(id);
  logOp(req.user, '删除站点', `id=${id}`);
  res.json({ ok: true });
});
app.put('/api/admin/sites/order', requirePerm('sites'), (req, res) => {
  const list = (req.body && req.body.ids) || [];
  list.forEach((id, i) => db.prepare('UPDATE sites SET sort = ? WHERE id = ?').run(i, id));
  res.json({ ok: true });
});
app.post('/api/admin/sites/:id/fetch-icon', requirePerm('sites'), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const s = db.prepare('SELECT * FROM sites WHERE id = ?').get(id);
  if (!s) return res.status(404).json({ ok: false, error: '站点不存在' });
  const r = await ensureIcon(s.intranet_url || s.extranet_url, true);
  if (!r || !r.ok) return res.json({ ok: false, error: '图标拉取失败（目标站点可能不可达，可手动上传图标）' });
  db.prepare('UPDATE sites SET icon_auto = ? WHERE id = ?').run(r.filename, id);
  res.json({ ok: true, filename: r.filename, url: `/api/icons/file/auto/${r.filename}` });
});

app.get('/api/admin/icons', requirePerm('icons'), (req, res) => {
  const list = db.prepare('SELECT * FROM icons ORDER BY category ASC, id DESC').all();
  res.json({ ok: true, icons: list.map((i) => ({ ...i, url: `/api/icons/file/library/${i.filename}` })) });
});
app.post('/api/admin/icons', requirePerm('icons'), (req, res) => {
  const { name, category, data, ext } = req.body || {};
  if (!name || !data) return res.status(400).json({ ok: false, error: '图标名称与内容必填' });
  const buf = Buffer.from(data, 'base64');
  if (buf.length > 2 * 1024 * 1024) return res.status(400).json({ ok: false, error: '图标不能超过 2MB' });
  const safeExt = ['png', 'jpg', 'jpeg', 'webp', 'svg', 'gif', 'ico'].includes(String(ext).toLowerCase()) ? String(ext).toLowerCase() : 'png';
  const filename = `${Date.now()}_${Math.random().toString(36).slice(2, 8)}.${safeExt}`;
  fs.writeFileSync(path.join(ICON_LIB_DIR, filename), buf);
  const info = db.prepare('INSERT INTO icons(name, filename, category, uploaded_by) VALUES(?, ?, ?, ?)').run(name.trim(), filename, (category || '通用').trim(), req.user.id);
  logOp(req.user, '上传图标', name);
  res.json({ ok: true, icon: { id: info.lastInsertRowid, name, filename, category, url: `/api/icons/file/library/${filename}` } });
});
app.delete('/api/admin/icons/:id', requirePerm('icons'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const icon = db.prepare('SELECT * FROM icons WHERE id = ?').get(id);
  if (!icon) return res.status(404).json({ ok: false, error: '图标不存在' });
  const used = db.prepare('SELECT COUNT(*) AS c FROM sites WHERE icon_ref = ?').get(icon.filename).c;
  db.prepare('DELETE FROM icons WHERE id = ?').run(id);
  fs.rmSync(path.join(ICON_LIB_DIR, icon.filename), { force: true });
  logOp(req.user, '删除图标', `${icon.name}（被 ${used} 个站点引用）`);
  res.json({ ok: true, used });
});

app.get('/api/admin/notices', requirePerm('notices'), (req, res) => {
  res.json({ ok: true, notices: db.prepare('SELECT * FROM notices ORDER BY id DESC').all() });
});
app.post('/api/admin/notices', requirePerm('notices'), (req, res) => {
  const { title, content, content_html, level, pinned, published } = req.body || {};
  if (!title || !title.trim() || !content || !content.trim()) return res.status(400).json({ ok: false, error: '标题与内容必填' });
  const info = db.prepare('INSERT INTO notices(title, content, content_html, level, pinned, published, created_by) VALUES(?,?,?,?,?,?,?)')
    .run(title.trim(), content.trim(), content_html || null, level || 'info', pinned ? 1 : 0, published === undefined ? 1 : (published ? 1 : 0), req.user.id);
  logOp(req.user, published === 0 ? '新增草稿通知' : '发布通知', title);
  res.json({ ok: true, notice: db.prepare('SELECT * FROM notices WHERE id = ?').get(info.lastInsertRowid) });
});
app.put('/api/admin/notices/:id', requirePerm('notices'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const n = db.prepare('SELECT * FROM notices WHERE id = ?').get(id);
  if (!n) return res.status(404).json({ ok: false, error: '通知不存在' });
  const b = req.body || {};
  db.prepare("UPDATE notices SET title=?, content=?, content_html=?, level=?, pinned=?, published=?, updated_at=datetime('now','localtime') WHERE id=?")
    .run(b.title ?? n.title, b.content ?? n.content, b.content_html !== undefined ? b.content_html : n.content_html, b.level ?? n.level, b.pinned !== undefined ? (b.pinned ? 1 : 0) : n.pinned, b.published !== undefined ? (b.published ? 1 : 0) : n.published, id);
  logOp(req.user, '更新通知', b.title || n.title);
  res.json({ ok: true });
});
app.delete('/api/admin/notices/:id', requirePerm('notices'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  db.prepare('DELETE FROM notice_reads WHERE notice_id = ?').run(id);
  db.prepare('DELETE FROM notices WHERE id = ?').run(id);
  logOp(req.user, '删除通知', `id=${id}`);
  res.json({ ok: true });
});

// ---------- 管理员：收录审核 ----------
app.get('/api/admin/site-applications', requirePerm('apply'), (req, res) => {
  const rows = db.prepare("SELECT * FROM site_applications ORDER BY (status = 'pending') DESC, id DESC").all();
  res.json({ ok: true, applications: rows });
});
app.post('/api/admin/site-applications/:id/approve', requirePerm('apply'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const ap = db.prepare('SELECT * FROM site_applications WHERE id = ?').get(id);
  if (!ap) return res.status(404).json({ ok: false, error: '申请不存在' });
  if (ap.status !== 'pending') return res.status(400).json({ ok: false, error: '该申请已处理' });
  const dup = db.prepare('SELECT * FROM sites WHERE intranet_url = ? OR extranet_url = ?').get(ap.url, ap.url);
  if (dup) return res.status(400).json({ ok: false, error: '该网址已收录，无需重复添加' });
  // 分组：优先使用同名分组，否则按申请的分组名创建，默认「用户收录」
  const gname = (ap.group_name || '用户收录').trim();
  let g = db.prepare('SELECT * FROM groups WHERE name = ?').get(gname);
  if (!g) {
    const max = db.prepare('SELECT COALESCE(MAX(sort), -1) AS m FROM groups').get().m;
    const gi = db.prepare('INSERT INTO groups(name, icon, sort) VALUES(?,?,?)').run(gname, 'link', max + 1);
    g = { id: gi.lastInsertRowid };
  }
  // 按申请网址自动判定内网/外网字段（各存各的，不自动同址）
  const nu = normalizeUrl(ap.url);
  const host = nu.replace(/^https?:\/\//i, '').split('/')[0].split(':')[0];
  const isIn = isLanAddr(host);
  const intranet_url = isIn ? nu : null;
  const extranet_url = isIn ? null : nu;
  const smax = db.prepare('SELECT COALESCE(MAX(sort), -1) AS m FROM sites WHERE group_id = ?').get(g.id).m;
  db.prepare('INSERT INTO sites(group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode, status) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
    .run(g.id, ap.name, 'auto', null, null, intranet_url, extranet_url, smax + 1, (ap.note || `由用户「${ap.username || '未知'}」申请收录`).slice(0, 200), 'new', 'active');
  db.prepare("UPDATE site_applications SET status = ?, reviewed_at = datetime('now','localtime') WHERE id = ?").run('approved', id);
  logOp(req.user, '通过收录申请', `${ap.name} ${ap.url}`);
  res.json({ ok: true });
});
app.post('/api/admin/site-applications/:id/reject', requirePerm('apply'), (req, res) => {
  const id = parseInt(req.params.id, 10);
  const ap = db.prepare('SELECT * FROM site_applications WHERE id = ?').get(id);
  if (!ap) return res.status(404).json({ ok: false, error: '申请不存在' });
  if (ap.status !== 'pending') return res.status(400).json({ ok: false, error: '该申请已处理' });
  const reason = ((req.body && req.body.reason) || '').trim() || '未通过审核';
  db.prepare("UPDATE site_applications SET status = ?, reason = ?, reviewed_at = datetime('now','localtime') WHERE id = ?").run('rejected', reason, id);
  logOp(req.user, '拒绝收录申请', `${ap.name} ${ap.url}（${reason}）`);
  res.json({ ok: true });
});

// R103C：用户管理为敏感模块，仅超级管理员可操作（普通管理员不开放）
app.get('/api/admin/users', requireSuper, (req, res) => {
  const users = db.prepare('SELECT id, email, username, role, perms, status, created_at, last_login_at FROM users ORDER BY id ASC').all();
  res.json({ ok: true, users });
});
app.post('/api/admin/users/:id/enable', requireSuper, (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (id === req.user.id) return res.status(400).json({ ok: false, error: '不能操作自己' });
  db.prepare('UPDATE users SET status = ? WHERE id = ?').run('active', id);
  logOp(req.user, '启用用户', `id=${id}`);
  res.json({ ok: true });
});
app.post('/api/admin/users/:id/disable', requireSuper, (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (id === req.user.id) return res.status(400).json({ ok: false, error: '不能操作自己' });
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (u && u.role === 'superadmin') {
    const sc = db.prepare('SELECT COUNT(*) AS c FROM users WHERE role = ?').get('superadmin').c;
    if (sc <= 1) return res.status(400).json({ ok: false, error: '至少保留一名超级管理员' });
  }
  db.prepare('UPDATE users SET status = ? WHERE id = ?').run('disabled', id);
  logOp(req.user, '禁用用户', `id=${id}`);
  res.json({ ok: true });
});
app.post('/api/admin/users/:id/reset-password', requireSuper, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ ok: false, error: '用户不存在' });
  const newPwd = (req.body && req.body.password) || `Tsh@${crypto.randomInt(100000, 1000000)}`;
  // R100-B2：重置密码禁止设为默认值（与全站口径统一）
  if (isDefaultPwd(newPwd)) return res.status(400).json({ ok: false, error: '不能设置为默认密码' });
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(newPwd, salt, 64).toString('hex');
  // R100-A4：重置后置 pwd_default=1，强制对方下次登录改密（防止临时密码长期使用）
  db.prepare('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?').run(hash, salt, id);
  userState.setDefaultPwd(db, id);   // R126（R-D1）：唯一写入口
  revokeAllSessions(id);             // R126（R-D5）：管理员重置 → 对方全部会话强制下线，下次登录改密
  logOp(req.user, '重置用户密码', u.email);
  res.json({ ok: true, message: '密码已重置，对方下次登录需重新设置密码', new_password: newPwd });
});
app.delete('/api/admin/users/:id', requireSuper, (req, res) => {
  const id = parseInt(req.params.id, 10);
  if (id === req.user.id) return res.status(400).json({ ok: false, error: '不能删除自己' });
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ ok: false, error: '用户不存在' });
  if (u.role === 'superadmin') {
    const sc = db.prepare('SELECT COUNT(*) AS c FROM users WHERE role = ?').get('superadmin').c;
    if (sc <= 1) return res.status(400).json({ ok: false, error: '至少保留一名超级管理员' });
  }
  db.prepare('DELETE FROM notice_reads WHERE user_id = ?').run(id);
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  logOp(req.user, '删除用户', u.email);
  res.json({ ok: true });
});
// 超级管理员新建用户（角色：普通管理员 admin / 普通用户 user；不可创建第二个超管）
app.post('/api/admin/users', requireSuper, (req, res) => {
  // 免费版配额：用户 ≤ 2（含管理员；专业版不限）
  const q = lic.checkQuota('users');
  if (!q.ok) return res.status(403).json({ ok: false, error: `免费版用户数量已达上限（${q.limit} 名，含管理员），请升级专业版解锁更多用户`, need_pro: true });
  const b = req.body || {};
  const email = (b.email || '').trim().toLowerCase();
  const username = (b.username || '').trim();
  const password = b.password || '';
  const role = b.role === 'admin' ? 'admin' : 'user';
  const status = b.status === 'disabled' ? 'disabled' : 'active';
  // R103C：权限勾选仅对普通管理员生效；普通管理员默认全授可勾选模块，敏感模块（用户/设置/数据/升级/日志）锁定超管
  let perms = '[]';
  if (role === 'admin') {
    const sel = Array.isArray(b.perms) ? b.perms.filter((m) => PERM_MODULES.includes(m) && ['sites', 'groups', 'icons', 'notices', 'apply', 'orders', 'contact'].includes(m)) : [];
    perms = JSON.stringify(sel);
  }
  if (!email || !username || !password) return res.status(400).json({ ok: false, error: '邮箱、用户名、初始密码必填' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ ok: false, error: '邮箱格式不正确' });
  if (username.length < 2 || username.length > 20) return res.status(400).json({ ok: false, error: '用户名长度需 2-20 位' });
  if (password.length < 6) return res.status(400).json({ ok: false, error: '密码至少 6 位' });
  if (isDefaultPwd(password)) return res.status(400).json({ ok: false, error: '不能设置为默认密码' });
  if (db.prepare('SELECT * FROM users WHERE email = ?').get(email)) return res.status(400).json({ ok: false, error: '该邮箱已被使用' });
  if (db.prepare('SELECT * FROM users WHERE username = ?').get(username)) return res.status(400).json({ ok: false, error: '该用户名已被使用' });
  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.scryptSync(password, salt, 64).toString('hex');
  const info = db.prepare('INSERT INTO users(email, username, password_hash, salt, role, perms, status, pwd_default) VALUES(?,?,?,?,?,?,?,0)')
    .run(email, username, hash, salt, role, perms, status);
  logOp(req.user, '新建用户', `${email}（${role}）`);
  res.json({ ok: true, user: db.prepare('SELECT id, email, username, role, perms, status, created_at FROM users WHERE id = ?').get(info.lastInsertRowid) });
});
// 超级管理员编辑用户（邮箱格式全局强制；超管邮箱激活后锁定=绑定账号；不可降级唯一超管/不可产生第二超管）
app.put('/api/admin/users/:id', requireSuper, (req, res) => {
  const id = parseInt(req.params.id, 10);
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  if (!u) return res.status(404).json({ ok: false, error: '用户不存在' });
  const b = req.body || {};
  const email = (b.email !== undefined ? String(b.email) : u.email).trim().toLowerCase();
  const username = (b.username !== undefined ? String(b.username) : u.username).trim();
  if (!email || !username) return res.status(400).json({ ok: false, error: '邮箱与用户名不能为空' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return res.status(400).json({ ok: false, error: '邮箱格式不正确' });
  if (username.length < 2 || username.length > 20) return res.status(400).json({ ok: false, error: '用户名长度需 2-20 位' });
  if (email !== u.email && db.prepare('SELECT * FROM users WHERE email = ?').get(email)) return res.status(400).json({ ok: false, error: '该邮箱已被其他用户使用' });
  if (username !== u.username && db.prepare('SELECT * FROM users WHERE username = ?').get(username)) return res.status(400).json({ ok: false, error: '该用户名已被其他用户使用' });
  // 超管邮箱 = 授权绑定账号：真实激活（pro）才锁定，不可直接修改（换超管须解绑迁移后重新激活）；
  // R113/A7：锁定条件收敛为「已激活才锁」（未激活允许改邮箱/用户名，解除存量非法邮箱死锁）
  if (superAdminLocked(u) && email !== u.email) {
    return res.status(400).json({ ok: false, error: '超级管理员资料已锁定，仅可修改密码；如需更换超管请先解绑迁移' });
  }
  if (superAdminLocked(u) && username !== u.username) {
    return res.status(400).json({ ok: false, error: '超级管理员用户名已锁定，仅可修改密码' });
  }
  // R99-B3：显式指定 role=superadmin（提权/新建超管）一律拒绝；编辑超管自身未传 role 时沿用原角色，不得误拒
  if (b.role === 'superadmin') return res.status(400).json({ ok: false, error: '超级管理员唯一，不可再创建或指定' });
  const nextRole = (b.role === 'admin' || b.role === 'user') ? b.role : u.role;
  if (u.role === 'superadmin' && nextRole !== 'superadmin') {
    const sc = db.prepare('SELECT COUNT(*) AS c FROM users WHERE role = ?').get('superadmin').c;
    if (sc <= 1) return res.status(400).json({ ok: false, error: '至少保留一名超级管理员，不可将唯一超管降级' });
  }
  if (id === req.user.id && b.status === 'disabled') return res.status(400).json({ ok: false, error: '不能禁用自己的账号' });
  const status = (b.status === 'disabled' || b.status === 'active') ? b.status : u.status;
  let perms = u.perms;
  if (nextRole === 'admin' && Array.isArray(b.perms)) {
    const sel = b.perms.filter((m) => ['sites', 'groups', 'icons', 'notices', 'apply', 'orders', 'contact'].includes(m));
    perms = JSON.stringify(sel);
  }
  if (nextRole === 'user') perms = '[]';
  db.prepare('UPDATE users SET email = ?, username = ?, role = ?, perms = ?, status = ? WHERE id = ?').run(email, username, nextRole, perms, status, id);
  if (b.password) {
    if (isDefaultPwd(b.password)) return res.status(400).json({ ok: false, error: '不能设置为默认密码' });
    if (String(b.password).length < 6) return res.status(400).json({ ok: false, error: '新密码至少 6 位' });
    const salt = crypto.randomBytes(16).toString('hex');
    const hash = crypto.scryptSync(String(b.password), salt, 64).toString('hex');
    db.prepare('UPDATE users SET password_hash = ?, salt = ? WHERE id = ?').run(hash, salt, id);
    userState.clearDefaultPwd(db, id);   // R126（R-D1）：管理员直接设新密码=本人已知，视为已改密
    revokeAllSessions(id);               // R126（R-D5）：编辑设密后旧会话下线
  }
  logOp(req.user, '编辑用户', `${email}（${nextRole}）`);
  res.json({ ok: true, user: db.prepare('SELECT id, email, username, role, perms, status, created_at, last_login_at FROM users WHERE id = ?').get(id) });
});

app.get('/api/admin/invite-codes', requireSuper, (req, res) => {
  res.json({ ok: true, codes: db.prepare('SELECT * FROM invite_codes ORDER BY id DESC').all() });
});
app.post('/api/admin/invite-codes', requireSuper, (req, res) => {
  const maxUses = Math.max(1, parseInt((req.body && req.body.max_uses) || '1', 10));
  const code = 'TSH-' + crypto.randomBytes(4).toString('hex').toUpperCase();
  const info = db.prepare('INSERT INTO invite_codes(code, max_uses, created_by) VALUES(?, ?, ?)').run(code, maxUses, req.user.id);
  logOp(req.user, '生成邀请码', code);
  res.json({ ok: true, code: db.prepare('SELECT * FROM invite_codes WHERE id = ?').get(info.lastInsertRowid) });
});
app.post('/api/admin/invite-codes/:id/disable', requireSuper, (req, res) => {
  db.prepare('UPDATE invite_codes SET status = ? WHERE id = ?').run('disabled', parseInt(req.params.id, 10));
  res.json({ ok: true });
});
app.delete('/api/admin/invite-codes/:id', requireSuper, (req, res) => {
  db.prepare('DELETE FROM invite_codes WHERE id = ?').run(parseInt(req.params.id, 10));
  res.json({ ok: true });
});

app.get('/api/admin/settings', requireSuper, (req, res) => res.json({ ok: true, settings: getSettings() }));
app.put('/api/admin/settings', requireSuper, (req, res) => {
  const b = (req.body && req.body.settings) || {};
  setSettings(b);
  logOp(req.user, '更新系统配置', Object.keys(b).join(', '));
  res.json({ ok: true, settings: getSettings() });
});
// ---------- DDNS 动态域名（R98：10 家服务商；凭据 AES 加密存储、回显脱敏） ----------
// R133 / B-10：对外错误文案脱敏。原先 5 处把 e.message 原样回给客户端，Node 的系统错误会带出
// 绝对路径（ENOENT: open '/app/data/ddns.json'）与内网地址，等于把部署结构送给攻击者。
// 规则：带盘符/标准路径前缀或 ENOENT/EACCES/EPERM 一律换成兜底文案，原文只进服务端日志；
// 业务校验类短句（如「服务商不支持」「密钥格式不正确」）照常回显，不牺牲可用性。
function safeErr(e, fallback) {
  const raw = String((e && e.message) || '').replace(/\s+/g, ' ').trim();
  console.error('[ERR-SANITIZED]', fallback, '|', raw);
  const leak = /(?:[A-Za-z]:\\|\/(?:app|vol1|root|home|data|www|usr|tmp)\/|ENOENT|EACCES|EPERM|EADDRINUSE)/.test(raw);
  if (!raw || leak || raw.length > 200) return fallback;
  return raw;
}

app.get('/api/admin/ddns', requireSuper, (req, res) => {
  // R133-B16（审计 B-16）：原写法 try{res.json(x)}catch{res.status(400).json(...)} —— 若 res.json 内部
  // 序列化失败，headers 可能已发出，catch 再发一次即 ERR_HTTP_HEADERS_SENT（本地测不出来，被 Express 吞）。
  // 改法：先在 try 里只算数据，res.json 放到 try 外；二次响应由全局错误中间件的 headersSent 守卫兜底。
  let payload;
  try { payload = { ok: true, cfg: ddns.getCfg(), providers: ddns.PROVIDERS, status: ddns.status() }; }
  catch (e) { return res.status(400).json({ ok: false, error: safeErr(e, '读取 DDNS 配置失败') }); }
  res.json(payload);
});
app.put('/api/admin/ddns', requireSuper, (req, res) => {
  try {
    const cfg = ddns.save((req.body && req.body.cfg) || {}, req.user);
    logOp(req.user, 'DDNS 动态域名', '保存配置（' + ((req.body && req.body.cfg && req.body.cfg.provider) || '') + '）');
    res.json({ ok: true, cfg, status: ddns.status() });
  } catch (e) { res.status(400).json({ ok: false, error: safeErr(e, '保存 DDNS 配置失败（请检查参数格式）') }); }
});
app.post('/api/admin/ddns/test', requireSuper, async (req, res) => {
  // R133-B16：同上——先算数据再响应，避免二次响应
  let payload;
  try { payload = await ddns.test(); }
  catch (e) { return res.status(400).json({ ok: false, error: safeErr(e, 'DDNS 连通性测试失败（请检查域名与密钥）') }); }
  res.json(payload);
});
app.post('/api/admin/ddns/update', requireSuper, async (req, res) => {
  try {
    const r = await ddns.updateNow();
    if (r.ok) logOp(req.user, 'DDNS 动态域名', '手动立即更新 → ' + (r.message || '').slice(0, 80));
    else logOp(req.user, 'DDNS 动态域名', '手动更新失败：' + (r.error || '').slice(0, 80));
    res.json(Object.assign({}, r, { status: ddns.status() }));
  } catch (e) { res.status(400).json({ ok: false, error: safeErr(e, 'DDNS 更新失败（请检查服务商配置）') }); }
});
// v0.99.45：SMTP 发送测试邮件（系统设置-邮件模块「发送测试邮件」按钮）。
// 优先使用表单当前填写的参数（未保存也能测试）；密码留空时回退到已保存的 smtp_pass。
app.post('/api/admin/settings/smtp-test', requireSuper, async (req, res) => {
  try {
    const b = (req.body && req.body.body) || req.body || {};
    const s = getSettings();
    const cfg = {
      host: String(b.host || s.smtp_host || '').trim(),
      port: Number(b.port || s.smtp_port || 465),
      secure: b.secure != null ? !!b.secure : (s.smtp_secure === '1'),
      user: String(b.user || s.smtp_user || '').trim(),
      pass: String(b.pass || s.smtp_pass || ''),
      from: String(b.from || s.smtp_from || b.user || s.smtp_user || '').trim()
    };
    const to = String(b.to || '').trim();
    if (!cfg.host || !cfg.user || !cfg.pass) return res.status(400).json({ ok: false, error: '请先填写完整的 SMTP 配置（主机 / 用户 / 密码或授权码）后再测试' });
    if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(to)) return res.status(400).json({ ok: false, error: '测试收件邮箱格式不正确' });
    const nodemailer = require('nodemailer');
    const t = nodemailer.createTransport({
      host: cfg.host, port: cfg.port, secure: cfg.secure,
      auth: { user: cfg.user, pass: cfg.pass },
      tls: { rejectUnauthorized: false }
    });
    await t.sendMail({
      from: `"${APP_NAME}" <${cfg.from}>`, to,
      subject: `【${APP_NAME}】SMTP 测试邮件`,
      html: `<div style="font-family:'Microsoft YaHei',sans-serif;max-width:600px;margin:0 auto;padding:24px"><h2 style="color:#1d4ed8;margin-top:0">${APP_NAME} SMTP 配置测试成功</h2><p>收到本邮件说明 SMTP 配置正确，邮箱验证码、找回密码等邮件功能可正常使用。</p><p style="color:#666">发送时间：${new Date().toLocaleString('zh-CN')}</p><p style="color:#999;font-size:12px">— ${APP_COPYRIGHT}</p></div>`
    });
    await t.close();
    logOp(req.user, '系统设置', `SMTP 测试邮件已发送至 ${to}`);
    res.json({ ok: true, message: `测试邮件已发送至 ${to}，请查收` });
  } catch (e) {
    console.error('[SMTP 测试失败]', e && e.message);
    res.status(400).json({ ok: false, error: '测试邮件发送失败：' + safeErr(e, '请检查服务器地址、端口与账号密码') });
  }
});
app.get('/api/admin/logs', requireSuper, (req, res) => {
  const rows = db.prepare('SELECT * FROM operation_logs ORDER BY id DESC LIMIT 200').all();
  res.json({ ok: true, logs: rows });
});
// 清空操作日志（管理员密码二次验证）
app.post('/api/admin/logs/clear', requireSuper, (req, res) => {
  const pwd = ((req.body || {}).password || '').trim();
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const ok = u && pwd && crypto.scryptSync(pwd, u.salt, 64).toString('hex') === u.password_hash;
  if (!ok) return res.status(403).json({ ok: false, error: '管理员密码验证失败，已取消' });
  db.prepare('DELETE FROM operation_logs').run();
  logOp(req.user, '清空操作日志', '全部日志已清空（二次验证通过）');
  res.json({ ok: true, removed: true });
});
// 示例数据：默认新部署自动填充（站点/分组/通知/广告），一键初始化 / 清空全站（均需管理员密码二次验证）
const SAMPLE_AD_IMAGE = "/img/ads/top.gif"; // v0.99.45 GIF 动图示例：顶部横幅 1200×50
// 底部图片广告示例图（SVG 渐变横幅，链接到官网产品页）
const SAMPLE_FOOTER_BANNER = "/img/ads/footer.gif"; // v0.99.45 GIF 动图示例：底部横幅 1200×100
// 站内购买收款二维码示例图（个人收款码方案：开发者后台可配置真实收款码图片并推送）
const SAMPLE_PAY_QR = "data:image/svg+xml;charset=utf-8," + encodeURIComponent("<svg xmlns='http://www.w3.org/2000/svg' width='280' height='280'><rect width='280' height='280' rx='16' fill='#fff'/><rect x='14' y='14' width='252' height='252' rx='12' fill='#f0f6ff'/><g fill='#111827'><rect x='44' y='44' width='36' height='36'/><rect x='90' y='44' width='16' height='36'/><rect x='116' y='44' width='36' height='36'/><rect x='162' y='44' width='16' height='36'/><rect x='188' y='44' width='36' height='36'/><rect x='44' y='90' width='36' height='16'/><rect x='188' y='90' width='36' height='16'/><rect x='44' y='116' width='36' height='36'/><rect x='90' y='116' width='16' height='36'/><rect x='116' y='116' width='36' height='36'/><rect x='162' y='116' width='16' height='36'/><rect x='188' y='116' width='36' height='36'/><rect x='44' y='162' width='36' height='16'/><rect x='188' y='162' width='36' height='16'/><rect x='44' y='188' width='36' height='36'/><rect x='90' y='188' width='16' height='36'/><rect x='116' y='188' width='36' height='36'/><rect x='162' y='188' width='16' height='36'/><rect x='188' y='188' width='36' height='36'/></g><circle cx='140' cy='140' r='22' fill='#fff'/><text x='140' y='256' font-family='PingFang SC,Microsoft YaHei,sans-serif' font-size='12' fill='#6b7280' text-anchor='middle'>支付宝收款码（示例，请在系统设置中配置真实收款码）</text></svg>");
// C6 示例图片广告（四列广告中的图片列；推荐尺寸 640×160，开发者后台配置说明同步）
const SAMPLE_AD_COL_IMG1 = "/img/ads/notify1.gif"; //"<svg xmlns='http://www.w3.org/2000/svg' width='640' height='160'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#1e3a8a'/><stop offset='1' stop-color='#0ea5e9'/></linearGradient></defs><rect width='640' height='160' rx='14' fill='url(#g)'/><circle cx='545' cy='30' r='120' fill='rgba(255,255,255,0.08)'/><circle cx='60' cy='150' r='80' fill='rgba(255,255,255,0.06)'/><text x='46' y='78' font-family='Microsoft YaHei, sans-serif' font-size='44' font-weight='bold' fill='#ffffff'>天枢导航</text><text x='48' y='116' font-family='Microsoft YaHei, sans-serif' font-size='20' fill='rgba(255,255,255,0.85)'>常用工具一网直达 · 点击了解</text><circle cx='572' cy='140' r='10' fill='rgba(255,255,255,0.55)'/></svg>");
const SAMPLE_AD_COL_IMG2 = "/img/ads/notify2.gif"; //"<svg xmlns='http://www.w3.org/2000/svg' width='640' height='160'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#0b1f4d'/><stop offset='1' stop-color='#7c3aed'/></linearGradient></defs><rect width='640' height='160' rx='14' fill='url(#g)'/><circle cx='545' cy='30' r='120' fill='rgba(255,255,255,0.08)'/><circle cx='60' cy='150' r='80' fill='rgba(255,255,255,0.06)'/><text x='46' y='78' font-family='Microsoft YaHei, sans-serif' font-size='44' font-weight='bold' fill='#ffffff'>AI 工具导航</text><text x='48' y='116' font-family='Microsoft YaHei, sans-serif' font-size='20' fill='rgba(255,255,255,0.85)'>tools-ai.cn 聚合常用 AI</text><circle cx='572' cy='140' r='10' fill='rgba(255,255,255,0.55)'/></svg>");
const SAMPLE_AD_COL_IMG3 = "/img/ads/notify3.gif"; //"<svg xmlns='http://www.w3.org/2000/svg' width='640' height='160'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#134e4a'/><stop offset='1' stop-color='#0d9488'/></linearGradient></defs><rect width='640' height='160' rx='14' fill='url(#g)'/><circle cx='545' cy='30' r='120' fill='rgba(255,255,255,0.08)'/><circle cx='60' cy='150' r='80' fill='rgba(255,255,255,0.06)'/><text x='46' y='78' font-family='Microsoft YaHei, sans-serif' font-size='44' font-weight='bold' fill='#ffffff'>专业版 · 秒发激活码</text><text x='48' y='116' font-family='Microsoft YaHei, sans-serif' font-size='20' fill='rgba(255,255,255,0.85)'>在线购买即买即用</text><circle cx='572' cy='140' r='10' fill='rgba(255,255,255,0.55)'/></svg>");
const SAMPLE_AD_COL_IMG4 = "/img/ads/notify4.gif"; //"<svg xmlns='http://www.w3.org/2000/svg' width='640' height='160'><defs><linearGradient id='g' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#7c2d12'/><stop offset='1' stop-color='#f97316'/></linearGradient></defs><rect width='640' height='160' rx='14' fill='url(#g)'/><circle cx='545' cy='30' r='120' fill='rgba(255,255,255,0.08)'/><circle cx='60' cy='150' r='80' fill='rgba(255,255,255,0.06)'/><text x='46' y='78' font-family='Microsoft YaHei, sans-serif' font-size='44' font-weight='bold' fill='#ffffff'>天枢导航 · EDIY 出品</text><text x='48' y='116' font-family='Microsoft YaHei, sans-serif' font-size='20' fill='rgba(255,255,255,0.85)'>内网/外网智能切换导航</text><circle cx='572' cy='140' r='10' fill='rgba(255,255,255,0.55)'/></svg>");
// v0.99.30：分类间隔文字广告示例池（1 行 × 5 列 × 5 个分类间隔 = 25 个位置；第 k 间隔取第 k*5+1 ~ k*5+5 条）
const AD_BETWEEN_SEED_25 = [
  { t: '开发工具 · AI 工具 · 效率办公聚合导航', url: 'https://nav.ediy.net', color: '#2f7bff', bold: 1 },
  { t: '站点管理 · 分组管理 · 公共图库', url: 'https://nav.ediy.net', color: '#7b5bff' },
  { t: '专业版激活 · 在线购买秒发激活码', url: 'https://nav.ediy.net', color: '#0f9d58', bold: 1 },
  { t: '系统通知 · 站内广告统一管理', url: 'https://nav.ediy.net', color: '#d64550', italic: 1 },
  { t: '常用搜索：站内 / 百度 / 必应 / 谷歌', url: 'https://nav.ediy.net', color: '#0f9d58' },
  { t: '内网服务器导航门户 · 统一入口', url: 'https://nav.ediy.net', color: '#2f7bff', bold: 1 },
  { t: '内外网智能切换 · 一键直达常用系统', url: 'https://nav.ediy.net', color: '#6d5bd0' },
  { t: '个人收藏 · 数据本地持久化', url: 'https://nav.ediy.net', color: '#13c2c2', italic: 1 },
  { t: '支持分组管理 · 站点排序自定义', url: 'https://nav.ediy.net', color: '#52c41a' },
  { t: '深蓝科技风 · 简约美观不拥挤', url: 'https://nav.ediy.net', color: '#fa8c16' },
  { t: '公共图库 · 图标资源统一管理', url: 'https://nav.ediy.net', color: '#eb2f96' },
  { t: '站内通知 · 滚动广播与未读提醒', url: 'https://nav.ediy.net', color: '#2f7bff' },
  { t: '用户管理 · 收录审核 · 权限分配', url: 'https://nav.ediy.net', color: '#faad14', bold: 1 },
  { t: '系统设置 · 站点外观自由配置', url: 'https://nav.ediy.net', color: '#13c2c2' },
  { t: '数据管理 · 一键导入导出备份', url: 'https://nav.ediy.net', color: '#6d5bd0', italic: 1 },
  { t: '在线升级 · 一键检测最新版本', url: 'https://nav.ediy.net', color: '#52c41a', bold: 1 },
  { t: '离线升级包 · 断网环境轻松升级', url: 'https://nav.ediy.net', color: '#5f6b7a' },
  { t: '操作日志 · 全程留痕可追溯', url: 'https://nav.ediy.net', color: '#2f7bff' },
  { t: '浏览器设为首页 · 一键快捷访问', url: 'https://nav.ediy.net', color: '#0f9d58' },
  { t: '暗黑主题 · 夜间浏览更舒适', url: 'https://nav.ediy.net', color: '#7c8798' },
  { t: '专业版订阅 · 关闭全站广告', url: 'https://nav.ediy.net', color: '#fa8c16', bold: 1 },
  { t: '激活码激活 · 短码在线秒用', url: 'https://nav.ediy.net', color: '#13c2c2' },
  { t: '在线购买 · 付款秒发激活码', url: 'https://nav.ediy.net', color: '#d64550', italic: 1 },
  { t: '我的订单 · 随时查看与一键激活', url: 'https://nav.ediy.net', color: '#2f7bff' },
  { t: '广告位招商中 · 联系开发者投放', url: 'https://nav.ediy.net', color: '#0f9d58', bold: 1 }
];
const SAMPLE_AD_POPUP_IMG = "/img/ads/popup.gif"; // v0.99.45 GIF 动图示例：右下角弹窗 520×240
// v0.99.25：免费版分组配额 5→6，存量库幂等补齐第 6 组「效率办公」示例（不覆盖用户已有数据，升级用户同样可见）
function ensureSeedGroups() {
  try {
    const findG = (name) => db.prepare('SELECT id FROM groups WHERE name = ? ORDER BY id LIMIT 1').get(name);
    if (findG('效率办公')) return;
    const insG = db.prepare('INSERT INTO groups(name, icon, sort, scene, show_in_nav, is_recommend, admin_only) VALUES(?,?,?,?,?,?,?)');
    const insS = db.prepare('INSERT INTO sites(group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode) VALUES(?,?,?,?,?,?,?,?,?,?)');
    const g = insG.run('效率办公', 'app', 999, '工作', 1, 0, 0);
    insS.run(g.lastInsertRowid, '语雀', 'auto', null, null, null, 'https://www.yuque.com', 0, '云端知识库 / 文档协作', 'new');
    insS.run(g.lastInsertRowid, '腾讯文档', 'auto', null, null, null, 'https://docs.qq.com', 1, '在线协作文档', 'new');
    insS.run(g.lastInsertRowid, '飞书', 'auto', null, null, null, 'https://www.feishu.cn', 2, '一站式协同办公平台', 'new');
    console.log('[天枢导航] 已补齐第 6 组示例「效率办公」（免费版分组配额 ≤6，示例分组与配额上限持平，达到上限时可删除示例分组）');
  } catch (e) { console.error('[天枢导航] ensureSeedGroups', e.message); }
}

function seedSampleData(admin, opts) {
  opts = opts || {};
  const keepGroups = !!opts.keepGroups;
  const insG = db.prepare('INSERT INTO groups(name, icon, sort, scene, show_in_nav, is_recommend, admin_only) VALUES(?,?,?,?,?,?,?)');
  const insS = db.prepare('INSERT INTO sites(group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode) VALUES(?,?,?,?,?,?,?,?,?,?)');
  const findG = (name) => db.prepare('SELECT id FROM groups WHERE name = ? ORDER BY id LIMIT 1').get(name);
  const gid = (name) => {
    if (keepGroups) { const e = findG(name); if (e) return e.id; }
    const r = insG.run(name, iconFor(name), 999, sceneFor(name), 1, isRec(name), isAdminOnly(name));
    return r.lastInsertRowid;
  };
  const S = (gname, name, intra, extra, remark) => insS.run(gid(gname), name, 'auto', null, null, intra || null, extra || null, 0, remark || '', 'new');
  S('开发工具', 'GitLab 代码仓库', 'http://192.168.100.2:9080/', null, '内网 Git 代码托管');
  S('开发工具', 'Jenkins 构建平台', 'http://192.168.100.2:8080/', null, '持续集成 / 自动构建');
  S('开发工具', '宝塔面板', 'http://192.168.100.2:8888/', null, '服务器管理后台');
  S('AI 工具', 'AI 工具导航', null, 'https://tools-ai.cn', '常用 AI 站点聚合');
  S('AI 工具', '慧剪辑官网', null, 'https://hui-clip.cn', '视频剪辑工具');
  S('系统服务', 'NAS 管理台', 'http://192.168.100.2:5666/', null, '飞牛 NAS 管理（管理员专属）');
  S('系统服务', '路由器管理', 'http://192.168.100.1/', null, '网关配置（管理员专属）');
  S('影音娱乐', '哔哩哔哩', null, 'https://www.bilibili.com', '视频弹幕网站');
  S('影音娱乐', 'YouTube', null, 'https://www.youtube.com', '海外视频平台');
  S('常用搜索', '百度', null, 'https://www.baidu.com', '');
  S('常用搜索', '必应', null, 'https://www.bing.com', '');
  S('常用搜索', '谷歌', null, 'https://www.google.com', '');
  S('效率办公', '语雀', null, 'https://www.yuque.com', '云端知识库 / 文档协作');
  S('效率办公', '腾讯文档', null, 'https://docs.qq.com', '在线协作文档');
  S('效率办公', '飞书', null, 'https://www.feishu.cn', '一站式协同办公平台');
  const insN = db.prepare('INSERT INTO notices(title, content, level, pinned, published, created_by) VALUES(?,?,?,?,?,?)');
  insN.run('欢迎使用天枢导航', '这是一条示例站内通知。管理员可以在后台「站内通知」中发布图文混排的重要消息，置顶消息会优先展示。开发者还可通过云端服务平台向所有用户推送「系统通知」，首页右上角广播按钮会红色标出未读数量。', 'important', 1, 1, admin.id);
  // 示例广告数据（免费版与专业版默认均展示，管理员可在后台系统设置关闭；可由服务器端远端推送覆盖）
  // v0.99.72：在线演示（DEMO=1）环境出厂默认「关」由启动时设置（上方 DEMO 块），此处不得覆盖——否则新部署示例数据初始化会把广告重新打开
  if (!DEMO) setSetting('ad_enabled', '1');
  // R104-B6：顶部横幅位（ad_text_top / ad_image_top）不再补种示例广告——首页顶部横幅由推广返佣（远端 slots.top）默认接管；
  // 无远端推送时该位留空不显示，避免旧示例文案/图片残留（R115 已清升级补种，此处同步清初始化补种）
  setSetting('ad_text_top', '');
  setSetting('ad_image_top', '');
  setSetting('ad_image_link', '');
  setSetting('ad_popup_enabled', '1');
  // 右下角弹窗广告示例：适配弹窗容器的图片广告（520×240 SVG，推广本系统；开发者后台可配置真实图片/HTML 覆盖）
  setSetting('ad_popup_text', '<a href="https://nav.ediy.net" target="_blank" rel="noopener"><img src="' + SAMPLE_AD_POPUP_IMG + '" alt="广告" style="display:block;width:100%;border-radius:10px"></a>');
  // 站内通知下方：四列图片广告（v1.0.6 字段 ad_img_cols；未配置时首页显示图片化推广占位，默认沾满）
  setSetting('ad_img_cols', JSON.stringify([
    { image: SAMPLE_AD_COL_IMG1, link: 'https://nav.ediy.net', title: '天枢导航 · 内网导航门户' },
    { image: SAMPLE_AD_COL_IMG2, link: 'https://tools-ai.cn', title: 'AI 工具导航 · tools-ai.cn' },
    { image: SAMPLE_AD_COL_IMG3, link: 'https://nav.ediy.net', title: '专业版 · 秒发激活码' },
    { image: SAMPLE_AD_COL_IMG4, link: 'https://nav.ediy.net', title: '天枢导航 · EDIY 出品' }
  ]));
  // 常用搜索功能区下方：四列广告（文字列「标题+最多3行，文字|链接」；图片列「image+link+title」；远端推送可整体覆盖）
  setSetting('ad_cols', JSON.stringify([
    { title: '导航推荐', lines: ['推荐工具导航 tools-ai.cn|https://tools-ai.cn', '视频剪辑神器 hui-clip.cn|https://hui-clip.cn', '天枢导航产品页|https://nav.ediy.net'] },
    { image: SAMPLE_AD_COL_IMG1, link: 'https://nav.ediy.net', title: '天枢导航 · 内网导航门户' },
    { title: '开发资源', lines: ['GitHub 开源社区|https://github.com', 'Docker Hub 镜像|https://hub.docker.com', 'Gitee 码云|https://gitee.com'] },
    { image: SAMPLE_AD_COL_IMG2, link: 'https://tools-ai.cn', title: 'AI 工具导航 · tools-ai.cn' }
  ]));
  // 常用搜索下方：一行 × 四列文字广告（v0.99.25 起由 3×4 改为 1×4；未配置时首页显示推广占位）
  setSetting('ad_text_rows', JSON.stringify([
    { t: '欢迎使用天枢导航 · 内网/外网网址导航门户', url: 'https://nav.ediy.net', color: '#2f7bff', bold: 1 },
    { t: '官网 https://nav.ediy.net', url: 'https://nav.ediy.net', color: '#7b5bff', italic: 1 },
    { t: '内网/外网双地址 · 一键直达常用系统', url: 'https://nav.ediy.net', color: '#0f9d58', bold: 1 },
    { t: '广告位招商中 · 联系开发者投放', url: 'https://nav.ediy.net', color: '#d64550' }
  ]));
  // 分类导航区域之间：1 行 × 5 列 × 5 个分类间隔（v0.99.30 起 25 个位置独立配置：间隔 k 对应第 k*5+1 ~ k*5+5 条，展示于第 k 个分类下方）
  setSetting('ad_between', JSON.stringify(AD_BETWEEN_SEED_25));
  // 首页底部整条图片 + 超链接广告（付费订阅用户自动隐藏）
  setSetting('ad_footer_enabled', '1');
  setSetting('ad_footer_image', SAMPLE_FOOTER_BANNER);
  setSetting('ad_footer_link', 'https://nav.ediy.net');
  // 站内搜索默认目标地址（常用搜索卡片「站内」引擎空关键词落地页）
  setSetting('site_search_url', 'https://nav.ediy.net');
  // 站内购买收款二维码（支付宝当面付个人收款码；远端配置可覆盖推送）
  setSetting('pay_qrcode', SAMPLE_PAY_QR);
  setSetting('sample_seeded', '1');
  seedSampleIcons(admin);
}

// v0.99.52：公共图库示例图标补种（仅当图标库为空时写入 3 个内置示例，不覆盖管理员上传）
// 图标为深蓝科技风 SVG（与全局主题一致），落盘 DATA_DIR/icons/library/ 供图库列表展示
const SAMPLE_LIB_ICONS = [
  { name: 'GitLab 代码仓库', category: '开发工具', filename: 'sample-gitlab.svg',
    svg: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'><defs><linearGradient id='g1' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#2f7bff'/><stop offset='1' stop-color='#7b5bff'/></linearGradient></defs><rect x='4' y='4' width='88' height='88' rx='20' fill='url(#g1)'/><path d='M48 22l8 20-8 16-8-16 8-20z' fill='none' stroke='#fff' stroke-width='4' stroke-linejoin='round'/><path d='M40 42h16M48 22v36' stroke='#fff' stroke-width='4' stroke-linecap='round' fill='none'/></svg>" },
  { name: '全球网络', category: '通用', filename: 'sample-globe.svg',
    svg: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'><circle cx='48' cy='48' r='40' fill='none' stroke='#2f7bff' stroke-width='5'/><ellipse cx='48' cy='48' rx='40' ry='16' fill='none' stroke='#7b5bff' stroke-width='3'/><path d='M8 48h80M22 26c14 8 18 12 52 8M22 70c14-8 18-12 52-8' fill='none' stroke='#7b5bff' stroke-width='3' opacity='.8'/><circle cx='48' cy='48' r='9' fill='#2f7bff'/></svg>" },
  { name: 'AI 智能芯片', category: 'AI 工具', filename: 'sample-ai.svg',
    svg: "<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 96 96'><defs><linearGradient id='g2' x1='0' y1='0' x2='1' y2='1'><stop offset='0' stop-color='#2f7bff'/><stop offset='1' stop-color='#0f9d58'/></linearGradient></defs><rect x='20' y='20' width='56' height='56' rx='12' fill='url(#g2)'/><rect x='34' y='34' width='28' height='28' rx='6' fill='#0b1220' opacity='.85'/><path d='M34 48h28M48 34v28' stroke='#2f7bff' stroke-width='3'/><g stroke='#7b5bff' stroke-width='4' stroke-linecap='round'><path d='M20 34h-9M20 48h-9M20 62h-9M85 34h-9M85 48h-9M85 62h-9M34 20v-9M48 20v-9M62 20v-9M34 85v-9M48 85v-9M62 85v-9'/></g></svg>" }
];
function seedSampleIcons(admin) {
  try {
    const n = db.prepare('SELECT COUNT(*) c FROM icons').get().c;
    if (Number(n) > 0) return; // 已有图标（含用户上传）不补种
    const fs = require('fs');
    fs.mkdirSync(ICON_LIB_DIR, { recursive: true });
    const ins = db.prepare('INSERT INTO icons(name, filename, category, uploaded_by) VALUES(?,?,?,?)');
    for (const it of SAMPLE_LIB_ICONS) {
      fs.writeFileSync(path.join(ICON_LIB_DIR, it.filename), it.svg, 'utf8');
      ins.run(it.name, it.filename, it.category, admin.id);
    }
    console.log('[天枢导航] 已补种公共图库示例图标（' + SAMPLE_LIB_ICONS.length + ' 个）');
  } catch (e) { console.error('[天枢导航] seedSampleIcons', e.message); }
}
function iconFor(name) {
  const map = { '开发工具': 'code', 'AI 工具': 'cloud', '系统服务': 'server', '影音娱乐': 'app', '常用搜索': 'link', '效率办公': 'app' };
  return map[name] || 'link';
}
function sceneFor(name) {
  const map = { '开发工具': '工作室', 'AI 工具': '工作室', '系统服务': '公司', '影音娱乐': '家庭', '常用搜索': '个人', '效率办公': '工作' };
  return map[name] || '个人';
}
function isRec(name) { return (name === '开发工具' || name === 'AI 工具') ? 1 : 0; }
function isAdminOnly(name) { return name === '系统服务' ? 1 : 0; }
app.post('/api/admin/sample-data/init', requireSuper, (req, res) => {
  const pwd = ((req.body || {}).password || '').trim();
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const ok = u && pwd && crypto.scryptSync(pwd, u.salt, 64).toString('hex') === u.password_hash;
  if (!ok) return res.status(403).json({ ok: false, error: '管理员密码验证失败，已取消' });
  // 一键初始化：清空站点/通知/申请等业务数据，保留分类（分组）、系统设置与用户，再重建示例数据
  db.prepare('DELETE FROM sites').run();
  db.prepare('DELETE FROM notices').run();
  db.prepare('DELETE FROM notice_reads').run();
  db.prepare('DELETE FROM site_applications').run();
  db.prepare('DELETE FROM invite_codes').run();
  seedSampleData(req.user, { keepGroups: true });
  logOp(req.user, '一键初始化', '已清空站点/通知/申请并重建示例数据（保留分类与设置）');
  res.json({ ok: true, note: '一键初始化完成：站点数据已重置为示例，分类与系统设置保留' });
});
app.post('/api/admin/sample-data/clear', requireSuper, (req, res) => {
  const pwd = ((req.body || {}).password || '').trim();
  const u = db.prepare('SELECT * FROM users WHERE id = ?').get(req.user.id);
  const ok = u && pwd && crypto.scryptSync(pwd, u.salt, 64).toString('hex') === u.password_hash;
  if (!ok) return res.status(403).json({ ok: false, error: '管理员密码验证失败，已取消' });
  // 清空全站数据：清空全部业务数据（站点/分组/通知/申请/邀请码/普通用户收藏），保留系统设置与管理员账号
  db.prepare('DELETE FROM sites').run();
  db.prepare('DELETE FROM groups').run();
  db.prepare('DELETE FROM notices').run();
  db.prepare('DELETE FROM notice_reads').run();
  db.prepare('DELETE FROM site_applications').run();
  db.prepare('DELETE FROM invite_codes').run();
  db.prepare('DELETE FROM users WHERE role != ?').run('admin');
  setSetting('sample_seeded', '0');
  logOp(req.user, '清空全站数据', '站点/分组/通知/申请/邀请码/普通用户已清空（设置与管理员保留）');
  res.json({ ok: true, note: '全站数据已清空（系统设置与管理员账号保留）' });
});

// ---------- 导入 / 导出 ----------
app.get('/api/export', requireSuper, (req, res) => {
  const settings = getSettings();
  delete settings.smtp_pass;
  delete settings.license_key;
  delete settings.license_type;
  delete settings.license_expire;
  const payload = {
    product: 'tianshu-nav', product_name: APP_NAME, version: APP_VERSION, exported_at: new Date().toISOString(),
    settings,
    groups: db.prepare('SELECT * FROM groups ORDER BY sort ASC').all(),
    sites: db.prepare('SELECT * FROM sites ORDER BY sort ASC').all(),
    notices: db.prepare('SELECT id, title, content, content_html, level, pinned, published, created_at FROM notices ORDER BY id ASC').all()
  };
  res.setHeader('Content-Disposition', `attachment; filename="tianshu-nav-export-${new Date().toISOString().slice(0, 10)}.json"`);
  res.json({ ok: true, export: payload });
});

function applyImport(payload, strategy) {
  if (!payload || payload.product !== 'tianshu-nav') return { ok: false, error: '文件格式不正确或不是天枢导航导出文件' };
  if (strategy === 'overwrite') {
    db.prepare('DELETE FROM sites').run();
    db.prepare('DELETE FROM groups').run();
    db.prepare('DELETE FROM notices').run();
    db.prepare('DELETE FROM notice_reads').run();
    for (const g of payload.groups || []) db.prepare('INSERT INTO groups(id, name, icon, sort, scene, show_in_nav) VALUES(?,?,?,?,?,?)').run(g.id, g.name, g.icon || 'folder', g.sort || 0, g.scene || '', g.show_in_nav === undefined || g.show_in_nav ? 1 : 0);
    for (const s of payload.sites || []) db.prepare('INSERT INTO sites(group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode, status, net_flag, net_flag_val, visibility) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(s.group_id, s.name, s.icon_type || 'auto', s.icon_ref || null, s.icon_auto || null, s.intranet_url, s.extranet_url || null, s.sort || 0, s.remark || '', s.open_mode || 'new', s.status || 'active', s.net_flag || 'auto', s.net_flag_val || null, s.visibility === 'private' ? 'private' : 'public');
    for (const n of payload.notices || []) db.prepare('INSERT INTO notices(title, content, content_html, level, pinned, published, created_at) VALUES(?,?,?,?,?,?,?)')
      .run(n.title, n.content, n.content_html || null, n.level || 'info', n.pinned ? 1 : 0, n.published === undefined ? 1 : n.published, n.created_at || new Date().toISOString());
    if (payload.settings) { const s = { ...payload.settings }; delete s.smtp_pass; setSettings(s); }
    return { ok: true, groups: (payload.groups || []).length, sites: (payload.sites || []).length, notices: (payload.notices || []).length };
  }
  // merge：按名称去重
  const gMap = {};
  const nameOf = (g) => g.name.trim();
  let gCount = 0, sCount = 0;
  for (const g of payload.groups || []) {
    const exist = db.prepare('SELECT * FROM groups WHERE name = ?').get(nameOf(g));
    if (exist) gMap[g.id] = exist.id;
    else {
      const info = db.prepare('INSERT INTO groups(name, icon, sort, scene, show_in_nav) VALUES(?,?,?,?,?)').run(nameOf(g), g.icon || 'folder', (g.sort || 0), g.scene || '', g.show_in_nav === undefined || g.show_in_nav ? 1 : 0);
      gMap[g.id] = info.lastInsertRowid; gCount++;
    }
  }
  for (const s of payload.sites || []) {
    const dup = db.prepare('SELECT * FROM sites WHERE name = ? AND intranet_url = ?').get(s.name, s.intranet_url);
    if (dup) continue;
    db.prepare('INSERT INTO sites(group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode, status, net_flag, net_flag_val, visibility) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)')
      .run(gMap[s.group_id] || 1, s.name, s.icon_type || 'auto', s.icon_ref || null, s.icon_auto || null, s.intranet_url, s.extranet_url || null, s.sort || 0, s.remark || '', s.open_mode || 'new', s.status || 'active', s.net_flag || 'auto', s.net_flag_val || null, s.visibility === 'private' ? 'private' : 'public');
    sCount++;
  }
  return { ok: true, groups: gCount, sites: sCount, notices: 0 };
}

app.post('/api/import', requireSuper, (req, res) => {
  const { payload, strategy } = req.body || {};
  const r = applyImport(payload, strategy === 'merge' ? 'merge' : 'overwrite');
  if (!r.ok) return res.status(400).json(r);
  logOp(req.user, '导入配置', `策略=${strategy || 'overwrite'}，分组${r.groups}，站点${r.sites}`);
  res.json(r);
});
app.post('/api/import/bookmarks', requireSuper, (req, res) => {
  const items = (req.body && req.body.items) || [];
  if (!Array.isArray(items) || !items.length) return res.status(400).json({ ok: false, error: '没有可导入的书签' });
  let gCount = 0, sCount = 0;
  const gCache = {};
  for (const it of items) {
    const gname = (it.group || '导入书签').trim();
    if (!gCache[gname]) {
      let g = db.prepare('SELECT * FROM groups WHERE name = ?').get(gname);
      if (!g) { const info = db.prepare('INSERT INTO groups(name, icon, sort) VALUES(?,?,?)').run(gname, 'bookmark', 9999); g = { id: info.lastInsertRowid }; gCount++; }
      gCache[gname] = g.id;
    }
    if (!it.url || !/^https?:\/\//i.test(it.url)) continue;
    const dup = db.prepare('SELECT * FROM sites WHERE name = ? AND intranet_url = ?').get(it.name, it.url);
    if (dup) continue;
    db.prepare('INSERT INTO sites(group_id, name, icon_type, icon_ref, icon_auto, intranet_url, extranet_url, sort, remark, open_mode, status) VALUES(?,?,?,?,?,?,?,?,?,?,?)')
      .run(gCache[gname], it.name.trim(), 'auto', null, null, it.url, it.url, 9999, '', 'new', 'active');
    sCount++;
  }
  logOp(req.user, '导入书签', `${items.length} 条，新建分组${gCount}，新建站点${sCount}`);
  res.json({ ok: true, total: items.length, groups: gCount, sites: sCount });
});

// ---------- 升级 ----------
// 升级问题反馈：转发到服务器端（远端 /api/v1/feedback 汇聚），供开发者后台统一查看处理
app.post('/api/feedback', requirePerm('contact'), async (req, res) => {
  const content = String((req.body || {}).content || '').trim();
  const contact = String((req.body || {}).contact || '').trim();
  if (!content) return res.status(400).json({ ok: false, error: '请填写问题描述' });
  const base = lic.remoteBase();
  // v0.99.72：演示环境反馈本地模拟——不把演示数据上送线上反馈池
  if (DEMO) return res.json(demoMock({ note: '在线演示环境：反馈已模拟提交（不会送达开发者）' }));
  if (!base) return res.json({ ok: false, error: '远程反馈服务未就绪；可直接联系开发者（微信 LiuLian-8090 / 邮箱 13002501616@163.com）' });
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 8000);
    const r = await fetch(base + '/api/v1/feedback', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ instanceId: lic.instanceId(), version: APP_VERSION, content, contact: contact || String(req.user.email || ''), account: String(req.user.email || '') }),
      signal: ctl.signal
    });
    clearTimeout(timer);
    const j = await r.json().catch(() => ({}));
    if (j && j.ok) {
      logOp(req.user, '提交问题反馈', '反馈已提交（' + APP_VERSION + '）');
      return res.json({ ok: true, note: '反馈已提交，我们将尽快处理' });
    }
    return res.json({ ok: false, error: (j && j.reason) || '反馈提交失败（HTTP ' + r.status + '）' });
  } catch (e) {
    return res.json({ ok: false, error: '远程反馈服务无法连接（' + (e.name === 'AbortError' ? '请求超时' : e.message) + '）' });
  }
});
// 「联系我们」：查询本人反馈与开发者回复（转发远端 /api/v1/feedback/list，展示处理结果）
app.get('/api/feedback/list', requirePerm('contact'), async (req, res) => {
  const base = lic.remoteBase();
  if (!base) return res.json({ ok: true, list: [] });
  try {
    const ctl = new AbortController();
    const timer = setTimeout(() => ctl.abort(), 8000);
    const r = await fetch(base + '/api/v1/feedback/list?instanceId=' + encodeURIComponent(lic.instanceId()) + '&account=' + encodeURIComponent(String(req.user.email || '')), { signal: ctl.signal });
    clearTimeout(timer);
    const j = await r.json().catch(() => ({}));
    return res.json({ ok: true, list: (j && j.list) || [] });
  } catch { return res.json({ ok: true, list: [] }); }
});
function currentVersionInfo() {
  // v0.99.47：版本日志仅正式版展示，测试版 latest_log 返回 null
  const logs = isFormalVersion(APP_VERSION)
    ? db.prepare('SELECT version, log, created_at FROM version_log ORDER BY id DESC LIMIT 1').get()
    : null;
  return { version: APP_VERSION, build: APP_BUILD, latest_log: logs || null };
}
// R167：在线升级的「更新源地址」与「远端拉取」抽成单一实现。
// 此前 /api/upgrade/check 与 /api/upgrade/online 各写一份逐字相同的拉取逻辑（第二份已在漂移：online 的
// on('aborted') 处理只存在于其中一份），改一处漏一处必然导致「检查说有新版、升级却说没有」。
function resolveUpgradeUrl() {
  // 更新源：优先取远端「更新源」配置（云端开发者后台配置），其次回退本地 update_url（兼容旧配置）
  const rc = lic.cached() || {};
  const updates = (rc && rc.updates) || null;
  let url = null;
  if (updates && updates.enabled !== false) url = updates.custom || 'https://nav.ediy.net/upgrade/upgrade.json';
  if (!url) url = getSetting('update_url');
  return url || null;
}
function fetchRemoteUpgrade(url) {
  return new Promise((resolve) => {
    if (!url || !/^https?:\/\//i.test(url)) return resolve(null);
    try {
      const https = require('https');
      https.get(url, { timeout: 8000 }, (r) => {
        if (r.statusCode !== 200) { r.resume(); return resolve(null); }
        const chunks = [];
        r.on('data', (c) => chunks.push(c));
        r.on('end', () => { try { resolve(JSON.parse(Buffer.concat(chunks).toString())); } catch (e) { resolve(null); } });
        r.on('aborted', () => resolve(null));
      }).on('error', () => resolve(null));
    } catch (e) { resolve(null); }
  });
}
app.get('/api/upgrade/check', async (req, res) => {
  // v0.99.72：演示环境不支持在线升级（demo 随云端升级包同步更新，无需客户端侧在线升级）
  if (DEMO) return res.json({ ok: true, current: APP_VERSION, remote: null, has_update: false, demo: true, note: '在线演示环境：版本由平台统一维护，不支持在线升级' });
  const url = resolveUpgradeUrl();
  const remote = await fetchRemoteUpgrade(url);
  const remoteVersion = remote && (remote.version || remote.latest) ? (remote.version || remote.latest) : null;
  // 第 104 轮：同版本覆盖安装支持——修复轮不递增版本号时，远端同版本新包同样允许覆盖重装（has_same 供前端提示）
  const hasUpdate = remoteVersion ? (compareVer(remoteVersion, APP_VERSION) > 0) : false;
  const hasSame = remoteVersion ? (compareVer(remoteVersion, APP_VERSION) === 0) : false;
  res.json({ ok: true, current: APP_VERSION, remote: remote || null, has_update: hasUpdate, has_same: hasSame, url });
});
// R167（产品方需求）：超管进管理后台时主动检测更新，由用户自己决定是否升级。
// 与上面 /api/upgrade/check 的四处差异，每一处都是这一轮的必需项：
//   1) requireSuper —— 原接口匿名可打，任何人都能让服务器去外呼更新源（放大与探测面）；
//   2) 成功结果缓存 6 小时 —— 「进后台就检测」若每次都外呼，等于把更新源当心跳打；
//   3) 失败结果只缓存 10 分钟 —— 内网/断网设备不必每次进后台都等满 8 秒超时；
//   4) 遵守「自动检查更新」总开关，关掉时直接返回 skipped 且不发起外呼（内网合规客户不希望设备主动外联）。
const UPGRADE_CACHE_OK_MS = 6 * 3600 * 1000;
const UPGRADE_CACHE_FAIL_MS = 10 * 60 * 1000;
let upgradeCheckCache = { url: null, at: 0, remote: null };
app.get('/api/admin/upgrade/check', requireSuper, async (req, res) => {
  if (DEMO) return res.json({ ok: true, current: APP_VERSION, remote: null, has_update: false, has_same: false, demo: true });
  const auto = getSetting('auto_check_update') !== '0';
  const force = String((req.query && req.query.force) || '') === '1';
  if (!auto && !force) {
    return res.json({ ok: true, skipped: true, auto: false, current: APP_VERSION, remote: null, has_update: false, has_same: false });
  }
  const url = resolveUpgradeUrl();
  const now = Date.now();
  const ttl = upgradeCheckCache.remote ? UPGRADE_CACHE_OK_MS : UPGRADE_CACHE_FAIL_MS;
  let hit = upgradeCheckCache.url === url && (now - upgradeCheckCache.at) < ttl;
  // force：面板里手动「检查更新」要拿实时结果，不能被 6 小时缓存挡住
  if (force) hit = false;
  let remote = upgradeCheckCache.remote;
  let cached = true;
  if (!hit) {
    remote = await fetchRemoteUpgrade(url);
    upgradeCheckCache = { url: url, at: now, remote: remote };
    cached = false;
  }
  const remoteVersion = remote && (remote.version || remote.latest) ? (remote.version || remote.latest) : null;
  // R167 决策 A：同版本覆盖包（has_same）不触发弹窗——修复轮不递增版本号时弹「发现新版本」会困惑超管，
  // 该场景只在「在线升级」面板手动检查时提示。此处仍如实返回 has_same，由前端自行取舍。
  const hasUpdate = remoteVersion ? (compareVer(remoteVersion, APP_VERSION) > 0) : false;
  const hasSame = remoteVersion ? (compareVer(remoteVersion, APP_VERSION) === 0) : false;
  res.json({
    ok: true, auto: true, cached: cached, checkedAt: upgradeCheckCache.at,
    current: APP_VERSION, remote: remote || null,
    has_update: hasUpdate, has_same: hasSame, url: url
  });
});
// v0.99.38：版本比对统一剔除 v 前缀（如 'v0.99.36'），避免 Number('v0')=NaN 导致在线升级检测失效。
// R133 / B-14：实现已上移至 ./version.js（唯一真源，与云端 src/version.js 字节一致），
// 此处仅转出引用，禁止再就地写第二份（原实现只在本文件，与 db.js / 云端 api.js 口径不同）。
const { compareVer, isFormalVersion } = require('./version');

// v0.99.6 新增设置字段默认值补齐（仅当不存在/为空时写入，不覆盖管理员或远端已配置值）
function ensureNewSettingDefaults() {
  const DEFAULTS = {
    site_search_url: 'https://nav.ediy.net',
    // R167：超管进后台自动检测更新（弹窗提醒）的总开关，默认开启；置 '0' 后客户端不再主动外联更新源
    auto_check_update: '1',
    ddns_cfg: '',
    pay_qrcode: SAMPLE_PAY_QR,
    ad_footer_enabled: '1',
    ad_footer_image: SAMPLE_FOOTER_BANNER,
    ad_footer_link: 'https://nav.ediy.net',
    ad_cols: JSON.stringify([
      { title: '导航推荐', lines: ['推荐工具导航 tools-ai.cn|https://tools-ai.cn', '视频剪辑神器 hui-clip.cn|https://hui-clip.cn', '天枢导航产品页|https://nav.ediy.net'] },
      { image: SAMPLE_AD_COL_IMG1, link: 'https://nav.ediy.net', title: '天枢导航 · 内网导航门户' },
      { title: '开发资源', lines: ['GitHub 开源社区|https://github.com', 'Docker Hub 镜像|https://hub.docker.com', 'Gitee 码云|https://gitee.com'] },
      { image: SAMPLE_AD_COL_IMG2, link: 'https://tools-ai.cn', title: 'AI 工具导航 · tools-ai.cn' }
    ])
  };
  for (const [k, v] of Object.entries(DEFAULTS)) {
    if (getSetting(k) === undefined || getSetting(k) === null || getSetting(k) === '') setSetting(k, v);
  }
}

// v0.99.25：示例广告升级补种（仅当字段缺失或仍是旧示例默认值时覆盖为新版示例，不触碰用户自定义配置）
// v0.99.31：四张示例广告升级为差异化 PNG（顶部蓝 / 中部绿 / 底部紫 / 弹窗橙）；旧 SVG 示例均含
// 「data:image/svg+xml + linearGradient + 0b1f4d（旧渐变蓝）」特征，据此识别并替换，用户自定义图片不受影响
// v0.99.34：识别 v0.99.33 轮旧 PNG 示例（顶部 23514 / 中部 24038 / 底部 37942 / 弹窗 src 39278）并替换为本轮更大气示例图
function ensureAdDefaults() {
  try {
    const isOldSvg = (v) => typeof v === 'string' && v.indexOf('data:image/svg+xml') === 0
      && (v.length <= 200 || v.indexOf('gradient') >= 0 || v.indexOf('广告') >= 0 || v.indexOf('招商') >= 0 || v.indexOf('天枢') >= 0 || v.indexOf('TIANSHU') >= 0
        // v0.99.49：识别 URL 编码的旧示例 SVG（charset=utf-8 + 640×160 固定尺寸，此前误判为用户自定义导致 4 列图片广告不补种）
        || (v.indexOf('charset=utf-8') >= 0 && v.indexOf("width%3D'640'%20height%3D'160'") >= 0));
    // v0.99.32：识别上一轮（v0.99.31）旧 PNG 示例（按总长度精确匹配，偏差 ≤6），存量库补种为新版更大气示例图
    // v0.99.34：识别 v0.99.33 轮旧 PNG（23514/24038/37942/39278）一并补种
    // 注意：data:image/png;base64, 前缀为 22 字符；旧图总长 19510/20642/31522/23514/24038/37942，弹窗 src 内串长 25198/39278
    const isOldPng = (v, lens) => {
      const arr = [].concat(lens);
      return typeof v === 'string' && v.indexOf('data:image/png;base64,') === 0 && arr.some((L) => Math.abs(v.length - L) <= 6);
    };
    const popSrcLen = (v) => { const m = /src="(data:image\/png;base64,[^"]+)"/.exec(v); return m ? m[1].length : -1; };
    // v0.99.49：识别旧版示例广告（v0.99.43 及更早的 PNG 文件路径 /img/ads/top.png 等，以及内嵌 SVG/PNG base64），
    // 统一补种为 v0.99.45 起的新 GIF 动图示例；用户自定义值（非示例特征）一律不覆盖
    const OLD_PNG_PATHS = ['/img/ads/top.png', '/img/ads/mid.png', '/img/ads/footer.png', '/img/ads/popup.png', '/img/ads/notify1.png', '/img/ads/notify2.png', '/img/ads/notify3.png', '/img/ads/notify4.png'];
    const isOldSampleImg = (v) => typeof v === 'string' && (OLD_PNG_PATHS.indexOf(v) >= 0 || isOldSvg(v) || isOldPng(v, [19510, 20642, 23514, 24038, 31522, 37942, 39278, 25198]));
    const isOldSampleArr = (v) => {
      if (typeof v !== 'string') return false;
      let a = null; try { a = JSON.parse(v); } catch { return false; }
      if (!Array.isArray(a) || !a.length) return false;
      // 数组任一项的 image 字段命中旧示例特征即视为旧示例广告，整组补种
      return a.some((it) => it && typeof it.image === 'string' && isOldSampleImg(it.image));
    };
    // ① 首页顶部横幅（1200×50）：第 104 轮起顶部横幅位不再补种示例广告——
    // 未配置或旧示例（含 v0.99.45 起补种的 top.gif 新示例）一律清空，前端默认显示「推广返佣」占位横幅；
    // 仅管理员后台/云端显式配置顶部广告（含云端 rads.top 推送）后才显示广告
    if (!getSetting('ad_image_top') || isOldSampleImg(getSetting('ad_image_top')) || getSetting('ad_image_top') === SAMPLE_AD_IMAGE) {
      setSetting('ad_image_top', '');
    }
    // ② 1+1+1 与站内通知之间整条横幅（v0.99.72 起已删除该广告位，存量配置不再补种/展示）
    // ③ 首页底部整条横幅（1200×100 紫色示例）
    if (!getSetting('ad_footer_image') || isOldSampleImg(getSetting('ad_footer_image'))) {
      setSetting('ad_footer_image', SAMPLE_FOOTER_BANNER);
      if (!getSetting('ad_footer_link')) setSetting('ad_footer_link', 'https://nav.ediy.net');
    }
    // ④ 右下角弹窗（520×240 橙色示例）：旧示例为 SVG 渐变图（含 0b1f4d）或旧 PNG 文件/内嵌，识别后替换为 GIF
    const pop = getSetting('ad_popup_text');
    if (!pop || (pop.indexOf('<img') < 0 && pop.indexOf('欢迎使用天枢导航') >= 0) || (pop.indexOf('data:image/svg+xml') >= 0 && pop.indexOf('0b1f4d') >= 0) || (pop.indexOf('<img') >= 0 && [25198, 39278].indexOf(popSrcLen(pop)) >= 0) || (pop.indexOf('<img') >= 0 && /src="\/img\/ads\/popup\.png"/.test(pop))) {
      setSetting('ad_popup_text', '<a href="https://nav.ediy.net" target="_blank" rel="noopener"><img src="' + SAMPLE_AD_POPUP_IMG + '" alt="广告" style="display:block;width:100%;border-radius:10px"></a>');
    }
    let tr = [];
    try { tr = JSON.parse(getSetting('ad_text_rows') || '[]'); } catch {}
    if (!tr.length || tr.length >= 12) {
      setSetting('ad_text_rows', JSON.stringify([
        { t: '欢迎使用天枢导航 · 内网/外网网址导航门户', url: 'https://nav.ediy.net', color: '#2f7bff', bold: 1 },
        { t: '官网 https://nav.ediy.net', url: 'https://nav.ediy.net', color: '#7b5bff', italic: 1 },
        { t: '内网/外网双地址 · 一键直达常用系统', url: 'https://nav.ediy.net', color: '#0f9d58', bold: 1 },
        { t: '广告位招商中 · 联系开发者投放', url: 'https://nav.ediy.net', color: '#d64550' }
      ]));
    }
    let bt = [];
    try { bt = JSON.parse(getSetting('ad_between') || '[]'); } catch {}
    // v0.99.30：5 个分类间隔 × 每间隔 1 行 5 列 = 25 个独立位置；旧默认 5 条（或空）时补种 25 条新版示例，用户自定义不覆盖
    const OLD_B5 = ['开发工具 · AI 工具 · 效率办公聚合导航', '站点管理 · 分组管理 · 公共图库', '专业版激活 · 在线购买秒发激活码', '系统通知 · 公告滚动 · 站内广告统一管理', '常用搜索：站内 / 百度 / 必应 / 谷歌'];
    const isOldDefault = bt.length <= 5 && bt.every((r, idx) => r && typeof r.t === 'string' && r.t === OLD_B5[idx]);
    if (!bt.length || isOldDefault) {
      setSetting('ad_between', JSON.stringify(AD_BETWEEN_SEED_25));
    }
    let ic = [];
    try { ic = JSON.parse(getSetting('ad_img_cols') || '[]'); } catch {}
    // v0.99.49：4 列图片广告——旧示例（SVG/PNG 内嵌或旧 PNG 路径）整组补种为 GIF，用户自定义不覆盖
    if (!ic.length || isOldSampleArr(getSetting('ad_img_cols'))) {
      setSetting('ad_img_cols', JSON.stringify([
        { image: SAMPLE_AD_COL_IMG1, link: 'https://nav.ediy.net', title: '天枢导航 · 内网导航门户' },
        { image: SAMPLE_AD_COL_IMG2, link: 'https://tools-ai.cn', title: 'AI 工具导航 · tools-ai.cn' },
        { image: SAMPLE_AD_COL_IMG3, link: 'https://nav.ediy.net', title: '专业版 · 秒发激活码' },
        { image: SAMPLE_AD_COL_IMG4, link: 'https://nav.ediy.net', title: '天枢导航 · EDIY 出品' }
      ]));
    }
    let colArr = [];
    try { colArr = JSON.parse(getSetting('ad_cols') || '[]'); } catch {}
    // v0.99.49：常用搜索下方四列广告——含旧示例图片的整组补种为 GIF 版，用户自定义不覆盖
    if (!colArr.length || isOldSampleArr(getSetting('ad_cols'))) {
      setSetting('ad_cols', JSON.stringify([
        { title: '导航推荐', lines: ['推荐工具导航 tools-ai.cn|https://tools-ai.cn', '视频剪辑神器 hui-clip.cn|https://hui-clip.cn', '天枢导航产品页|https://nav.ediy.net'] },
        { image: SAMPLE_AD_COL_IMG1, link: 'https://nav.ediy.net', title: '天枢导航 · 内网导航门户' },
        { title: '开发资源', lines: ['GitHub 开源社区|https://github.com', 'Docker Hub 镜像|https://hub.docker.com', 'Gitee 码云|https://gitee.com'] },
        { image: SAMPLE_AD_COL_IMG2, link: 'https://tools-ai.cn', title: 'AI 工具导航 · tools-ai.cn' }
      ]));
    }
    console.log('[天枢导航] 示例广告已按 v0.99.72 规格补种（GIF 动图示例 / 弹窗 / 1×4 文字 / 1×5×5 间隔 / 4 列 GIF；1+1+1 下方横幅广告位已删除）');
  } catch (e) { console.error('[天枢导航] ensureAdDefaults', e.message); }
}

// R160（审计 R2）：升级包验签抽成独立模块（可单测，见 _r160_sig_probe.js）。
// 客户端此前对升级包零校验——一个超管会话就能推自造 zip 覆盖 server/ 与 public/。
// 现与云端同一算法同一密钥，缺签名/包标识不符/验签失败一律 fail-closed。
const { UPGRADE_SIG_NAME, verifyUpgradeSig } = require('./upgradeSig');

// 最小 ZIP 读取器（仅支持 stored / deflate，用于升级包解析）
function unzipToMap(buf) {
  const out = {};
  const rejected = [];   // R153（审计 R8）：路径穿越条目改为「整包 fail-closed」，见下方注释
  const dv = new DataView(buf.buffer, buf.byteOffset, buf.byteLength);
  let eocd = -1;
  for (let i = buf.length - 22; i >= 0; i--) {
    if (buf.readUInt32LE(i) === 0x06054b50) { eocd = i; break; }
  }
  if (eocd < 0) return out;
  const count = buf.readUInt16LE(eocd + 10);
  let off = buf.readUInt32LE(eocd + 16);
  for (let k = 0; k < count; k++) {
    if (buf.readUInt32LE(off) !== 0x02014b50) break;
    const method = buf.readUInt16LE(off + 10);
    const csize = buf.readUInt32LE(off + 20);
    const usize = buf.readUInt32LE(off + 24);
    const nlen = buf.readUInt16LE(off + 28);
    const elen = buf.readUInt16LE(off + 30);
    const clen = buf.readUInt16LE(off + 32);
    const localOff = buf.readUInt32LE(off + 42);
    const name = buf.toString('utf8', off + 46, off + 46 + nlen);
    const localNameLen = buf.readUInt16LE(localOff + 26);
    const localExtraLen = buf.readUInt16LE(localOff + 28);
    const dataStart = localOff + 30 + localNameLen + localExtraLen;
    const comp = buf.subarray(dataStart, dataStart + csize);
    let data;
    if (method === 0) data = comp;
    else if (method === 8) data = zlib.inflateRawSync(comp);
    else { off += 46 + nlen + elen + clen; continue; }
    if (data.length === usize && !name.endsWith('/')) {
      // R133-B3（审计 B-3）：zip-slip 防护。此前直接 out[name]=data，条目名来自 zip 中央目录，
      // 可构造 ../../ 或绝对路径，上层只靠白名单正则 + 路径归一化侥幸没被打穿。
      // 这里在入口处硬拒：绝对路径 / 盘符 / 任何一段为 .. / 含 NUL / 反斜杠回溯。
      const segs = String(name).split(/[\\/]+/);
      const unsafe = name.startsWith('/') || name.startsWith('\\') || /^[A-Za-z]:/.test(name)
        || segs.includes('..') || name.includes('\0');
      // R153（审计 R8 / 纵深防御）：原实现把不安全条目「静默丢弃」——包照样被接受、其余文件照常覆盖，
      // 攻击者既拿不到明确拒绝，运维也看不到异常。改为 fail-closed：只要出现一个逃逸条目，整包拒收。
      if (unsafe) rejected.push(name); else out[name] = data;
    }
    off += 46 + nlen + elen + clen;
  }
  if (rejected.length) {
    const e = new Error('升级包含不安全路径条目（' + rejected.slice(0, 3).join('、') + '），已整包拒绝');
    e.code = 'UNSAFE_ENTRY';
    throw e;
  }
  return out;
}

// 公共升级流程：校验 zip → 持久化到数据卷 → 立即应用并自动重启（无需手动重启容器）
function applyUpgradeZip(req, res, b64, label) {
  const buf = Buffer.from(b64, 'base64');
  if (buf.length > 50 * 1024 * 1024) return res.status(400).json({ ok: false, error: '升级包不能超过 50MB' });
  let files;
  try { files = unzipToMap(buf); } catch (e) {
    // R153（审计 R8）：路径穿越条目走 fail-closed，错误原样回给使用者，不再伪装成「包损坏」
    return res.status(400).json({ ok: false, error: (e && e.code === 'UNSAFE_ENTRY') ? e.message : '升级包解析失败（不是有效的 zip）' });
  }
  const names = Object.keys(files);
  if (!names.length) return res.status(400).json({ ok: false, error: '升级包为空' });
  // 白名单：server/*.js|json 与 public/*（修复历史版本误拒 server/package.json 的问题）
  const WHITE = /^(server\/.+\.(js|json)|public\/.+)$/;
  const bad = names.filter((n) => n !== UPGRADE_SIG_NAME && !WHITE.test(n));
  if (bad.length) return res.status(400).json({ ok: false, error: `升级包含不允许的文件：${bad.slice(0, 5).join(', ')}。请使用「客户端离线升级包」（内含 public/ 与 server/ 文件），勿上传完整部署包` });
  // R160（审计 R2）：完整性签名校验。此前客户端升级包**无任何验签**——
  // 只要拿到内网访问权与一个超管会话，就能推一个自造 zip 覆盖 server/ 与 public/，
  // 等于把整台设备交给对方。云端从 v0.99.66 起就有 Ed25519 验签，客户端一直缺这一环。
  // 现改为与云端同一套算法（rel|字节数|sha256 排序后 sha256），公钥内置，
  // 缺签名 / 包标识不符 / 验签失败一律拒绝，fail-closed。
  const sigCheck = verifyUpgradeSig(files);
  if (!sigCheck.ok) return res.status(400).json({ ok: false, error: sigCheck.reason });
  // 语法检查：升级包内所有 server/*.js 必须通过 node --check（v0.99.60：改 stdin 输入，免疫中文/非 ASCII 数据目录路径）
  const serverFiles = names.filter((n) => n.startsWith('server/') && n.endsWith('.js'));
  for (const n of serverFiles) {
    try { execFileSync(process.execPath, ['--check', '-'], { input: files[n], timeout: 20000, stdio: ['pipe', 'ignore', 'pipe'] }); }
    catch { return res.status(400).json({ ok: false, error: `升级包中 ${n} 语法检查失败，已中止` }); }
  }
  // 读取升级包版本：R150（审计 P1-002）改为「运行期唯一真源 = server.js 的 APP_VERSION」优先。
  // 历史写法先读 server/package.json，一旦构建期漏同步（R147/R149 确实漏了，停在 1.1.000），
  // 官方升级包会被自己的包误判成旧版整包 400 拒绝，离线与在线两条升级通道同时死。
  // 现口径：APP_VERSION 优先 → 取不到才回落 package.json；两者不一致只告警不阻断（构建期由打包断言拦）。
  let newVer = '';
  const verSrc = files['server/server.js'] ? files['server/server.js'].toString('utf8') : '';
  const verM = /APP_VERSION\s*=\s*'([^']+)'/.exec(verSrc);
  if (verM) newVer = verM[1];
  let pkgVer = '';
  try {
    if (files['server/package.json']) {
      const pj = JSON.parse(files['server/package.json'].toString('utf8').replace(/^\uFEFF/, ''));
      if (pj && pj.version) pkgVer = String(pj.version);
    }
  } catch (e) {}
  if (!newVer) newVer = pkgVer;
  if (newVer && pkgVer && newVer !== pkgVer) {
    try { console.warn('[升级] 升级包版本双源不一致：APP_VERSION=' + newVer + ' / package.json=' + pkgVer + '，以 APP_VERSION 为准（构建期应由打包脚本拦下）'); } catch (e) {}
  }
  if (newVer && compareVer(newVer, APP_VERSION) < 0) {
    return res.status(400).json({ ok: false, error: `升级包版本（v${newVer}）低于当前版本（v${APP_VERSION}），已拒绝` });
  }
  // 持久化到数据卷 upgrade/files + meta.json：容器重启/重建后由启动流程自动应用，升级不丢失
  fs.rmSync(UPGRADE_FILES, { recursive: true, force: true });
  fs.mkdirSync(UPGRADE_FILES, { recursive: true });
  for (const n of names) {
    if (n === UPGRADE_SIG_NAME) continue;   // 签名文件只用于校验，不落到代码目录
    const dest = path.join(UPGRADE_FILES, n);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.writeFileSync(dest, files[n]);
  }
  fs.writeFileSync(UPGRADE_META, JSON.stringify({ version: newVer || APP_VERSION, ts: Date.now() }, null, 2));
  // v0.99.47：版本日志按规则仅正式版（≥v1.0.0）写入（seedVersionLog 内部判定）；R95：说明取自 VERSION_HISTORY 真实记录，不写占位文案、不追加无发布记录的版本
  try { seedVersionLog(newVer || APP_VERSION); } catch (e) {}
  // 立即应用：覆盖代码文件；若代码版本已变化则 2 秒后自动重启进程加载新版本（容器/守护自动拉起）
  let restarting = false;
  try { restarting = applyPendingUpgrade(); } catch (e) { console.error('[升级] 应用升级包异常：', e.message); }
  if (!restarting) {
    // 未触发重启（如同版本重复应用）时无需处理；若代码未变但 public 已覆盖，同样已生效
    logOp(req.user, '升级', `已应用${label} v${newVer || APP_VERSION}（无需重启）`);
    return res.json({ ok: true, from: APP_VERSION, to: newVer || APP_VERSION, message: `${label}已应用（v${newVer || APP_VERSION}），页面刷新后生效。`, restarting: false });
  }
  logOp(req.user, '升级', `已应用${label} v${newVer || APP_VERSION}，服务自动重启加载新版本`);
  res.json({ ok: true, from: APP_VERSION, to: newVer || APP_VERSION, message: `${label}已应用（v${newVer || APP_VERSION}），服务正在自动重启，约 5-10 秒后刷新页面查看新版本。`, restarting: true });
}

app.post('/api/upgrade/upload', requireSuper, (req, res) => {
  const { data } = req.body || {};
  if (!data) return res.status(400).json({ ok: false, error: '请上传升级包（zip）' });
  return applyUpgradeZip(req, res, data, '离线升级包');
});

// 在线一键升级：检查远端更新源 → 有新版 → 自动下载升级包 → 校验 → 应用并自动重启
app.post('/api/upgrade/online', requireSuper, async (req, res) => {
  // v0.99.72：演示环境不支持在线升级（版本由平台统一维护）
  if (DEMO) return res.json({ ok: false, demo: true, error: '在线演示环境不支持在线升级：版本由平台统一维护，关闭页面即还原' });
  const url = resolveUpgradeUrl();
  const remote = await fetchRemoteUpgrade(url);
  const remoteVersion = remote && (remote.version || remote.latest) ? (remote.version || remote.latest) : null;
  if (!remoteVersion) return res.status(400).json({ ok: false, error: '检查更新源失败：网络异常或更新源不可用，请稍后重试或改用离线升级包' });
  if (compareVer(remoteVersion, APP_VERSION) < 0) return res.json({ ok: false, error: '更新源版本（' + remoteVersion + '）低于当前版本（' + APP_VERSION + '），已拒绝' });
  // 第 104 轮：同版本（=0）放行下载应用，支持修复轮不递增版本号时的覆盖安装；仅拒绝更低版本
  const zipUrl = remote && (remote.url || remote.download_url);
  if (!zipUrl || !/^https?:\/\//i.test(zipUrl)) return res.status(400).json({ ok: false, error: `更新源未提供升级包下载地址（${remoteVersion}），请联系平台发布新版升级包` });
  let zipBuf = null;
  try {
    const https = require('https');
    zipBuf = await new Promise((resolve) => {
      https.get(zipUrl, { timeout: 30000 }, (r) => {
        if (r.statusCode !== 200) { r.resume(); return resolve(null); }
        const chunks = []; let total = 0;
        r.on('data', (c) => { chunks.push(c); total += c.length; if (total > 50 * 1024 * 1024) { r.destroy(); return resolve(null); } });
        r.on('end', () => resolve(Buffer.concat(chunks)));
        r.on('aborted', () => resolve(null));
      }).on('error', () => resolve(null));
    });
  } catch (e) { zipBuf = null; }
  if (!zipBuf) return res.status(400).json({ ok: false, error: `下载升级包失败（${zipUrl}），请稍后重试或改用离线升级包` });
  return applyUpgradeZip(req, res, zipBuf.toString('base64'), `在线升级包 v${remoteVersion}`);
});
app.get('/api/upgrade/status', requireSuper, (req, res) => {
  let pending = null;
  if (fs.existsSync(UPGRADE_META)) {
    try { pending = JSON.parse(fs.readFileSync(UPGRADE_META, 'utf8')); } catch (e) {}
    // v0.99.49：防御性过滤——待应用版本不高于当前代码版本时视为已消费，清理 meta 防误显示
    if (pending && pending.version && compareVer(String(pending.version), APP_VERSION) <= 0) {
      try { fs.unlinkSync(UPGRADE_META); } catch (e) {}
      pending = null;
    }
  }
  res.json({ ok: true, current: APP_VERSION, pending: pending || null });
});
app.post('/api/upgrade/restart', requireSuper, (req, res) => {
  logOp(req.user, '重启服务', '应用升级后重启容器服务');
  res.json({ ok: true, message: '服务即将重启（约 2 秒后退出，容器将自动拉起新版本）' });
  setTimeout(() => process.exit(0), 2000);
});
app.get('/api/upgrade/backups', requireSuper, (req, res) => {
  res.json({ ok: true, backups: [] });
});
app.post('/api/upgrade/rollback', requireSuper, (req, res) => {
  res.status(400).json({ ok: false, error: '备份与回滚模块已停用（升级前系统会自动备份到数据目录，如需恢复请手动处理）' });
});

// ---------- 错误处理 ----------
app.use((req, res) => res.status(404).json({ ok: false, error: '接口不存在' }));
app.use((err, req, res, next) => {
  // R133-B16（审计 B-16）：二次响应守卫——若响应头已发出，绝不能再写一次（会抛 ERR_HTTP_HEADERS_SENT
  // 且被 Express 吞掉，表现为「日志有错但用户看到成功」）。交给默认处理器断开连接即可。
  if (res.headersSent) {
    console.error('[ERR-AFTER-SENT]', req.method, req.originalUrl, err && err.message ? err.message : err);
    return next(err);
  }
  if (err.type === 'entity.too.large') return res.status(413).json({ ok: false, error: '请求体过大' });
  if (err.type === 'entity.parse.failed') return res.status(400).json({ ok: false, error: '请求体不是合法 JSON' });
  console.error('[ERR]', req.method, req.originalUrl, err && err.stack ? err.stack : err);
  res.status(500).json({ ok: false, error: '服务器内部错误' });
});

// ---------- 启动（端口避让） ----------
// 持久化升级应用：数据卷 upgrade/ 内如有待应用升级且版本高于当前代码版本，则覆盖代码并快速重启加载新版本。
// 容器重建后镜像代码回退时同样会再次应用，保证升级不丢失。
function readCodeVersion() {
  // R150（审计 P1-002 同类点普查）：口径与 applyUpgradeZip 对齐 —— APP_VERSION 是唯一真源。
  // 历史写法先读 server/package.json，滞后时会返回 1.1.000，导致「持久化升级包」每次启动都被判为「比代码新」
  // 而重复覆盖一遍（幂等但白耗 IO + 日志噪音，且有触发重启循环的风险）。
  try {
    const s = fs.readFileSync(path.join(ROOT, 'server', 'server.js'), 'utf8');
    const m = /APP_VERSION\s*=\s*'([^']+)'/.exec(s);
    if (m) return m[1];
  } catch (e) {}
  try {
    const pj = path.join(ROOT, 'server', 'package.json');
    if (fs.existsSync(pj)) {
      const v = JSON.parse(fs.readFileSync(pj, 'utf8').replace(/^\uFEFF/, '')).version;
      if (v) return String(v);
    }
  } catch (e) {}
  return '';
}
function applyPendingUpgrade() {
  if (!fs.existsSync(UPGRADE_META)) return false;
  let meta = null;
  try { meta = JSON.parse(fs.readFileSync(UPGRADE_META, 'utf8')); } catch (e) { return false; }
  const ver = meta && meta.version;
  if (!ver) return false;
  const codeVer = readCodeVersion();
  // R174 修复（P0 容器无限重启 —— 2026-11-01 生产机实测）：
  // 旧判据 needRestart = compareVer(codeVer2, ver) >= 0 在「升级包版本 == 当前代码版本」时恒为 true，
  // 而 meta 只被「更低版本」分支清理 ⇒ 应用完重启一次后，新进程启动又走同一条路：
  // 再覆盖一遍 → 再 process.exit(0) → 容器被拉起 → 又来一遍，形成无限重启（页面永远等不到服务回来）。
  // 现在拆成两件事：① 同一份包已应用过就不再动（清 meta 早退）；
  // ② 只有「本次覆盖真的改动了 server 侧代码」才重启 —— public 改动刷新浏览器即生效，不需要 exit。
  if (meta.appliedAt && codeVer && compareVer(ver, codeVer) <= 0) {
    try { fs.unlinkSync(UPGRADE_META); } catch (e) {}
    console.log(`[升级] 升级包 v${ver} 已应用过（当前 v${codeVer}），跳过，不重启`);
    return false;
  }
  // 第 104 轮：仅「更低版本」视为已应用/无需处理；同版本（=0）同样走覆盖应用，支持修复轮不递增版本号时的覆盖安装
  if (codeVer && compareVer(ver, codeVer) < 0) {
    try { fs.unlinkSync(UPGRADE_META); } catch (e) {}
    return false;
  }
  const filesDir = path.join(UPGRADE_DIR, 'files');
  if (!fs.existsSync(filesDir)) return false;
  let count = 0;
  let touchedServer = false;
  const sha1 = (buf) => crypto.createHash('sha1').update(buf).digest('hex');
  const walk = (dir) => {
    for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
      const s = path.join(dir, e.name);
      const rel = path.relative(filesDir, s).replace(/\\/g, '/');
      if (e.isDirectory()) { walk(s); continue; }
      if (!/^(server\/.+\.(js|json)|public\/.+)$/.test(rel)) continue;
      const dest = path.join(ROOT, rel);
      fs.mkdirSync(path.dirname(dest), { recursive: true });
      // 先比内容再覆盖：只有服务端文件真的变了才值得重启一次
      let same = false;
      try { same = sha1(fs.readFileSync(dest)) === sha1(fs.readFileSync(s)); } catch (e) { same = false; }
      fs.copyFileSync(s, dest);
      count++;
      if (!same && rel.indexOf('server/') === 0) touchedServer = true;
    }
  };
  try { walk(filesDir); } catch (e) { console.error('[升级] 应用持久化升级包失败：', e.message); return false; }
  if (touchedServer) {
    meta.version = readCodeVersion() || ver;
    meta.appliedAt = Date.now();
    try { fs.writeFileSync(UPGRADE_META, JSON.stringify(meta, null, 2)); } catch (e) {}
    console.log(`[升级] 已应用持久化升级包 v${ver}（覆盖 ${count} 个文件，服务端代码有变更），2 秒后快速重启加载新版本…`);
    setTimeout(() => process.exit(0), 2000);
    return true;
  }
  // 服务端代码没变（纯前端包 / 同版本重复应用）⇒ 直接消费掉 meta，绝不 exit，否则就是无限重启
  try { fs.unlinkSync(UPGRADE_META); } catch (e) {}
  console.log(`[升级] 已应用持久化升级包 v${ver}（覆盖 ${count} 个文件，仅前端变更，无需重启）`);
  return false;
}
function start() {
  try { if (applyPendingUpgrade()) return; } catch (e) { console.error('[升级]', e.message); }
  runIntegrityCheck();   // 防篡改自校验：启动即比对核心文件（升级包应用后再检测一次，见下方 listen 成功后）
  loadRevokedTokens();   // R133-B5：把落盘的撤销记录载回内存，避免重启后旧 token 复活
  const base = parseInt(process.env.PORT || '8080', 10);
  let port = base;
  const tryListen = (p) => new Promise((resolve) => {
    const srv = app.listen(p, () => resolve({ srv, port: p }));
    srv.on('error', (e) => { if (e.code === 'EADDRINUSE') resolve({ port: null }); else resolve({ error: e }); });
  });
  (async () => {
    for (let p = base; p < base + 10; p++) {
      const r = await tryListen(p);
      if (r.error) { console.error('[启动失败]', r.error.message); process.exit(1); }
      if (r.port) {
        // v0.99.47：版本日志规则——仅正式版（≥v1.0.0）记录，测试版不写入（seedVersionLog 内部已按正式版判定）；
        // R95：说明取自 VERSION_HISTORY 真实记录（言简意赅），不写「修复已知BUG或问题」占位文案，修复轮不追加记录
        seedVersionLog(APP_VERSION);
        // 新部署默认自动填充示例数据（站点/分组/通知/广告），便于开箱体验；管理员自动完成
        if (getSetting('sample_seeded') !== '1') {
          const adm = db.prepare("SELECT * FROM users WHERE role = 'superadmin' ORDER BY id LIMIT 1").get() || db.prepare("SELECT * FROM users WHERE role = 'admin' ORDER BY id LIMIT 1").get();
          if (adm) {
            seedSampleData(adm, { keepGroups: true });
            console.log('[天枢导航] 已自动填充示例数据（站点/分组/通知/广告）');
          }
        }
        // 存量库字段补齐：新版本设置字段若不存在则写入默认值（保证跨版本升级后功能可用）
        ensureNewSettingDefaults();
        // v0.99.25：示例广告升级补种（旧示例默认值→新版规格；不触碰用户自定义）
        ensureAdDefaults();
        // v0.99.25：免费版分组配额 5→6，存量库幂等补齐第 6 组「效率办公」示例（不覆盖用户已有数据，升级用户同样可见）
        ensureSeedGroups();
        console.log(`[天枢导航] ${APP_NAME} v${APP_VERSION} 已启动 → http://127.0.0.1:${r.port}  (容器内建议 PORT=8080，对外映射 5 位高位端口如 16080)`);
        // 异步：初始化实例标识 → 拉取远端配置（系统通知/广告/定价）→ 上报实例（均静默，不阻塞启动）
        lic.instanceId();
        // R149：实例标识自检 —— 治「同机多套撞号，界面上看不出来」。
        // 把标识/槽位/盐来源/持久目录打进启动日志，并把需要注意的事实逐条说明；只告警，绝不阻塞启动。
        try {
          const im = lic.instanceMeta();
          console.log('[实例] ' + im.instanceId + ' · 槽位 ' + im.slot + ' · 盐来源 ' + im.saltSource +
            ' · 持久目录 ' + im.stateRoot + (im.slots.length > 1 ? ' · 本机共 ' + im.slots.length + ' 套部署' : ''));
          for (const w of lic.instanceWarnings()) console.log('[实例] ' + w);
        } catch (e) {}
        lic.pullRemote().catch(() => {});
        setTimeout(() => lic.reportInstance().catch(() => {}), 3000);
        // v0.99.41：远端心跳再优化 —— 每 30 秒「拉取远端配置 + 上报实例」周期任务。
        // 云端下发（系统通知/广告/定价/授权裁决）客户端 ≤30s 感知，达到「修改即送达」；
        // 实例活跃度与广告展示状态云端实时可见（原 60 秒轮询按用户要求进一步缩短）。
        setInterval(() => {
          lic.pullRemote().catch(() => {});
          lic.reportInstance().catch(() => {});
        }, 30 * 1000);
        // R98：DDNS 动态域名周期任务（内部按配置间隔与 IP 变化判断是否实际调用服务商 API）
        ddns.start(60);
        return;
      }
    }
    console.error('[启动失败] 端口被占用且避让 10 个均失败');
    process.exit(1);
  })();
}
start();
