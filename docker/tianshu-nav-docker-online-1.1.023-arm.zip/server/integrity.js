/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 天枢导航 · 防篡改自校验模块（安全强化④）
// 原理：打包/发布时对核心文件（server/*.js、server/package.json、public/js/*.js）计算 HMAC-SHA256，
// 清单与密钥同存 server/integrity.json（随包分发）；启动时复算比对，任一文件被改动即标记失败。
// 定位：防「普通篡改/投毒」（改了代码或注入恶意文件），不阻断启动（避免误杀小白升级/部署），
// 失败状态暴露给管理后台提示重新部署；混淆版同样适用（清单在混淆产物上生成）。
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

function integrityPath(root) {
  return path.join(root, 'server', 'integrity.json');
}

// 计算单文件 HMAC-SHA256（hex）
function hmacFile(key, absPath) {
  const data = fs.readFileSync(absPath);
  return crypto.createHmac('sha256', key).update(data).digest('hex');
}

// 校验：返回 { ok, version, keyId, checked, failed: [rel], updatedAt }
function check(root) {
  const ip = integrityPath(root);
  if (!fs.existsSync(ip)) return { ok: true, checked: 0, failed: [], note: 'no-manifest' }; // 未生成清单（源码调试态）不阻断
  let manifest = null;
  try { manifest = JSON.parse(fs.readFileSync(ip, 'utf8').replace(/^\uFEFF/, '')); } catch (e) { return { ok: false, checked: 0, failed: ['integrity.json'], note: 'manifest-corrupt' }; }
  const key = String(manifest.key || '');
  const files = (manifest.files && typeof manifest.files === 'object') ? manifest.files : {};
  const failed = [];
  let checked = 0;
  for (const rel of Object.keys(files)) {
    const abs = path.join(root, rel);
    if (!fs.existsSync(abs)) { failed.push(rel); continue; }
    checked++;
    try {
      const h = hmacFile(key, abs);
      if (h !== String(files[rel])) failed.push(rel);
    } catch (e) { failed.push(rel); }
  }
  return { ok: failed.length === 0, version: manifest.version || '', keyId: manifest.keyId || 'ts-nav-v1', checked, failed, updatedAt: manifest.updatedAt || 0 };
}

module.exports = { check, hmacFile };
