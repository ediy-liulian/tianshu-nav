'use strict';
// 迁移 002：v1.5.0 结构变更
//  groups.scene        分组场景标签（个人/家庭/工作室/公司，空=不限）
//  groups.show_in_nav  分组是否显示在首页导航条（0=隐藏/归档）
//  sites.net_flag      auto=自动判定 / manual=手动指定（net_flag_val 生效）
//  sites.net_flag_val  intranet_only / dual / extranet_only
//  sites.visibility    public=公开 / private=仅管理员可见
//  notices.content_html 通知富文本正文（content 保留纯文本摘要）
//  settings.license_*  授权钩子（仅留字段，不做强制校验）
module.exports = {
  version: '002',
  up(db) {
    // 幂等：列已存在时 SQLite 抛 "duplicate column name"，忽略之
    const addCol = (sql) => { try { db.exec(sql); } catch (e) { if (!/duplicate column/i.test(e.message)) throw e; } };
    addCol("ALTER TABLE groups ADD COLUMN scene TEXT NOT NULL DEFAULT ''");
    addCol('ALTER TABLE groups ADD COLUMN show_in_nav INTEGER NOT NULL DEFAULT 1');
    addCol("ALTER TABLE sites ADD COLUMN net_flag TEXT NOT NULL DEFAULT 'auto'");
    addCol('ALTER TABLE sites ADD COLUMN net_flag_val TEXT');
    addCol("ALTER TABLE sites ADD COLUMN visibility TEXT NOT NULL DEFAULT 'public'");
    addCol('ALTER TABLE notices ADD COLUMN content_html TEXT');
    const st = db.prepare('INSERT OR IGNORE INTO settings(key, value) VALUES(?, ?)');
    st.run('license_key', '');
    st.run('license_type', '');
    st.run('license_expire', '');
  }
};
