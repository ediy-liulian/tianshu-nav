/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';


const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const os = require('os');
const { promisify } = require('util');

// 免费版配额（规格 v5：站点≤50 / 分组≤6 / 用户≤2 含管理员；专业版不限）
const FREE_QUOTA = { sites: 50, groups: 6, users: 2 };
const TIER_DAYS = { year: 365, tri: 1095, lifetime: 0 }; // 0 = 永久
const TIER_LABEL = { year: '按年订阅', tri: '三年订阅', lifetime: '永久买断' };
// 远端服务地址出厂内置（规格 v1.0.3：客户端不展示、不编辑，仅做连通性测试；远端配置推送覆盖）
const DEFAULT_REMOTE = 'https://nav.ediy.net';

// ---------- SSRF 出口校验（唯一收口） ----------
// 远端地址可由管理后台写入设置项，服务端随后会主动 fetch 它。若不校验，攻击者（或被盗的管理员账号）
// 可把它设成 http://169.254.169.254/（云元数据）或内网地址，让服务端代替自己去访问 —— 典型 SSRF。
// 这里在**唯一出口** remoteBase() 上做判定，所有调用方（含 server.js 直接 fetch 的两处）自动获得防护；
// 调用点再各自校验一遍是补不齐的（漏一个就是一个洞）。
const PRIVATE_HOST = /^(localhost|127\.|0\.0\.0\.0|\[?::1\]?|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|metadata\.|fd[0-9a-f]{2}:|fe80:)/i;
function assertRemoteUrl(u) {
  let p;
  try { p = new URL(String(u)); } catch (e) { throw new Error('远端地址格式非法'); }
  if (p.protocol !== 'https:' && p.protocol !== 'http:') throw new Error('远端地址协议不被允许（仅 http/https）');
  if (p.username || p.password) throw new Error('远端地址不得包含用户名或口令');
  const host = String(p.hostname || '').replace(/^\[|\]$/g, '');
  if (!host) throw new Error('远端地址缺少主机名');
  // 十进制/十六进制整数形式的 IPv4（如 http://2130706433/ 等价 127.0.0.1）与 IPv4-mapped IPv6 都要拦
  if (/^\d+$/.test(host) || /^0x[0-9a-f]+$/i.test(host) || /::ffff:/i.test(host)) {
    throw new Error('远端地址为 IP 数字/映射形式，已拒绝');
  }
  if (PRIVATE_HOST.test(host)) throw new Error('远端地址指向内网/环回/云元数据地址，已拒绝');
  const port = String(p.port || '');
  if (port && port !== '80' && port !== '443') throw new Error('远端地址端口不被允许（仅 80/443）');
  return true;
}







const DMI_BASE = '/sys/class/dmi/id';
const DMI_KEYS = ['product_uuid', 'board_serial', 'product_serial', 'board_asset_tag'];
const DMI_PLACEHOLDER = /^(None|To\s?be\s?filled.*|O\.?E\.?M\..*|System\s?Serial\s?Number|Default\s?string|Not\s?Specified|000+)$/i;


function dmiBase() {
  const v = String(process.env.TSN_DMI_DIR || '').trim();
  return (v && v.indexOf('..') === -1) ? v : DMI_BASE;
}

function dmiSource(baseArg) {
  const base = String(baseArg || dmiBase());
  const parts = [];
  for (const k of DMI_KEYS) {
    try {
      const p = base + '/' + k;
      if (fs.existsSync(p)) {
        const v = fs.readFileSync(p, 'utf8').trim();
        if (v && !DMI_PLACEHOLDER.test(v)) parts.push(k + '=' + v);
      }
    } catch (e) {}
  }
  return parts.join('@@');
}
function dmiFingerprint(baseArg) {
  const src = dmiSource(baseArg);
  if (!src) return '';
  return crypto.createHash('sha256').update('dmi@@' + src).digest('hex').slice(0, 12);
}
function envFingerprint() {
  const v = String(process.env.TSN_HOST_ID || process.env.TSN_MACHINE_ID || '').trim();
  if (!v) return '';
  return crypto.createHash('sha256').update('env@@' + v).digest('hex').slice(0, 12);
}
function containerFingerprint() {
  



  try {
    for (const p of ['/etc/machine-id', '/var/lib/dbus/machine-id']) {
      if (fs.existsSync(p)) {
        const v = fs.readFileSync(p, 'utf8').trim();
        if (v) {
          return crypto.createHash('sha256').update('mid@@' + v).digest('hex').slice(0, 12);
        }
      }
    }
  } catch (e) {}
  const parts = [];
  try {
    const macs = Object.values(os.networkInterfaces())
      .reduce((a, l) => a.concat(l || []), [])
      .map(i => (i && i.mac) || '')
      .filter(m => m && m !== '00:00:00:00:00:00')
      .sort();
    parts.push(macs.join('|'));
  } catch (e) {}
  try { parts.push(os.hostname()); } catch (e) {}
  try {
    const cpus = os.cpus();
    if (cpus && cpus.length) parts.push((cpus[0].model || '') + '|' + cpus.length);
  } catch (e) {}
  return crypto.createHash('sha256').update(parts.join('@@')).digest('hex').slice(0, 12);
}

const SLOT_DEFAULT = 'main';
const SLOT_RE = /[^a-z0-9_-]/g;

// 部署槽位：默认 main；装第二套时用 TSN_INSTANCE_SLOT 显式命名（如 test / shop2）
function deploySlot() {
  const raw = String(process.env.TSN_INSTANCE_SLOT || '').trim().toLowerCase();
  const s = raw.replace(SLOT_RE, '').slice(0, 24);
  return s || SLOT_DEFAULT;
}
// 老公式（v1.1.000 / v1.1.001 用的那套）：盐 = f(DMI 原始串)。保留，作为默认槽位的盐。
// ★ 必须与旧版逐字符一致：旧版 dmiSource() 恒为字符串，无 DMI 时是 ''，于是盐 = sha256('salt@@')[:6]。
//   曾误加「无 DMI 就返回空」的守卫 ⇒ 无 DMI 主机（Windows 开发机 / 部分 ARM NAS）升级后盐从
//   sha256('salt@@')=9d8f76 变成 f('main')，实例标识随之改变，破 L2/L3/L4。此处不得再提前返回。
function legacySalt() {
  try {
    const src = dmiSource() || '';
    return crypto.createHash('sha256').update('salt@@' + src).digest('hex').slice(0, 6);
  } catch (e) { return ''; }
}
// 新公式：盐 = f(槽位)。纯函数，不依赖任何文件。
function slotSalt() {
  return crypto.createHash('sha256').update('slot@@' + deploySlot()).digest('hex').slice(0, 6);
}
// 部署盐：默认槽位沿用老公式（零迁移成本 + 零持久化可恢复），非默认槽位用新公式（必然可区分）
function deploySalt() {
  const ls = legacySalt();
  return (deploySlot() === SLOT_DEFAULT && ls) ? ls : slotSalt();
}
// 宿主持久状态根目录。历史缺陷 D1：非容器环境曾无条件写盘根 /app（Windows 上落到 E:\app），已修。
function stateRoot() {
  const env = String(process.env.TSN_STATE_DIR || '').trim();
  if (env && env.indexOf('..') === -1) return env;
  if (process.platform !== 'win32') {
    
    try { if (fs.existsSync('/app') && fs.statSync('/app').isDirectory()) return '/app/instance'; } catch (e) {}
    return '/var/lib/tianshu-nav-instance';
  }
  // Windows 直装（本地调试形态）：走 ProgramData，绝不写盘根
  const base = String(process.env.PROGRAMDATA || '').trim() || path.join(os.homedir(), 'AppData', 'Roaming');
  return path.join(base, 'tianshu-nav', 'instance');
}
function hostSlotDir(salt) {
  if (!salt) return '';
  const dir = path.join(stateRoot(), 'instances', salt);
  return dir.indexOf('..') !== -1 ? '' : dir;
}
function hostInstanceFile(salt) {
  const dir = hostSlotDir(salt);
  return dir ? path.join(dir, 'id') : '';
}
// v1.1.001 及更早只写死 /app/instance —— 存量迁移必须能找到它，否则老用户升级后身份会变
function legacyHostFiles() {
  const ls = legacySalt();
  if (!ls) return [];
  const roots = [];
  if (process.platform !== 'win32') roots.push('/app/instance');
  roots.push(stateRoot());
  const out = [];
  for (const r of roots) {
    const f = path.join(r, 'instances', ls, 'id');
    if (f.indexOf('..') === -1 && out.indexOf(f) < 0) out.push(f);
  }
  return out;
}
// 三处落盘（幂等：只补缺失或内容不符的，不重复写盘）

function createLicense(deps) {
  const { getSetting, setSetting, db, APP_VERSION, APP_NAME } = deps;

  
  function fingerprintHex() {
    return dmiFingerprint() || envFingerprint() || containerFingerprint();
  }
  function machineFingerprint() { return 'tsn-' + fingerprintHex(); }

  

























  function persistId(id) {
    if (!id) return;
    if (String(getSetting('instance_id') || '') !== id) setSetting('instance_id', id);
    try {
      const keyFile = path.join(deps.dataDir || '', '.instance_key');
      if (keyFile.indexOf('..') === -1) {
        let cur = '';
        try { cur = fs.readFileSync(keyFile, 'utf8').trim(); } catch (e) {}
        if (cur !== id) fs.writeFileSync(keyFile, id, 'utf8');
      }
    } catch (e) {}
    try {
      const dir = hostSlotDir(deploySalt());
      const hf = dir ? path.join(dir, 'id') : '';
      if (hf) {
        let cur = '';
        try { cur = fs.readFileSync(hf, 'utf8').trim(); } catch (e) {}
        if (cur !== id) {
          fs.mkdirSync(dir, { recursive: true });
          fs.writeFileSync(hf, id, 'utf8');
          // 槽位名一并留档：运维从目录名（盐）看不出是第几套，靠这个文件自解释
          try { fs.writeFileSync(path.join(dir, 'slot'), deploySlot(), 'utf8'); } catch (e) {}
        }
      }
    } catch (e) {}
  }
  function instanceId() {
    let id = String(getSetting('instance_id') || '').trim();
    if (!id) {
      // 兜底①数据卷内独立持久文件（升级/容器重建不触碰数据卷）
      try {
        const keyFile = path.join(deps.dataDir || '', '.instance_key');
        if (keyFile.indexOf('..') === -1) id = fs.readFileSync(keyFile, 'utf8').trim() || '';
      } catch (e) {}
    }
    if (!id) {
      // 兜底②按部署盐分目录的宿主持久文件（同机第二套读不到第一套 —— 消灭「静默冒用身份」）
      try {
        const hf = hostInstanceFile(deploySalt());
        if (hf) id = fs.readFileSync(hf, 'utf8').trim() || '';
      } catch (e) {}
    }
    if (!id && deploySlot() === SLOT_DEFAULT) {
      // 兜底③ v1.1.001 存量持久文件（仅默认槽位读）。读到后由 persistId 复制到新路径，**不删旧文件**（回滚需要）
      for (const lf of legacyHostFiles()) {
        try {
          const v = fs.readFileSync(lf, 'utf8').trim();
          if (v) { id = v; break; }
        } catch (e) {}
      }
    }
    if (!id) id = 'tsn-' + fingerprintHex() + deploySalt();   // ⑤ 确定性生成（无随机兜底：盐恒有值）
    persistId(id);
    return id;
  }
  // 实例元信息：启动日志与面板「关于」用（运维要能一眼看出这是第几套、标识怎么来的）
  function instanceMeta() {
    const slot = deploySlot();
    const salt = deploySalt();
    const root = stateRoot();
    let slots = [];
    try {
      const base = path.join(root, 'instances');
      slots = fs.readdirSync(base).filter(n => {
        try { return fs.statSync(path.join(base, n)).isDirectory(); } catch (e) { return false; }
      }).map(n => {
        let name = '';
        try { name = fs.readFileSync(path.join(base, n, 'slot'), 'utf8').trim(); } catch (e) {}
        return { salt: n, slot: name || '', current: n === salt };
      });
    } catch (e) {}
    return {
      instanceId: instanceId(),
      slot, salt, hostFp: fingerprintHex(), stateRoot: root,
      hostFile: hostInstanceFile(salt), slots,
      saltSource: (slot !== SLOT_DEFAULT) ? 'slot' : (dmiSource() ? 'legacy(dmi)' : 'legacy(no-dmi)')
    };
  }
  // 启动自检告警：不阻塞、不退出，只把「您知道会更好」的事实说清楚
  function instanceWarnings() {
    const m = instanceMeta();
    const out = [];
    if (m.slot === SLOT_DEFAULT && m.slots.length > 1) {
      out.push('本机已存在 ' + m.slots.length + ' 套部署，本实例沿用默认槽位 main（' + m.instanceId + '）。' +
        '若本实例应是独立的另一套，请设置环境变量 TSN_INSTANCE_SLOT=test 后重启（同名槽位共享同一标识）。');
    }
    if (!dmiFingerprint() && !envFingerprint()) {
      out.push('未读到硬件 DMI 身份，当前宿主身份取自容器指纹；镜像克隆/整机复制可能导致跨机撞号，建议显式设置 TSN_HOST_ID。');
    }
    if (m.slot !== SLOT_DEFAULT && m.saltSource === 'slot') {
      out.push('本实例使用槽位 ' + m.slot + '（' + m.instanceId + '），与默认槽位实例互不相同。');
    }
    return out;
  }

  function remoteBase() {
    


    if (process.env.DEMO === '1') return '';
    const v = String(getSetting('remote_base') || DEFAULT_REMOTE).trim().replace(/\/+$/, '');
    // SSRF 出口校验：库里可能存着历史遗留或被改坏的地址，宁可整体不可用（fail-closed）
    // 也不能让服务端代替攻击者去访问内网。返回空串后各调用方都会走「远端服务未就绪」分支。
    try { assertRemoteUrl(v); } catch (e) {
      if (!remoteBase._warned) {
        remoteBase._warned = true;
        console.warn('[license] 远端地址已被安全策略拒绝：' + e.message + '（值：' + v.slice(0, 80) + '）');
      }
      return '';
    }
    return v;
  }
  function remotePub() {
    // 远端公钥：本地出厂默认优先（由服务器端推送覆盖），其次远端配置下发 publicKey；当前激活为纯在线核验，公钥仅历史 TS1 码兼容保留
    const local = String(getSetting('remote_pubkey') || '').trim();
    if (local) return local;
    const c = cached();
    return (c && c.publicKey) ? String(c.publicKey).trim() : '';
  }
  function boundAccount() {
    return String(getSetting('license_bound_account') || '').trim();
  }

  // ---------- 授权状态 ----------
  function state() {
    
    if (process.env.DEMO === '1') {
      return {
        ok: true, licensed: true, type: 'pro', tier: 'lifetime',
        tierLabel: TIER_LABEL.lifetime || '永久买断', expireAt: 0,
        expireText: '9999年12月12日', daysLeft: null,
        boundAccount: 'demo', badge: 'pro', instanceId: instanceId(),
        remoteBase: '', remoteConfigured: false, version: APP_VERSION, demo: true
      };
    }
    const type = getSetting('license_type') || 'free';      // free | pro
    const tier = getSetting('license_tier') || '';
    const expire = getSetting('license_expire') || '';      // ''=无 | '0'=永久 | 时间戳
    const key = getSetting('license_key') || '';
    // 凭据强校验（安全强化）：licensed 必须同时满足 type=pro 且有激活码/授权凭证，
    // 防止直接篡改本地库 license_type 字段绕过授权（无凭据一律视为免费）
    const licensed = type === 'pro' && !!key;
    


    let trial = false, trialStartAt = 0, trialEndAt = 0, trialDaysLeft = null;
    if (!licensed) {
      // R94-3：远端未下发 trialDays（纯内网部署拉不到云端）时，出厂内置兜底 30 天，
      // 保证内网新装默认拿到专业版试用、广告开关可用；联网成功后仍以远端下发值覆盖
      const remoteTri = (cached() || {}).trialDays;
      const trialDays = (remoteTri === undefined || remoteTri === null)
        ? 30
        : Math.max(0, parseInt(remoteTri, 10) || 0);
      let ts = parseInt(getSetting('license_trial_start') || '0', 10) || 0;
      const trialUsed = getSetting('license_trial_used') === '1';
      if (trialDays > 0 && !trialUsed) {
        if (!ts) {
          // 惰性起算：试用须本实例已存在管理员账号；未初始化管理员前不消耗试用天数
          // R103C：管理员角色三档化——superadmin/admin 均视为管理员账号
          try {
            const adminN = db.prepare('SELECT COUNT(*) AS c FROM users WHERE role IN (?, ?)').get('superadmin', 'admin');
            if (adminN && adminN.c > 0) { ts = Date.now(); setSetting('license_trial_start', String(ts)); }
          } catch (e) {}
        }
        if (ts > 0) {
          trialEndAt = ts + trialDays * 86400000;
          if (Date.now() >= trialEndAt) {
            // 到期自动降级免费版（防回溯：试用名额标记已用，不再重新触发）
            setSetting('license_trial_start', '');
            setSetting('license_trial_used', '1');
          } else {
            trial = true; trialStartAt = ts;
            trialDaysLeft = Math.max(0, Math.ceil((trialEndAt - Date.now()) / 86400000));
          }
        }
      }
    }
    const effLicensed = licensed || trial;   // 试用期等同专业版行为（配额不限 / 广告可自主关闭 / 徽标「专业版试用中」）
    let expireAt = null, daysLeft = null;
    if (trial) {
      expireAt = trialEndAt; daysLeft = trialDaysLeft;
    } else if (licensed && expire === '0') { expireAt = 0; daysLeft = null; }          // 永久
    else if (licensed && /^\d+$/.test(expire)) {
      expireAt = parseInt(expire, 10);
      daysLeft = Math.max(0, Math.ceil((expireAt - Date.now()) / 86400000));
    }
    // 过期自动降级
    if (licensed && expireAt && expireAt !== 0 && expireAt < Date.now()) {
      setSetting('license_type', 'free');
      return state();
    }
    return {
      ok: true,
      licensed: effLicensed,
      type: trial ? 'trial' : (licensed ? 'pro' : 'free'),   // free | pro | trial
      tier: licensed ? tier : (trial ? 'trial' : ''),
      tierLabel: licensed ? (TIER_LABEL[tier] || '') : (trial ? '专业版试用中' : ''),
      


      warn: (!effLicensed && !trial && key) ? (getSetting('license_warn') || '') : '',
      expireAt,
      
      expireText: !effLicensed ? '' : (trial ? new Date(trialEndAt).toLocaleString('zh-CN') : expireAt === 0 ? '9999年12月12日' : new Date(expireAt).toLocaleString('zh-CN')),
      daysLeft: effLicensed && expireAt !== 0 ? daysLeft : null,
      boundAccount: licensed ? boundAccount() : '',
      licenseId: licensed ? key : '',            // 激活码（授权 ID），供解绑迁移等场景回填
      badge: trial ? 'trial' : (licensed ? 'pro' : 'free'),
      trial, trialStartAt, trialEndAt,
      trialDaysLeft: trial ? trialDaysLeft : null,
      instanceId: instanceId(),
      remoteBase: remoteBase() || '',
      remoteConfigured: !!remoteBase(),
      version: APP_VERSION
    };
  }

  // ---------- 免费配额检查 ----------
  function usedCount(kind) {
    if (kind === 'sites') return db.prepare('SELECT COUNT(*) AS c FROM sites').get().c;
    if (kind === 'groups') return db.prepare('SELECT COUNT(*) AS c FROM groups').get().c;
    if (kind === 'users') return db.prepare('SELECT COUNT(*) AS c FROM users').get().c;
    return 0;
  }
  function checkQuota(kind) {
    const st = state();
    if (st.licensed) return { ok: true, used: null, limit: null, pro: true };
    const limit = FREE_QUOTA[kind];
    const used = usedCount(kind);
    return { ok: used < limit, used, limit, pro: false, badge: 'free' };
  }
  function quotaDesc(kind) {
    const q = checkQuota(kind);
    return { used: q.used, limit: q.limit, pro: q.pro };
  }

  // ---------- 历史 TS1 长码离线验签（TS1-<b62(payload)>-<b62(sig)>，Ed25519；兼容保留，当前激活统一走服务器在线核验） ----------
  // 编码与远端签发完全一致：自定义 base62（大写小写数字），非 base64
  const B62_CHARS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  function b62Encode(buf) {
    let n = 0n;
    for (const b of buf) n = (n << 8n) + BigInt(b);
    if (n === 0n) return 'A';
    let s = '';
    while (n > 0n) { s = B62_CHARS[Number(n % 62n)] + s; n /= 62n; }
    return s;
  }
  function b62Decode(s) {
    let n = 0n;
    for (const c of String(s)) n = n * 62n + BigInt(B62_CHARS.indexOf(c));
    const bytes = [];
    while (n > 0n) { bytes.unshift(Number(n & 255n)); n >>= 8n; }
    return Buffer.from(bytes);
  }
  function verifyOffline(code, pubPem) {
    try {
      const parts = String(code || '').trim().split('-');
      if (parts.length < 3 || parts[0] !== 'TS1') return { ok: false, error: '激活码格式不正确' };
      const payload = JSON.parse(b62Decode(parts[1]).toString('utf8'));
      if (!payload || payload.v !== 1 || !payload.t) return { ok: false, error: '激活码内容无效' };
      const sig = b62Decode(parts.slice(2).join('-'));
      const pub = crypto.createPublicKey(pemToPem(pubPem));
      const data = Buffer.from(JSON.stringify(payload));
      const good = crypto.verify(null, data, pub, sig);
      if (!good) return { ok: false, error: '激活码签名校验失败（公钥不匹配或已失效）' };
      const days = TIER_DAYS[payload.t] !== undefined ? TIER_DAYS[payload.t] : (parseInt(payload.d, 10) || 365);
      const expireAt = days === 0 ? 0 : Date.now() + days * 86400000;
      return { ok: true, tier: payload.t, days, expireAt, nonce: payload.n || '' };
    } catch (e) {
      return { ok: false, error: '激活码解析失败：' + (e.message || '') };
    }
  }
  function pemToPem(pem) {
    const s = String(pem).trim();
    if (s.includes('BEGIN PUBLIC KEY')) return s;
    // 裸 base64 公钥 → 包装为 PEM
    const body = s.replace(/\s+/g, '');
    return '-----BEGIN PUBLIC KEY-----\n' + body.match(/.{1,64}/g).join('\n') + '\n-----END PUBLIC KEY-----';
  }

  

  const SHORT_CHARS = '23456789ABCDEFGHJKLMNPQRSTUVWXYZ';
  function charsOk(s) {
    for (const ch of String(s)) if (SHORT_CHARS.indexOf(ch) < 0) return false;
    return true;
  }
  function formatCheck(code) {
    const c = String(code || '').trim();
    if (!c) return { ok: false, error: '请输入激活码' };
    if (c.startsWith('TSN-')) {
      const p = c.split('-');
      if (p.length !== 4 || p[0] !== 'TSN') return { ok: false, error: '激活码格式不正确' };
      const p1 = p[1], mid = p[2], chk = p[3];
      if (p1.length !== 6 || mid.length !== 6 || chk.length !== 6) return { ok: false, error: '激活码格式不正确' };
      if (!'YTP'.includes(mid[0])) return { ok: false, error: '激活码档位标识无效（Y=年 T=三年 P=永久）' };
      if (!charsOk(p1) || !charsOk(mid.slice(1)) || !charsOk(chk)) return { ok: false, error: '激活码格式不正确' };
      return { ok: true };
    }
    if (c.startsWith('TS1-')) {
      const p = c.split('-');
      if (p.length < 3 || p[0] !== 'TS1' || !p[1] || !p[2]) return { ok: false, error: '激活码格式不正确' };
      return { ok: true };
    }
    return { ok: false, error: '激活码格式不正确' };
  }

  
  async function activate({ code, account, device }) {
    const key = String(code || '').trim();
    if (!key) return { ok: false, error: '请输入激活码' };
    const f = formatCheck(key);
    if (!f.ok) return f;
    const acc = String(account || '').trim();
    const dev = String(device || '').trim() || instanceId();
    const base = remoteBase();
    if (!base) return { ok: false, error: '未配置远端服务地址，在线激活需要联网，请在「授权订阅」中配置远端服务地址' };
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 8000);
      const r = await remoteFetchRaw(base + '/api/v1/activate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        
        body: JSON.stringify({ code: key, account: acc, device: dev, hostFp: fingerprintHex(), slot: deploySlot() }),
        signal: ctl.signal
      });
      clearTimeout(timer);
      const j = await r.json().catch(() => ({}));
      if (j && j.ok) {
        // 落库防御：云端必须返回完整授权字段才落库，缺失时不覆盖本地现有授权（防重复激活把授权写坏）
        // expireAt 允许 null（永久档 P 返回 null）；undefined 才视为缺失
        if (j.tier && j.expireAt !== undefined && j.expireAt !== null) {
          saveLicensed(key, j.tier, j.expireAt, acc);
          return { ok: true, licenseId: j.licenseId || '', tier: j.tier, expireAt: j.expireAt, mode: 'online', ...state() };
        }
        // 永久档（expireAt === null）单独落库，防止被误判为「授权信息异常」
        if (j.tier && j.expireAt === null) {
          saveLicensed(key, j.tier, 0, acc);
          return { ok: true, licenseId: j.licenseId || '', tier: j.tier, expireAt: 0, mode: 'online', ...state() };
        }
        return { ok: false, error: (j.reason) || '激活码已使用或授权信息异常，本地授权未变更', mode: 'online' };
      }
      return { ok: false, error: (j && j.reason) || '远端激活失败（HTTP ' + r.status + '）', mode: 'online' };
    } catch (e) {
      // 激活验证统一走服务器（纯断网无法激活）
      return { ok: false, error: '远端无法连接（' + (e.name === 'AbortError' ? '请求超时' : e.message) + '），在线激活需要联网，请检查远端服务地址后重试', mode: 'online' };
    }
  }

  function saveLicensed(key, tier, expireAt, account) {
    setSetting('license_key', key);
    setSetting('license_type', 'pro');
    setSetting('license_tier', tier);
    setSetting('license_expire', expireAt === 0 || expireAt === null ? '0' : String(expireAt));
    setSetting('license_bound_account', account || '');
    
    try { setSetting('license_warn', ''); } catch (e) {}
    
    setSetting('license_trial_start', '');
    setSetting('license_trial_used', '1');
  }

  // ---------- 解绑迁移（换机：规格 5.4 防倒卖，OTP + 24h 冷却 + 年度配额） ----------
  async function transferRequest({ licenseId, account }) {
    const base = remoteBase();
    if (!base) return { ok: false, error: '未配置远端服务地址' };
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 8000);
      const r = await remoteFetchRaw(base + '/api/v1/transfer/request', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseId: String(licenseId || '').trim(), account: String(account || '').trim() }),
        signal: ctl.signal
      });
      clearTimeout(timer);
      const j = await r.json().catch(() => ({}));
      if (j && j.ok) return { ok: true, retryAfter: j.retryAfter || 60 };
      return { ok: false, error: (j && j.reason) || '迁移申请失败（HTTP ' + r.status + '）' };
    } catch (e) {
      return { ok: false, error: '无法连接远端：' + (e.name === 'AbortError' ? '请求超时' : e.message) };
    }
  }

  async function transferConfirm({ licenseId, account, code }) {
    const base = remoteBase();
    if (!base) return { ok: false, error: '未配置远端服务地址' };
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 8000);
      const r = await remoteFetchRaw(base + '/api/v1/transfer/confirm', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ licenseId: String(licenseId || '').trim(), account: String(account || '').trim(), code: String(code || '').trim() }),
        signal: ctl.signal
      });
      clearTimeout(timer);
      const j = await r.json().catch(() => ({}));
      if (j && j.ok) return { ok: true };
      return { ok: false, error: (j && j.reason) || '迁移确认失败（HTTP ' + r.status + '）' };
    } catch (e) {
      return { ok: false, error: '无法连接远端：' + (e.name === 'AbortError' ? '请求超时' : e.message) };
    }
  }

  // ---------- 远端配置拉取（pricing/devInfo/copyright/notice/ads/freeQuota/trialDays） ----------
  let cachedRemote = null;
  // R103C：实例唯一超管邮箱——心跳上报的「管理员账号」= 绑定账号口径（超管）
  function superAdminEmail() {
    try {
      const u = db.prepare('SELECT email FROM users WHERE role = ? ORDER BY id ASC LIMIT 1').get('superadmin');
      return u ? String(u.email || '').trim() : '';
    } catch (e) { return ''; }
  }
  async function pullRemote() {
    const base = remoteBase();
    if (!base) return { ok: false, error: '未配置远端服务地址' };
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 8000);
      


      const lid = encodeURIComponent(String(getSetting('license_key') || ''));
      const iid = encodeURIComponent(instanceId());
      const acc = encodeURIComponent(superAdminEmail() || '');
      
      const hfp = encodeURIComponent(fingerprintHex() || '');
      const r = await remoteFetchRaw(base + '/api/v1/remote/config?licenseId=' + lid + '&instanceId=' + iid + '&account=' + acc + '&hostFp=' + hfp, { signal: ctl.signal });
      clearTimeout(timer);
      const j = await r.json().catch(() => ({}));
      if (!j || !j.ok) return { ok: false, error: '远端配置拉取失败（HTTP ' + r.status + '）' };
      const c = j.data || {};
      // 云端裁决：吊销/到期/设备不符 → 本地自动降级免费（保留激活码与到期记录，云端恢复有效后下次拉取自动回专业版）
      if (c.licStatus === 'revoked' || c.licStatus === 'expired' || c.licStatus === 'device_mismatch') {
        if (getSetting('license_type') === 'pro') {
          setSetting('license_type', 'free');
          if (c.licStatus === 'device_mismatch') {
            setSetting('license_warn', '授权绑定设备与本机不一致，已自动降级为免费版。请确认当前实例为激活时的超管设备，或在原设备解绑后重新激活。');
          }
        }
      } else if (c.licStatus === 'valid' && (getSetting('license_type') === 'free' || getSetting('license_type') === 'trial') && getSetting('license_key')) {
        // 云端确认有效（本地可能是缓存到期误降级）：按本地到期记录恢复
        const exp = getSetting('license_expire') || '';
        if (exp === '0' || /^\d+$/.test(exp)) setSetting('license_type', 'pro');
      } else if (c.licStatus === 'restore' && (getSetting('license_type') === 'free' || getSetting('license_type') === 'trial') && !getSetting('license_key')) {
        
        const k = c.licenseId || c.licenseKey || '';
        if (k) {
          setSetting('license_type', 'pro');
          setSetting('license_key', k);
          if (c.tier) setSetting('license_tier', c.tier);
          setSetting('license_expire', (c.expireAt === 0 || c.expireAt === '0' || c.expireAt === '') ? '0' : String(c.expireAt));
          if (c.boundAccount) setSetting('license_bound_account', c.boundAccount);
          try { setSetting('license_warn', ''); } catch (e) {}
        }
      }
      cachedRemote = c;
      try { setSetting('remote_cached', JSON.stringify(cachedRemote)); } catch (e) {}
      return { ok: true, data: cachedRemote };
    } catch (e) {
      return { ok: false, error: '远端无法连接（' + (e.name === 'AbortError' ? '请求超时' : e.message) + '）' };
    }
  }
  function cached() {
    if (cachedRemote) return cachedRemote;
    try { cachedRemote = JSON.parse(getSetting('remote_cached') || '{}'); } catch (e) { cachedRemote = {}; }
    return cachedRemote;
  }
  function cachedPricing() {
    const c = cached();
    return (c && c.pricing) || { year: { price: 19.9, label: '按年订阅' }, tri: { price: 29.9, label: '三年订阅' }, lifetime: { price: 39.9, label: '永久买断' } };
  }
  function cachedDev() {
    const c = cached();
    return (c && c.devInfo) || {};
  }
  function cachedCopyright() {
    const c = cached();
    return (c && c.copyright) || '';
  }

  // ---------- 实例上报（静默） ----------
  // R103C：adminAccount=当前实例唯一超管邮箱（绑定账号口径）；云端比对绑定授权/设备不符返回 deviceMismatch，立即本地降级
  async function reportInstance() {
    const base = remoteBase();
    if (!base) return;
    const st = state();
    const sup = superAdminEmail() || st.boundAccount;
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 6000);
      const r = await remoteFetchRaw(base + '/api/v1/instance/hello', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        
        body: JSON.stringify({ instanceId: st.instanceId, version: APP_VERSION, adminAccount: sup, licenseId: getSetting('license_key') || '', ads: String(getSetting('ad_enabled', '1') || '1'), licStatus: st.type, trialDaysLeft: st.trialDaysLeft || null, trialEndAt: st.trialEndAt || null, hostFp: fingerprintHex(), slot: deploySlot() }),
        signal: ctl.signal
      });
      clearTimeout(timer);
      // 设备即时校验：云端检测授权绑定设备与本机不一致 → 立即降级免费 + 记录警示（不等下一次轮询）
      const j = await r.json().catch(() => ({}));
      if (j && j.deviceMismatch && getSetting('license_type') === 'pro') {
        setSetting('license_type', 'free');
        setSetting('license_warn', '授权绑定设备与本机不一致，已自动降级为免费版。请确认当前实例为激活时的超管设备，或在原设备解绑后重新激活。');
      }
    } catch (e) {}
  }

  // ---------- 解绑/清除本地授权（管理员密码已在前端验证） ----------
  function clearLocal() {
    setSetting('license_key', '');
    setSetting('license_type', 'free');
    setSetting('license_tier', '');
    setSetting('license_expire', '');
    setSetting('license_bound_account', '');
    return state();
  }

  // ---------- 站内购买（规格 v1.0.3：客户端站内完成购买与激活动作，远端核销发码） ----------
  async function remoteFetch(path, opts) {
    const base = remoteBase();
    if (!base) return { ok: false, error: '远程服务未就绪' };
    try {
      const ctl = new AbortController();
      const timer = setTimeout(() => ctl.abort(), 12000);
      const r = await remoteFetchRaw(base + path, Object.assign({ signal: ctl.signal, headers: { 'Content-Type': 'application/json' } }, opts || {}));
      clearTimeout(timer);
      const j = await r.json().catch(() => ({}));
      if (!j || !j.ok) return { ok: false, error: (j && j.reason) || '远端请求失败（HTTP ' + r.status + '）', status: r.status, data: j || null };
      return { ok: true, ...j, data: j };
    } catch (e) {
      return { ok: false, error: '远端无法连接（' + (e.name === 'AbortError' ? '请求超时' : e.message) + '）' };
    }
  }
  // 统一出站入口：对远端的原始 fetch 一律走这里（地址校验 + 禁止跟随重定向）。
  // 为什么必须禁跟随重定向：即便地址本身合法，公网主机也可能 302 到 http://169.254.169.254/，
  // 靠「入口校验一次」是拦不住的 —— 只有把重定向掐掉，校验结论才对整条请求链成立。
  function remoteFetchRaw(url, opts) {
    assertRemoteUrl(url);
    return fetch(url, Object.assign({ redirect: 'manual' }, opts || {}));
  }
  

  async function createRemoteOrder(tier, account, qty, ref, channel) {
    const body = { tier, account, qty: Math.max(1, Math.min(99, parseInt(qty, 10) || 1)) };
    const refStr = String(ref || '').trim();
    if (refStr) body.ref = refStr;
    

    const ch = String(channel || '').trim().toLowerCase();
    if (['alipay', 'wechat', 'manual'].includes(ch)) body.channel = ch;
    return remoteFetch('/api/v1/pay/create', { method: 'POST', body: JSON.stringify(body) });
  }
  
  async function promoRemote(path, opts) {
    return remoteFetch(path, opts || {});
  }
  

  async function verifyRemoteOrder(orderId, tradeNo, account) {
    return remoteFetch('/api/v1/pay/verify', { method: 'POST', body: JSON.stringify({ orderId, tradeNo, account }) });
  }
  



  async function queryRemoteOrder(orderId, account, queryToken) {
    let q = '/api/v1/pay/query?orderId=' + encodeURIComponent(String(orderId || '')) + '&account=' + encodeURIComponent(String(account || ''));
    if (queryToken) q += '&queryToken=' + encodeURIComponent(String(queryToken));
    return remoteFetch(q);
  }
  // ---------- 系统通知（开发者通过服务器端开发者后台全站推送，客户端拉取展示） ----------
  async function fetchSystemNotices() {
    const r = await remoteFetch('/api/v1/system-notices', { timeout: 8000 });
    if (!r.ok) return { ok: false, error: r.error || '获取失败' };
    return { ok: true, list: (r.list || []).map(n => ({ id: n.id, title: n.title, level: n.level, content: n.content || '', link: n.link || '', createdAt: n.createdAt || 0 })) };
  }

  return {
    FREE_QUOTA, TIER_LABEL,
    instanceId, instanceMeta, instanceWarnings, remoteBase, remotePub, boundAccount,
    state, checkQuota, quotaDesc, verifyOffline,
    activate, transferRequest, transferConfirm, pullRemote, cached, cachedPricing, cachedDev, cachedCopyright,
    reportInstance, clearLocal,
    createRemoteOrder, verifyRemoteOrder, queryRemoteOrder, fetchSystemNotices, promoRemote, remoteFetchRaw
  };
}

module.exports = {
  createLicense, FREE_QUOTA, TIER_DAYS, TIER_LABEL,
  // 出站地址安全策略对外暴露，供写入设置项时「早失败、给明确提示」用（remoteBase 里仍会再判一次）
  _sec: { assertRemoteUrl },
  _fp: { dmiFingerprint, envFingerprint, containerFingerprint },
  
  _slot: { deploySlot, deploySalt, legacySalt, slotSalt, stateRoot }
};
