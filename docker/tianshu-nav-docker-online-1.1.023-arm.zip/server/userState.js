/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 天枢导航 客户端 server/userState.js（R126 / 审计 R-D1：pwd_default 唯一写入口）
//
// 全站不变量：pwd_default 只表达「密码是否仍为默认值」，且只允许两条受信路径修改：
//   置 1 —— 仅当：①用户用默认密码成功登录（登录接口）；②管理员重置用户密码（重置后强制对方下次改密）。
//   置 0 —— 仅当：本人成功改密（含 profile 内改密分支、独立改密接口、忘记密码重置）。
// 邮箱/用户名变更、注册/新建用户（INSERT 默认列值 0）一律不得触碰 pwd_default（R105-B1）。
// 任何位置需要写入 pwd_default 都必须调用本模块，禁止在 server.js 等文件散落 UPDATE users SET pwd_default，
// 防止未来新增散写点破坏「只由真正改密清除」这一不变量（第63轮 R105-B1 实证教训）。
//
// 调用约定：const userState = require('./userState');

module.exports = {
  // 置 1：仅登录接口发现默认密码、管理员重置密码后调用
  setDefaultPwd(db, userId) {
    db.prepare('UPDATE users SET pwd_default = 1 WHERE id = ?').run(userId);
  },
  // 置 0：仅本人成功改密后调用
  clearDefaultPwd(db, userId) {
    db.prepare('UPDATE users SET pwd_default = 0 WHERE id = ?').run(userId);
  }
};
