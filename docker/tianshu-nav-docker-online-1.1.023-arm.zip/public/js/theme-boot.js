/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';(function(){var a='ts_theme',b='auto';try{var c=localStorage['getItem'](a);if(c==='light'||c==='dark')b=c;}catch(h){}var f;if(b==='light'||b==='dark')f=b;else try{f=window['matchMedia']('(prefers-color-scheme:\x20dark)')['matches']?'dark':'light';}catch(i){f='dark';}var g=document['documentElement'];g['setAttribute']('data-theme',f),g['setAttribute']('data-theme-mode',b);}());