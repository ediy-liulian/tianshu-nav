#!/bin/sh
# 天枢导航 · Docker 离线包升级（v1.1.023）
# 数据在 ./data，本脚本不会删除数据目录
set -e
docker rm -f tianshu-nav >/dev/null 2>&1 || true
sh ./install.sh
