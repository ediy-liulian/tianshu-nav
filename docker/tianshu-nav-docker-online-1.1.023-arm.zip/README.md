# 天枢导航 · Docker 在线部署包（混淆版） v1.1.023

> 本包仅包含**混淆后的代码**（前端 `public/`、后端 `server/` 均为 OBF 构建产物），不含可读源码，避免源码泄露与盗版。
> 与「Docker 离线部署包」的区别：离线包内置 60MB+ 预构建镜像 tar；本包不含镜像，首次部署时由 Docker 从**本地混淆代码自动构建镜像**（需联网拉取 `node:22-alpine` 基础镜像，约 40MB）。

## 部署步骤

1. 安装 Docker（含 docker compose v2）。
2. 解压本包，进入解压目录。
3. 执行安装脚本（自动构建镜像并启动）：

   ```sh
   sh install.sh
   ```

4. 浏览器访问 `http://<本机IP>:16080`。
   - 初始账号：`admin`
   - 初始密码：`ediy666`
   - 数据保存在本目录 `./data`，重装/升级均不删除。

## 升级

```sh
sh update.sh
```

## 常用命令

- 查看状态：`docker compose ps`
- 查看日志：`docker compose logs -f`
- 停止：`docker compose down`

## 说明

- 镜像基于 `node:22-alpine`（多架构，x86/arm 通用），本包内的 `server/node_modules` 为对应架构预烘焙依赖，无需 `npm install`。
- 如需更改对外端口，编辑 `docker-compose.yml` 中 `ports` 的 `16080:8080` 冒号左侧端口即可。
- 构建日期：2026-11-02
