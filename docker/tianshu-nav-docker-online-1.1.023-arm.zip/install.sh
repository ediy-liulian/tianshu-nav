#!/bin/sh
# 天枢导航 · Docker 在线部署（混淆版，v1.1.023）
# 用法：解压后在本目录执行  sh install.sh
set -e
echo "[1/3] 构建镜像（首次需联网拉取 node:22-alpine 基础镜像，约 1-2 分钟）..."
docker compose build
mkdir -p ./data
echo "[2/3] 清理同名旧容器..."
docker compose down >/dev/null 2>&1 || true
echo "[3/3] 启动容器（自动从本地混淆代码构建镜像）..."
docker compose up -d
echo "已启动：http://<本机IP>:16080  （数据保存在 ./data，初始密码 ediy666）"
