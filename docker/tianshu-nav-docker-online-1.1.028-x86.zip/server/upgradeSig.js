/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';













const crypto = require('crypto');

const UPGRADE_SIG_NAME = 'upgrade.sig.json';
/* 公钥与 EDIY 打包流水线私钥（01-服务器端/keys/upgrade-sign.priv.key）配对；
   私钥不随任何交付包分发。 */
const UPGRADE_PUBKEY = 'MCowBQYDK2VwAyEA6goeeFsJXX78dEIa77x13EgnNymfRkdNtwI90CtQbWE=';

function upgradeManifestHashOfMap(files) {
  const rows = [];
  for (const n of Object.keys(files)) {
    if (n === UPGRADE_SIG_NAME) continue;
    const b = files[n];
    rows.push(n + '|' + b.length + '|' + crypto.createHash('sha256').update(b).digest('hex'));
  }
  rows.sort();
  return crypto.createHash('sha256').update(rows.join('\n'), 'utf8').digest('hex');
}

function verifyUpgradeSig(files) {
  const raw = files[UPGRADE_SIG_NAME];
  if (!raw) {
    return { ok: false, reason: '升级包缺少完整性签名（upgrade.sig.json），已拒绝应用。请使用官方打包流水线产出的客户端升级包' };
  }
  let sig;
  try { sig = JSON.parse(raw.toString('utf8')); } catch (e) { return { ok: false, reason: '升级包签名文件无法解析' }; }
  if (!sig || sig.alg !== 'ed25519' || !sig.sign || sig.pkg !== 'tianshu-nav') {
    return { ok: false, reason: '升级包签名格式不正确（alg / 包标识不符）' };
  }
  try {
    const key = crypto.createPublicKey({ key: Buffer.from(UPGRADE_PUBKEY, 'base64'), format: 'der', type: 'spki' });
    const ok = crypto.verify(null, Buffer.from(upgradeManifestHashOfMap(files), 'hex'),
      key, Buffer.from(String(sig.sign), 'base64'));
    if (!ok) return { ok: false, reason: '升级包完整性签名校验失败（文件被篡改或非官方升级包），已拒绝应用' };
    return { ok: true, version: sig.version || '' };
  } catch (e) {
    return { ok: false, reason: '升级包签名校验异常：' + (e && e.message ? e.message : '') };
  }
}

module.exports = { UPGRADE_SIG_NAME, UPGRADE_PUBKEY, upgradeManifestHashOfMap, verifyUpgradeSig };
