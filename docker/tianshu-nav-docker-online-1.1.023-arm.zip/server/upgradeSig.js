/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
/* 客户端升级包完整性签名校验（R160 / 审计 R2）
   ------------------------------------------------------------------
   与云端 01-服务器端/tianshu-nav-cloud/src/api.js 的 verifyUpgradeSig 同一套算法、
   同一把密钥，只有 pkg 标识不同（客户端 'tianshu-nav' / 云端 'tianshu-nav-cloud'）。

   清单算法（两边必须逐字节一致，改一边就要改另一边）：
     对包内除 upgrade.sig.json 外的每个文件，取 `相对路径|字节数|sha256hex`，
     排序后用 '\n' 拼接，再对整个字符串做 sha256 → 32 字节摘要，作为 Ed25519 的签名对象。

   为什么单独成模块：这段逻辑要能被单元测试直接 require（改一个字节必须拒），
   而不是只能靠「起整个服务、传一个真包」来验——后者跑一次几十秒，没人会天天跑。
   署名：EDIY工作室 · https://www.ediy.net
*/
const crypto = require('crypto');

const UPGRADE_SIG_NAME = 'upgrade.sig.json';
/* 公钥与 EDIY 打包流水线私钥（01-服务器端/keys/upgrade-sign.priv.key）配对；
   私钥不随任何交付包分发。 */
const UPGRADE_PUBKEY = 'MCowBQYDK2VwAyEA6goeeFsJXX78dEIa77x13EgnNymfRkdNtwI90CtQbWE=';

function upgradeManifestHashOfMap(files) {
  const rows = [];
  for (const n of Object.keys(files)) {
    if (n === UPGRADE_SIG_NAME) continue;
    const b = files[n];
    rows.push(n + '|' + b.length + '|' + crypto.createHash('sha256').update(b).digest('hex'));
  }
  rows.sort();
  return crypto.createHash('sha256').update(rows.join('\n'), 'utf8').digest('hex');
}

function verifyUpgradeSig(files) {
  const raw = files[UPGRADE_SIG_NAME];
  if (!raw) {
    return { ok: false, reason: '升级包缺少完整性签名（upgrade.sig.json），已拒绝应用。请使用官方打包流水线产出的客户端升级包' };
  }
  let sig;
  try { sig = JSON.parse(raw.toString('utf8')); } catch (e) { return { ok: false, reason: '升级包签名文件无法解析' }; }
  if (!sig || sig.alg !== 'ed25519' || !sig.sign || sig.pkg !== 'tianshu-nav') {
    return { ok: false, reason: '升级包签名格式不正确（alg / 包标识不符）' };
  }
  try {
    const key = crypto.createPublicKey({ key: Buffer.from(UPGRADE_PUBKEY, 'base64'), format: 'der', type: 'spki' });
    const ok = crypto.verify(null, Buffer.from(upgradeManifestHashOfMap(files), 'hex'),
      key, Buffer.from(String(sig.sign), 'base64'));
    if (!ok) return { ok: false, reason: '升级包完整性签名校验失败（文件被篡改或非官方升级包），已拒绝应用' };
    return { ok: true, version: sig.version || '' };
  } catch (e) {
    return { ok: false, reason: '升级包签名校验异常：' + (e && e.message ? e.message : '') };
  }
}

module.exports = { UPGRADE_SIG_NAME, UPGRADE_PUBKEY, upgradeManifestHashOfMap, verifyUpgradeSig };
