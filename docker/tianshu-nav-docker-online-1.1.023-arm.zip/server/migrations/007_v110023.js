/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 迁移 007（v1.1.023）：把「工作室官网」从产品页地址纠正为工作室主站。
//
// 背景（产品方 2026-11-01）：「检查全站 EDIY 工作室 的超链接应改为 EDIY 工作室的主站。」
// 根因不是某处写错一个字符，而是两个地址一直被当成一个用：
//   · nav.ediy.net  = 天枢导航**产品页**
//   · www.ediy.net  = EDIY 工作室**主站**
// 迁移 004 把 dev_home 种成 nav.ediy.net，迁移 005 又把历史值 www.ediy.net **主动改写**成 nav.ediy.net
// —— 于是页脚「© 2026 EDIY 工作室」和「关于我们 → 官网」点进去永远是本产品自己。
//
// 本迁移只动「默认值」这一种情况：value 恰好等于 https://nav.ediy.net（或带尾斜杠）才改；
// 管理员自己填过的域名一律不动（同理 004 的注释：用户自定义数据不受影响）。
module.exports = {
  version: '007',
  up(db) {
    const NEW = 'https://www.ediy.net';
    const upd = db.prepare('UPDATE settings SET value=? WHERE key=? AND value=?');
    upd.run(NEW, 'dev_home', 'https://nav.ediy.net');
    upd.run(NEW, 'dev_home', 'https://nav.ediy.net/');
    // 老版本还没种过 dev_home 的库（极早期）：补一条，保证页脚有可点的官网
    const has = db.prepare('SELECT value FROM settings WHERE key=?').get('dev_home');
    if (!has) db.prepare('INSERT INTO settings(key, value) VALUES(?, ?)').run('dev_home', NEW);
  }
};
