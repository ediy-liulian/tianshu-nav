// 天枢导航 · 新标签页选项逻辑
const DEFAULT_URL = 'http://192.168.1.100:16080';

(async () => {
  const cfg = await chrome.storage.sync.get({ url: DEFAULT_URL });
  document.getElementById('url').value = cfg.url || DEFAULT_URL;
  document.getElementById('save').onclick = async () => {
    const url = document.getElementById('url').value.trim();
    if (!/^https?:\/\//i.test(url)) {
      document.getElementById('msg').style.color = '#f87171';
      document.getElementById('msg').textContent = '请输入以 http:// 或 https:// 开头的有效地址';
      return;
    }
    await chrome.storage.sync.set({ url });
    document.getElementById('msg').style.color = '#34d399';
    document.getElementById('msg').textContent = '已保存 ✓ 新标签页将打开：' + url;
  };
})();
