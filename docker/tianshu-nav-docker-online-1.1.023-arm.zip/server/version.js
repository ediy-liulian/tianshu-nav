/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 天枢导航 · 版本号比较唯一实现（R133 / 缺陷 B-14）
//
// 【为什么要这个文件】
// 全仓此前存在三份各自实现的版本比较，口径互不一致，典型差异：
//   · server/db.js  cmpVersion   —— 只比前 3 段（for i<3）⇒ 1.00.012.1 与 1.00.012 被判「相等」，第 4 段丢失
//   · server/server.js compareVer —— 用 Number() ⇒ '1.00.013-beta' 的 '013-beta' 变 NaN 被当 0
//                                    ⇒ 被判成 1.00.0.x，在线升级「永远检测不到新版本」
//   · 云端 src/api.js compareVer  —— 用 parseInt() ⇒ 同一串被判成 13
//                                    ⇒ 同一份 upgrade.json，客户端说「已是最新」、云端说「有新版本」
// 这不是三条小 bug，是同一规则的副本漂移（审计根因 R-B）。改为单一真源 + 一致性门禁。
//
// 【不变量】
//   1. 全仓只允许存在本实现；任何模块需要比版本号，一律 require 本文件，不得就地再写一份。
//   2. 客户端与云端各存一份**字节完全相同**的副本，由
//      04-脚本与工具/脚本/_r133_ver_single_source.py 断言 md5 相等（防未来改一边忘另一边）。
//
// 【比较规则】
//   剔除开头 v/V → 按 '.' 切段 → 每段取前导整数（parseInt 语义：'013'→13，'013-beta'→13，'abc'→0）
//   → 补 0 对齐到较长一方 → 逐段数值比较 → 返回 -1 / 0 / 1
// 刻意选择 parseInt 而非 Number：版本段允许带后缀（1.00.013-rc1 / 1.00.013+build），
// 前缀数字才是版本语义，后缀是构建标记，不应让整段退化为 0。

function parseVer(v) {
  return String(v == null ? '' : v).replace(/^v/i, '').split('.').map((s) => {
    const n = parseInt(s, 10);
    return Number.isFinite(n) ? n : 0;
  });
}

// a > b 返回 1；a < b 返回 -1；相等返回 0
function compareVer(a, b) {
  const pa = parseVer(a);
  const pb = parseVer(b);
  const n = Math.max(pa.length, pb.length);
  for (let i = 0; i < n; i++) {
    const x = pa[i] || 0;
    const y = pb[i] || 0;
    if (x !== y) return x > y ? 1 : -1;
  }
  return 0;
}

function isGreater(a, b) { return compareVer(a, b) > 0; }
function isSame(a, b) { return compareVer(a, b) === 0; }

// 正式版判定：规格书规定正式发布版为 v1.0.0，测试版（< 1.0.0）不写版本日志
function isFormalVersion(v) { return compareVer(v, '1.0.0') >= 0; }

module.exports = { parseVer, compareVer, isGreater, isSame, isFormalVersion };
