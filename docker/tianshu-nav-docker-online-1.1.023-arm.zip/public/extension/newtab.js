// 天枢导航 · 新标签页扩展逻辑
const DEFAULT_URL = 'http://192.168.1.100:16080'; // 默认部署地址（可在扩展选项中修改）

async function boot() {
  const cfg = await chrome.storage.sync.get({ url: DEFAULT_URL });
  const url = (cfg.url || '').trim();
  const tip = document.getElementById('tip');
  if (!url) {
    tip.innerHTML = '尚未配置天枢导航地址<br>请点击右上角扩展图标 → 「选项」进行配置';
    return;
  }
  try {
    // 探测目标可达性（5 秒超时）
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 5000);
    await fetch(url, { method: 'HEAD', signal: ctrl.signal });
    clearTimeout(timer);
  } catch {
    tip.innerHTML = `目标 <b>${url}</b> 暂不可达<br>请确认服务已启动（内网请使用内网地址）`;
    return;
  }
  // 可达 → 全屏嵌入
  document.body.style.background = '#fff';
  document.body.innerHTML = `<iframe src="${url}" style="position:fixed;inset:0;width:100%;height:100%;border:none"></iframe>`;
}
boot();
