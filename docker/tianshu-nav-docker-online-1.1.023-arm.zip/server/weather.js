/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 天枢导航 · 天气模块（和风天气 / wttr.in 兜底，30 分钟缓存，失败优雅降级）
const https = require('https');
const fs = require('fs');
const path = require('path');
const { DATA_DIR, getSetting } = require('./db');

const CACHE = path.join(DATA_DIR, 'cache', 'weather.json');
const TTL = 30 * 60 * 1000;

function getJson(url) {
  return new Promise((resolve) => {
    https.get(url, { timeout: 8000, headers: { 'User-Agent': 'TianshuNav/1.0' } }, (res) => {
      if (res.statusCode !== 200) { res.resume(); return resolve(null); }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        try { resolve(JSON.parse(Buffer.concat(chunks).toString('utf8'))); }
        catch { resolve(null); }
      });
      res.on('error', () => resolve(null));
    }).on('error', () => resolve(null));
  });
}

// wttr.in 英文天气描述 → 中文兜底映射（lang=zh 未生效或字段为英文时使用）
const EN_CN = {
  'Sunny': '晴', 'Clear': '晴', 'Partly cloudy': '多云', 'Partly Cloudy': '多云', 'Cloudy': '多云', 'Overcast': '阴',
  'Mist': '雾', 'Fog': '雾', 'Freezing fog': '雾', 'Haze': '霾', 'Smoke': '霾',
  'Light rain': '小雨', 'Patchy rain possible': '小雨', 'Light drizzle': '小雨', 'Moderate rain': '中雨', 'Heavy rain': '大雨', 'Rain': '雨', 'Drizzle': '小雨',
  'Thundery outbreaks possible': '雷阵雨', 'Thunderstorm': '雷阵雨', 'Moderate or heavy rain with thunder': '雷阵雨', 'Heavy rain with thunder': '雷阵雨',
  'Light snow': '小雪', 'Moderate snow': '中雪', 'Heavy snow': '大雪', 'Snow': '雪', 'Blizzard': '暴雪', 'Sleet': '雨夹雪',
  'Windy': '大风', 'Strong wind': '大风'
};
function cnText(t) {
  if (!t) return '';
  const s = String(t).trim();
  if (/[\u4e00-\u9fa5]/.test(s)) return s; // 已是中文
  return EN_CN[s] || EN_CN[s.replace(/^([A-Z])/, (m) => m.toLowerCase())] || s;
}

function normalize(city, data) {
  return {
    city,
    temp: data.temp,
    text: cnText(data.text),
    windDir: data.windDir || '',
    windScale: data.windScale || '',
    humidity: data.humidity,
    updatedAt: new Date().toISOString()
  };
}

async function fetchWeather() {
  const provider = getSetting('weather_provider') || 'wttr';
  const city = getSetting('weather_city') || '南京';
  if (provider === 'he') {
    const key = getSetting('weather_key');
    if (key) {
      const geo = await getJson(`https://geoapi.qweather.com/v2/city/lookup?location=${encodeURIComponent(city)}&key=${key}`);
      const loc = geo && geo.code === '200' && geo.location && geo.location[0];
      if (loc) {
        const now = await getJson(`https://devapi.qweather.com/v7/weather/now?location=${loc.id}&key=${key}`);
        if (now && now.code === '200' && now.now) {
          return normalize(city, { temp: now.now.temp + '℃', text: now.now.text, windDir: now.now.windDir, windScale: now.now.windScale, humidity: now.now.humidity + '%' });
        }
      }
    }
  }
  // 兜底：wttr.in（免密钥，lang=zh 请求中文描述）
  const w = await getJson(`https://wttr.in/${encodeURIComponent(city)}?format=j1&lang=zh`);
  if (w && w.current_condition && w.current_condition[0]) {
    const c = w.current_condition[0];
    return normalize(city, { temp: c.temp_C + '℃', text: c.weatherDesc[0].value, windDir: c.winddir16Point, windScale: c.windspeedKmph + 'km/h', humidity: c.humidity + '%' });
  }
  return null;
}

async function getWeather(force = false) {
  try {
    if (!force && fs.existsSync(CACHE)) {
      const raw = JSON.parse(fs.readFileSync(CACHE, 'utf8'));
      if (raw.ts && Date.now() - raw.ts < TTL && raw.data) return { ...raw.data, cached: true };
    }
    const data = await fetchWeather();
    if (data) {
      fs.writeFileSync(CACHE, JSON.stringify({ ts: Date.now(), data }));
      return { ...data, cached: false };
    }
    return { available: false, city: getSetting('weather_city') || '' };
  } catch {
    return { available: false, city: getSetting('weather_city') || '' };
  }
}

module.exports = { getWeather };
