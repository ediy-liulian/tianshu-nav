# 天枢导航（Tianshu Nav）・内网服务器导航门户

> 部署于飞牛 fnOS Docker 的统一导航入口：内网服务越多，入口越分散 —— 天枢导航把它们集中到一个清爽简约的页面上，内网点击即达，外网自动切换，无需记忆端口。

## 功能一览



| 模块    | 说明                                                        |
| ----- | --------------------------------------------------------- |
| 用户管理  | 注册 / 登录 / 找回密码，邮箱验证码校验，登录失败锁定防爆破，管理员管理用户                  |
| 邀请码   | 支持「必须邀请码」注册模式，管理员后台生成与管理邀请码                               |
| 导航管理  | 分组 + 站点（内外网双地址），拖拽排序，搜索过滤                                 |
| 内外网切换 | 按访问来源自动识别（IP 段 + 域名规则），也可手动切换 自动 / 内网 / 外网                |
| 图标    | 站点图标自动拉取（favicon.ico → HTML link → 第三方兜底），失败可手动拉取或从公共图库选择 |
| 公共图库  | 内置图标库 + 自定义上传（PNG/SVG/ICO），分类检索，引用提示                      |
| 站内通知  | 管理员发布公告 / 提醒 / 重要通知，支持置顶，用户已读标记与未读徽标；另有开发者全站推送的「系统通知」经首页广播按钮 + 红色未读数展示 |
| 个人收藏  | 普通用户星标收藏站点，我的收藏视图独立展示                                     |
| 首页    | 日期时间、当前城市天气、搜索框、分组卡片、暗黑 / 浅色 / 跟随系统三档主题                   |
| 数据管理  | 全量配置 JSON 导出 / 导入（覆盖或合并），浏览器书签 HTML 导入                    |
| 系统升级  | 更新源检测、升级包上传（白名单校验 + 自动备份）、一键回滚                            |
| 版本与关于 | 版本号、构建时间、版本日志、关于我们（官网 / 反馈邮箱 / 版权）                        |
| 浏览器插件 | Chrome/Edge 新标签页扩展（MV3），可配置部署地址                           |
| 多终端   | 响应式布局，适配 Windows / Mac / 安卓手机浏览器；可选 PWA 安装                |

## 快速部署（飞牛 fnOS · 零配置）

> 容器以 root 运行，文件与数据目录权限已内置处理，**无需任何 chmod / chown / 加配置**，解压即可部署。

1. 将部署包上传到飞牛「文件管理」并解压（得到一个 `tianshu_nav` 文件夹）。

2. 打开「Docker → Compose → 新增项目」：项目名称填 `tianshu-nav`，路径选择 `tianshu_nav` 文件夹（自动识别 `docker-compose.yml`），勾选「创建项目后立即启动」并完成。

3. 等待构建完成（首次需拉取 `node:22-alpine` 基础镜像；国内网络慢/失败时，在「Docker → 镜像仓库 → 仓库设置」添加加速源 `https://docker.1ms.run`、`https://docker.1panel.live` 后重试）。

4. 访问 `http://<飞牛IP>:16080`（默认 5 位高位端口，可在 `docker-compose.yml` 中修改左侧端口）。

5. 首次登录初始管理员（环境变量可改）：

- 账号：`admin`
- 密码：`ediy666`
- **请登录后立即在「管理后台 → 系统设置」修改密码与面板信息。**

6. 数据目录：`./data`（挂载卷，含 SQLite 数据库、图标、备份、缓存），升级与备份都在此目录内。


## 外网访问



* 有公网 IP：配置 DDNS 域名 + 路由器端口映射（将 16080 映射到公网），飞牛侧用反向代理（Nginx / Lucky）签发 HTTPS 证书。

* 无公网 IP：使用飞牛 FN Connect，或 frp /cpolar 等内网穿透，将 16080 映射为隧道域名。

* 系统会自动识别访问环境并切换站点内外网地址；识别规则在「系统设置 → 内外网识别」中配置（内网 IP 段 / 内网访问域名）。

## 浏览器插件



* 扩展位于 `public/extension/`（源码）：Chrome / Edge 地址栏输入 `chrome://extensions` → 打开「开发者模式」→「加载已解压的扩展程序」→ 选择该目录。

* 首次安装后点击扩展「选项」，填写天枢导航部署地址（如 `http://192.168.1.100:16080`），此后新标签页即自动打开天枢导航。

* 正式使用建议打包发布（可后续生成 .crx/ 商店上架）。

## 系统升级与备份



* 更新源：在「管理后台 → 系统设置 → 更新源 URL」填写 JSON 更新源（`{"version":"x.y.z","url":"...","log":"..."}`），首页「系统升级」可在线检测。

* 升级包：zip 结构限 `server/*.js` + `public/*`，上传时自动做白名单校验、`node --check` 语法检查、旧文件备份至 `data/backups/<时间戳>`，应用后（配置 `RESTART_ON_UPGRADE=1`）自动重启。

* 回滚：管理后台「系统升级 → 备份与回滚」选择备份一键回滚。

* 手动备份：直接备份 `./data` 目录即可（含数据库与图标）。

## 本地开发（源码模式）



```
cd server
npm install
$env:PORT='8080'; $env:DATA_DIR='..\data-dev'; node server.js
# 浏览器访问 http://127.0.0.1:8080/
```

## 冒烟测试

仓库内置 `server/_smoke.js` 全链路冒烟脚本（30 项断言：健康检查、认证、分组 / 站点 CRUD、内外网切换、通知、收藏、天气、导入导出、书签导入、邀请码、升级检测、防爆破、访客模式等）。已通过本地三轮全量验证（含数据累积幂等验证，30/30 通过）。



```
cd server
$env:PORT='8090'; $env:DATA_DIR='..\data-dev'; $env:ADMIN_EMAIL='admin'; $env:ADMIN_PASSWORD='ediy666'
node server.js &   # 后台启动
node _smoke.js     # 运行冒烟测试，期望 pass=30 fail=0
```

> 开发备注：本项目目录位于 Windows Junction 路径下时，node:sqlite 建表事务会异常（已通过 
>
> `fs.realpathSync`
>
>  在 db.js 中修复）；Docker / Linux 环境无此问题。

## 主要接口



* `GET /api/health` 健康检查

* `GET /api/settings/public` 公开配置（面板名、注册策略等）

* `GET /api/public/nav` 访客只读导航

* 认证：`/api/auth/register` `/login` `/send-code` `/forgot` `/me`

* 导航：`/api/nav` `/api/groups` `/api/sites` `/api/mode` `/api/favorites` `/api/notices` `/api/weather`

* 管理：`/api/admin/*`（用户 / 分组 / 站点 / 图库 / 通知 / 邀请码 / 设置 / 日志 / 导入导出 / 升级）

## 安全基线



* 密码加盐哈希（scrypt），会话令牌 HMAC 签名，支持 HttpOnly Cookie 与会话有效期配置。

* 登录失败锁定（默认 5 次锁 15 分钟）、验证码频控（60 秒 / 邮箱、5 分钟有效）。

* 外网入口建议 HTTPS（反向代理），管理后台不对外网开放为默认安全建议。

* 上传白名单：升级包仅允许 `server/*.js` 与 `public/*`；图标限 2MB 且限定图片类型。

## 目录结构



```
tianshu-nav/
├─ server/          # 后端（Express + node:sqlite，零外部数据库）
├─ public/          # 前端（index.html + css + js）与浏览器插件 extension/
├─ Dockerfile       # 多阶段构建
├─ docker-compose.yml
├─ .env.example
└─ data/            # 运行时数据卷（自动创建：db / icons / backups / cache）
```