/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 天枢导航（Tianshu Nav）· DDNS 动态域名模块（R98 新增）
// 支持 10 家服务商：阿里云 DNS / 腾讯云 DNSPod / 华为云 DNS / 花生壳 / Cloudflare / DNSPod.cn（经典）/ DuckDNS / No-IP / DynDNS / Dynu.com
// 配置存 settings.ddns_cfg（JSON 字符串；凭据字段 AES-256-GCM 加密存储，接口回显时脱敏）
// 对外：createDdns({ getSetting, setSetting, logOp, secret, isDemo }) → { getCfg, saveCfg, test, updateNow, status, start }

const crypto = require('crypto');

// ---------- 服务商元数据 ----------
const PROVIDERS = [
  { id: 'aliyun',     name: '阿里云 DNS',       fields: [{ k: 'akId', label: 'AccessKey ID' }, { k: 'akSecret', label: 'AccessKey Secret', type: 'password' }], style: 'rpc',     needRecord: true },
  { id: 'tencent',    name: '腾讯云 DNSPod',    fields: [{ k: 'secretId', label: 'SecretId' }, { k: 'secretKey', label: 'SecretKey', type: 'password' }], style: 'tc3',     needRecord: true },
  { id: 'huawei',     name: '华为云 DNS',       fields: [{ k: 'ak', label: 'Access Key' }, { k: 'sk', label: 'Secret Key', type: 'password' }], style: 'sdk',     needRecord: true },
  { id: 'oray',       name: '花生壳',           fields: [{ k: 'username', label: '花生壳账号' }, { k: 'password', label: '花生壳密码', type: 'password' }], style: 'dyn2',    needRecord: false },
  { id: 'cloudflare', name: 'Cloudflare',       fields: [{ k: 'email', label: '账户邮箱' }, { k: 'apiKey', label: 'Global API Key', type: 'password' }], style: 'cf',      needRecord: true },
  { id: 'dnspod',     name: 'DNSPod.cn（经典）', fields: [{ k: 'tokenId', label: 'Token ID' }, { k: 'token', label: 'Token', type: 'password' }], style: 'dnspod',  needRecord: true },
  { id: 'duckdns',    name: 'DuckDNS',          fields: [{ k: 'token', label: 'Token', type: 'password' }], style: 'duck',    needRecord: false },
  { id: 'noip',       name: 'No-IP',            fields: [{ k: 'username', label: '账号 / 邮箱' }, { k: 'password', label: '密码', type: 'password' }], style: 'dyn2',    needRecord: false },
  { id: 'dyn',        name: 'DynDNS',           fields: [{ k: 'username', label: '用户名' }, { k: 'password', label: '密码', type: 'password' }], style: 'dyn2',    needRecord: false },
  { id: 'dynu',       name: 'Dynu.com',         fields: [{ k: 'username', label: '用户名' }, { k: 'password', label: '密码', type: 'password' }], style: 'dyn2',    needRecord: false }
];
const DEFAULT_INTERVAL = 600; // 秒（10 分钟）
const IP_SOURCES = ['https://api.ipify.org', 'https://ifconfig.me/ip', 'https://ipv4.icanhazip.com'];

// ---------- 加密（AES-256-GCM，密钥派生自服务端 SECRET） ----------
function deriveKey(secret) { return crypto.createHash('sha256').update(String(secret)).digest(); }
function enc(secret, plain) {
  const iv = crypto.randomBytes(12);
  const c = crypto.createCipheriv('aes-256-gcm', deriveKey(secret), iv);
  const ct = Buffer.concat([c.update(String(plain), 'utf8'), c.final()]);
  return [iv.toString('base64'), c.getAuthTag().toString('base64'), ct.toString('base64')].join('.');
}
function dec(secret, token) {
  try {
    const [iv, tag, ct] = String(token || '').split('.');
    if (!iv || !tag || !ct) return null;
    const d = crypto.createDecipheriv('aes-256-gcm', deriveKey(secret), Buffer.from(iv, 'base64'));
    d.setAuthTag(Buffer.from(tag, 'base64'));
    return Buffer.concat([d.update(Buffer.from(ct, 'base64')), d.final()]).toString('utf8');
  } catch { return null; }
}
function mask(v) {
  const s = String(v || '');
  if (!s) return '';
  if (s.length <= 4) return '****';
  return s.slice(0, 2) + '****' + s.slice(-2);
}

// ---------- 配置读写 ----------
function createDdns(opts) {
  const { getSetting, setSetting, logOp, secret, isDemo } = opts;
  const API_PREFIX = 'https://';
  function loadCfg() {
    const raw = getSetting('ddns_cfg') || '';
    let base = {};
    try { base = raw ? JSON.parse(raw) : {}; } catch { base = {}; }
    const cfg = Object.assign({
      enabled: '0', provider: 'aliyun', hostname: '', interval: String(DEFAULT_INTERVAL),
      lastIp: '', lastUpdateAt: 0, nextUpdateAt: 0, lastResult: '', lastError: ''
    }, base);
    cfg.cred = cfg.credRaw ? (dec(secret, cfg.credRaw) ? JSON.parse(dec(secret, cfg.credRaw)) : {}) : {};
    return cfg;
  }
  function saveCfg(cfg, user, actionNote) {
    const out = Object.assign({}, cfg);
    out.credRaw = enc(secret, JSON.stringify(cfg.cred || {}));
    delete out.cred;
    setSetting('ddns_cfg', JSON.stringify(out));
    if (logOp && actionNote) logOp(user || { username: 'admin' }, 'DDNS 动态域名', actionNote);
  }
  function pubCfg(cfg) {
    const c = Object.assign({}, cfg, { cred: {} });
    if (!c.credRaw) { delete c.credRaw; return c; }
    const decCred = dec(secret, c.credRaw);
    const obj = decCred ? (() => { try { return JSON.parse(decCred); } catch { return {}; } })() : {};
    for (const p of PROVIDERS) {
      const pc = {};
      for (const f of p.fields) if (obj[f.k] !== undefined) pc[f.k] = mask(obj[f.k]);
      c['cred_' + p.id] = pc;
    }
    delete c.credRaw;
    return c;
  }

  // ---------- HTTP 工具 ----------
  async function httpJson(url, opt) {
    const ctl = new AbortController();
    const to = setTimeout(() => ctl.abort(), 12000);
    try {
      const r = await fetch(url, Object.assign({ signal: ctl.signal }, opt));
      const txt = await r.text();
      let j = null;
      try { j = JSON.parse(txt); } catch {}
      return { status: r.status, ok: r.ok, text: txt, json: j };
    } finally { clearTimeout(to); }
  }
  // 阿里云 / 腾讯云 / 华为云共用的 RFC3986 编码与 HMAC
  const ENC = (s) => encodeURIComponent(s).replace(/[!'()*]/g, (c) => '%' + c.charCodeAt(0).toString(16).toUpperCase());
  const hmac = (key, data, algo) => crypto.createHmac(algo, key).update(data).digest();
  const hmacHex = (key, data, algo) => hmac(key, data, algo).toString('hex');
  const sha256Hex = (s) => crypto.createHash('sha256').update(s).digest('hex');

  // ---------- 取公网 IP ----------
  async function getPublicIp() {
    for (const u of IP_SOURCES) {
      try {
        const r = await httpJson(u);
        if (r.status === 200) {
          const ip = (r.text || '').trim();
          if (/^\d{1,3}(\.\d{1,3}){3}$/.test(ip)) return ip;
        }
      } catch {}
    }
    return null;
  }

  // 拆分完整记录 → 主域 + 子域（aliyun/tencent/huawei/cloudflare/dnspod 需要）
  function splitHost(h) {
    const s = String(h || '').trim().toLowerCase();
    if (!s || !s.includes('.')) return { domain: s, sub: '@' };
    const parts = s.split('.');
    if (parts.length <= 2) return { domain: s, sub: '@' };
    const sub = parts[0];
    const domain = parts.slice(1).join('.');
    return { domain, sub };
  }

  // ---------- 各服务商实现 ----------
  const impl = {
    // 阿里云 RPC（HMAC-SHA1）
    async aliyun(cfg, ip) {
      const { akId, akSecret } = cfg.cred || {};
      if (!akId || !akSecret) throw new Error('缺少 AccessKey ID / Secret');
      const { domain, sub } = splitHost(cfg.hostname);
      const query = (extra) => {
        const q = Object.assign({
          Format: 'JSON', Version: '2015-01-09', AccessKeyId: akId,
          SignatureMethod: 'HMAC-SHA1', SignatureVersion: '1.0',
          SignatureNonce: crypto.randomUUID(), Timestamp: new Date().toISOString().replace(/\.\d{3}Z$/, 'Z')
        }, extra);
        const sorted = Object.keys(q).sort();
        const canonical = sorted.map((k) => ENC(k) + '=' + ENC(q[k])).join('&');
        const strToSign = 'GET&%2F&' + ENC(canonical);
        q.Signature = Buffer.from(hmac(akSecret + '&', strToSign, 'sha1')).toString('base64');
        return q;
      };
      // 1) 查询记录
      const list = await httpJson(API_PREFIX + 'alidns.aliyuncs.com/?' + new URLSearchParams(query({ Action: 'DescribeDomainRecords', DomainName: domain, RRKeyWord: sub === '@' ? '' : sub })).toString());
      const lj = list.json || {};
      if (!list.ok || lj.Code) throw new Error('阿里云查询失败：' + (lj.Code ? lj.Code + ' ' + (lj.Message || '') : list.text.slice(0, 120)));
      const recs = (lj.DomainRecords && lj.DomainRecords.Record) || [];
      const hit = recs.find((r) => r.Type === 'A' && (sub === '@' ? !r.RR || r.RR === '@' || r.RR === '' : r.RR === sub));
      if (!hit) throw new Error('未找到 A 记录 ' + cfg.hostname + '（请先在阿里云控制台创建）');
      // 2) 更新
      const upd = await httpJson(API_PREFIX + 'alidns.aliyuncs.com/?' + new URLSearchParams(query({ Action: 'UpdateDomainRecord', RecordId: hit.RecordId, RR: hit.RR || sub, Type: 'A', Value: ip, TTL: '600' })).toString());
      const uj = upd.json || {};
      if (!upd.ok || uj.Code) throw new Error('阿里云更新失败：' + (uj.Code ? uj.Code + ' ' + (uj.Message || '') : upd.text.slice(0, 120)));
      return '阿里云 A 记录已更新 → ' + ip;
    },
    // 腾讯云 DNSPod（TC3-HMAC-SHA256）
    async tencent(cfg, ip) {
      const { secretId, secretKey } = cfg.cred || {};
      if (!secretId || !secretKey) throw new Error('缺少 SecretId / SecretKey');
      const { domain, sub } = splitHost(cfg.hostname);
      const host = 'dnspod.tencentcloudapi.com';
      const ts = Math.floor(Date.now() / 1000);
      const date = new Date(ts * 1000).toISOString().slice(0, 10);
      const ct = 'application/json; charset=utf-8';
      const sign = (payload, action) => {
        const hashed = sha256Hex(payload);
        const ch = 'content-type:' + ct + '\nhost:' + host + '\n';
        const cr = 'POST\n/\n\n' + ch + '\ncontent-type;host\n' + hashed;
        const scope = date + '/dnspod/tc3_request';
        const sts = 'TC3-HMAC-SHA256\n' + ts + '\n' + scope + '\n' + sha256Hex(cr);
        const kDate = hmac('TC3' + secretKey, date, 'sha256');
        const kService = hmac(kDate, 'dnspod', 'sha256');
        const kSigning = hmac(kService, 'tc3_request', 'sha256');
        const sig = hmacHex(kSigning, sts, 'sha256');
        return { auth: 'TC3-HMAC-SHA256 Credential=' + secretId + '/' + scope + ', SignedHeaders=content-type;host, Signature=' + sig, action };
      };
      const call = async (action, payload) => {
        const body = JSON.stringify(payload);
        const { auth } = sign(body, action);
        const r = await httpJson(API_PREFIX + host + '/', {
          method: 'POST', headers: {
            'Content-Type': ct, Host: host, Authorization: auth,
            'X-TC-Action': action, 'X-TC-Timestamp': String(ts), 'X-TC-Version': '2021-03-23', 'X-TC-Region': 'ap-guangzhou'
          }, body
        });
        const j = r.json || {};
        if (!r.ok || j.Response && j.Response.Error) throw new Error('腾讯云' + (j.Response && j.Response.Error ? j.Response.Error.Code + ' ' + j.Response.Error.Message : '请求失败'));
        return j.Response || {};
      };
      const list = await call('DescribeRecordList', { Domain: domain, SubDomain: sub === '@' ? '' : sub, RecordType: 'A', Limit: 100 });
      const recs = list.RecordList || [];
      const hit = recs.find((x) => x.Type === 'A' && (x.Name === cfg.hostname.toLowerCase() || x.Name === sub || (sub === '@' && x.Name === domain)));
      if (!hit) throw new Error('未找到 A 记录 ' + cfg.hostname + '（请先在腾讯云控制台创建）');
      await call('ModifyRecord', { Domain: domain, RecordType: 'A', RecordLine: '默认', RecordId: String(hit.RecordId), SubDomain: sub === '@' ? '@' : sub, Value: ip });
      return '腾讯云 A 记录已更新 → ' + ip;
    },
    // 华为云 DNS（SDK-HMAC-SHA256）
    async huawei(cfg, ip) {
      const { ak, sk } = cfg.cred || {};
      if (!ak || !sk) throw new Error('缺少 Access Key / Secret Key');
      const { domain, sub } = splitHost(cfg.hostname);
      const host = 'dns.myhuaweicloud.com';
      const call = async (method, uri, body) => {
        const ts = new Date().toISOString().replace(/\.\d{3}Z$/, 'Z');
        const payloadHash = sha256Hex(body || '');
        const ch = 'content-type:application/json\nhost:' + host + '\nx-sdk-date:' + ts + '\n';
        const sh = 'content-type;host;x-sdk-date';
        const u = uri.split('?')[0];
        const qs = uri.split('?')[1] || '';
        const cr = method + '\n' + u + '\n' + qs + '\n' + ch + '\n' + sh + '\n' + payloadHash;
        const sts = 'SDK-HMAC-SHA256\n' + ts + '\n' + sha256Hex(cr);
        const sig = hmacHex(sk, sts, 'sha256');
        const r = await httpJson(API_PREFIX + host + uri, {
          method, headers: {
            'Content-Type': 'application/json', Host: host, 'X-Sdk-Date': ts,
            Authorization: 'SDK-HMAC-SHA256 Access=' + ak + ', SignedHeaders=' + sh + ', Signature=' + sig
          }, body: body || undefined
        });
        if (!r.ok) throw new Error('华为云请求失败：' + r.text.slice(0, 160));
        return r.json || {};
      };
      const zones = await call('GET', '/v2/zones?name=' + ENC(domain));
      const z = (zones.zones || []).find((x) => (x.name || '').toLowerCase() === domain);
      if (!z) throw new Error('未找到域名 ' + domain + '（请先在华为云控制台添加）');
      const rs = await call('GET', '/v2/zones/' + z.id + '/recordsets?name=' + ENC(cfg.hostname) + '&type=A');
      let rec = (rs.recordsets || []).find((x) => x.type === 'A');
      if (!rec) throw new Error('未找到 A 记录 ' + cfg.hostname + '（请先在华为云控制台创建）');
      const body = JSON.stringify({ name: cfg.hostname + '.', type: 'A', ttl: 600, records: [ip] });
      await call('PUT', '/v2/zones/' + z.id + '/recordsets/' + rec.id, body);
      return '华为云 A 记录已更新 → ' + ip;
    },
    // Cloudflare（REST）
    async cloudflare(cfg, ip) {
      const { email, apiKey } = cfg.cred || {};
      if (!apiKey) throw new Error('缺少 Global API Key');
      const h = { 'X-Auth-Email': email || '', 'X-Auth-Key': apiKey, 'Content-Type': 'application/json' };
      const zones = await httpJson(API_PREFIX + 'api.cloudflare.com/client/v4/zones?name=' + ENC(cfg.hostname.split('.').slice(1).join('.') || cfg.hostname) + '&per_page=1', { headers: h });
      const zj = zones.json || {};
      if (!zones.ok || !zj.success) throw new Error('Cloudflare 鉴权失败：' + (zj.errors || []).map((e) => e.message).join(';') || '请检查邮箱与 API Key');
      const zone = (zj.result || [])[0];
      if (!zone) throw new Error('未找到域名（请确认账号下已添加该域名）');
      const zid = zone.id;
      const list = await httpJson(API_PREFIX + 'api.cloudflare.com/client/v4/zones/' + zid + '/dns_records?type=A&name=' + ENC(cfg.hostname.toLowerCase()) + '&per_page=1', { headers: h });
      const lj = list.json || {};
      const rec = ((lj.result || [])[0]);
      if (rec) {
        const upd = await httpJson(API_PREFIX + 'api.cloudflare.com/client/v4/zones/' + zid + '/dns_records/' + rec.id, { method: 'PATCH', headers: h, body: JSON.stringify({ content: ip }) });
        if (!upd.ok) throw new Error('Cloudflare 更新失败：' + (upd.text || '').slice(0, 120));
      } else {
        const add = await httpJson(API_PREFIX + 'api.cloudflare.com/client/v4/zones/' + zid + '/dns_records', { method: 'POST', headers: h, body: JSON.stringify({ type: 'A', name: cfg.hostname.toLowerCase(), content: ip, ttl: 1, proxied: false }) });
        if (!add.ok) throw new Error('Cloudflare 新增记录失败：' + (add.text || '').slice(0, 120));
      }
      return 'Cloudflare A 记录已更新 → ' + ip;
    },
    // DNSPod 经典（dnsapi.cn，Token）
    async dnspod(cfg, ip) {
      const { tokenId, token } = cfg.cred || {};
      if (!tokenId || !token) throw new Error('缺少 Token ID / Token');
      const { domain, sub } = splitHost(cfg.hostname);
      const form = (extra) => Object.assign({ login_token: tokenId + ',' + token, format: 'json' }, extra);
      const post = async (act, data) => {
        const r = await httpJson(API_PREFIX + 'dnsapi.cn/' + act, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(form(data)).toString() });
        const j = r.json || {};
        if (j.status && j.status.code !== '1') throw new Error('DNSPod ' + (j.status.message || act) + ' 失败');
        return j;
      };
      const list = await post('Record.List', { domain, sub_domain: sub === '@' ? '' : sub, record_type: 'A', length: 100 });
      const recs = list.records || [];
      const hit = recs.find((x) => x.type === 'A' && (x.name === sub || (sub === '@' && (x.name === '@' || x.name === domain))));
      if (!hit) throw new Error('未找到 A 记录 ' + cfg.hostname + '（请先在 DNSPod 控制台创建）');
      await post('Record.Ddns', { domain, sub_domain: sub === '@' ? '@' : sub, record_id: hit.id, record_line: hit.line || '默认', value: ip });
      return 'DNSPod A 记录已更新 → ' + ip;
    },
    // DuckDNS
    async duckdns(cfg, ip) {
      const { token } = cfg.cred || {};
      if (!token) throw new Error('缺少 Token');
      const name = String(cfg.hostname || '').split('.')[0];
      if (!name) throw new Error('域名格式不正确（DuckDNS 使用 xxx.duckdns.org）');
      const r = await httpJson(API_PREFIX + 'www.duckdns.org/update?domains=' + ENC(name) + '&token=' + ENC(token) + '&ip=' + ENC(ip) + '&verbose=true');
      const t = (r.text || '').trim();
      if (!/^OK/i.test(t)) throw new Error('DuckDNS 更新失败：' + t.slice(0, 120));
      return 'DuckDNS 已更新 → ' + ip;
    },
    // dyn2 系（No-IP / DynDNS / Dynu / 花生壳）
    async dyn2(cfg, ip, base) {
      const { username, password } = cfg.cred || {};
      if (!username || !password) throw new Error('缺少账号 / 密码');
      const auth = Buffer.from(username + ':' + password).toString('base64');
      const r = await httpJson(API_PREFIX + base + '?hostname=' + ENC(cfg.hostname) + '&myip=' + ENC(ip), { headers: { Authorization: 'Basic ' + auth } });
      const t = (r.text || '').trim().toLowerCase();
      if (t.startsWith('good') || t.startsWith('nochg')) return '记录已更新 → ' + ip + '（' + t + '）';
      if (t.startsWith('badauth')) throw new Error('账号或密码错误（badauth）');
      if (t.startsWith('notfqdn')) throw new Error('域名格式不正确（notfqdn）');
      if (t.startsWith('nohost') || t.startsWith('abuse') || t.startsWith('911') || t.startsWith('bad')) throw new Error('更新失败：' + t);
      throw new Error('未知响应：' + t.slice(0, 120));
    }
  };

  function routeFor(provider) {
    const p = PROVIDERS.find((x) => x.id === provider) || PROVIDERS[0];
    const base = {
      aliyun: null, tencent: null, huawei: null, cloudflare: null, dnspod: null,
      duckdns: null,
      oray: 'ddns.oray.com/ph/update',
      noip: 'dynupdate.no-ip.com/nic/update',
      dyn: 'members.dyndns.org/nic/update',
      dynu: 'api.dynu.com/nic/update'
    }[p.id];
    return { p, base };
  }

  async function runUpdate(force) {
    const cfg = loadCfg();
    if (cfg.enabled !== '1') return { ok: false, error: 'DDNS 未启用' };
    if (!cfg.hostname) { cfg.lastError = '未填写域名'; cfg.lastResult = 'err'; saveCfg(cfg); return { ok: false, error: cfg.lastError }; }
    const ip = await getPublicIp();
    if (!ip) { cfg.lastError = '获取公网 IP 失败'; cfg.lastResult = 'err'; saveCfg(cfg); return { ok: false, error: cfg.lastError }; }
    if (!force && ip === cfg.lastIp) {
      const next = Date.now() + Number(cfg.interval || DEFAULT_INTERVAL) * 1000;
      cfg.nextUpdateAt = next; cfg.lastResult = 'skip'; cfg.lastError = ''; cfg.lastIp = ip; saveCfg(cfg);
      return { ok: true, message: '公网 IP 未变化（' + ip + '），无需更新' };
    }
    const { p, base } = routeFor(cfg.provider);
    const fn = impl[p.id] || impl.dyn2;
    try {
      const msg = p.style === 'dyn2' ? await fn.call(impl, cfg, ip, base) : await fn.call(impl, cfg, ip);
      cfg.lastIp = ip; cfg.lastUpdateAt = Date.now();
      cfg.nextUpdateAt = Date.now() + Number(cfg.interval || DEFAULT_INTERVAL) * 1000;
      cfg.lastResult = 'ok'; cfg.lastError = '';
      saveCfg(cfg);
      return { ok: true, message: msg };
    } catch (e) {
      cfg.lastResult = 'err'; cfg.lastError = e && e.message ? e.message : String(e);
      cfg.nextUpdateAt = Date.now() + 5 * 60 * 1000; // 失败 5 分钟后重试
      saveCfg(cfg);
      return { ok: false, error: cfg.lastError };
    }
  }

  function start(sec) {
    setInterval(() => {
      const cfg = loadCfg();
      if (cfg.enabled === '1' && cfg.hostname && (!cfg.nextUpdateAt || Date.now() >= cfg.nextUpdateAt)) {
        runUpdate(false).catch(() => {});
      }
    }, Math.max(30, sec || 60) * 1000);
  }

  return {
    PROVIDERS,
    start,
    getCfg() { return pubCfg(loadCfg()); },
    save(cfg, user, note) {
      if (isDemo && isDemo()) throw new Error('在线演示环境不支持修改 DDNS 配置');
      const cur = loadCfg();
      const allowed = ['enabled', 'provider', 'hostname', 'interval'];
      for (const k of allowed) if (cfg[k] !== undefined) cur[k] = String(cfg[k]);
      // 凭据：仅提交非空字段才覆盖；空字段保持已保存值
      const p = PROVIDERS.find((x) => x.id === cur.provider) || PROVIDERS[0];
      const cred = Object.assign({}, cur.cred);
      let anyCred = false;
      for (const f of p.fields) {
        const v = cfg['cred_' + f.k];
        if (v !== undefined && v !== null && String(v).trim() !== '') { cred[f.k] = String(v).trim(); anyCred = true; }
      }
      if (anyCred) cur.cred = cred;
      if (!cur.hostname || !cur.hostname.includes('.')) throw new Error('请填写完整的域名（如 ddns.example.com）');
      cur.interval = String(Math.max(60, Number(cur.interval) || DEFAULT_INTERVAL));
      if (cur.enabled === '1') {
        cur.nextUpdateAt = 0; // 启用后立即进入首次检查
        cur.lastResult = ''; cur.lastError = '';
      }
      saveCfg(cur, user, note || ('保存配置（' + (PROVIDERS.find((x) => x.id === cur.provider) || {}).name + '）'));
      return pubCfg(cur);
    },
    async test() {
      if (isDemo && isDemo()) throw new Error('在线演示环境不支持测试');
      const cfg = loadCfg();
      if (!cfg.hostname) throw new Error('请先填写域名');
      const { p, base } = routeFor(cfg.provider);
      const fn = impl[p.id] || impl.dyn2;
      const ip = await getPublicIp();
      if (!ip) throw new Error('获取公网 IP 失败，请检查网络');
      try {
        const msg = p.style === 'dyn2' ? await fn.call(impl, cfg, ip, base) : await fn.call(impl, cfg, ip);
        return { ok: true, message: msg, ip };
      } catch (e) {
        return { ok: false, error: e && e.message ? e.message : String(e), ip };
      }
    },
    updateNow() { return runUpdate(true); },
    status() {
      const cfg = loadCfg();
      return {
        enabled: cfg.enabled, provider: cfg.provider, hostname: cfg.hostname, interval: cfg.interval,
        lastIp: cfg.lastIp, lastUpdateAt: cfg.lastUpdateAt, nextUpdateAt: cfg.nextUpdateAt,
        lastResult: cfg.lastResult, lastError: cfg.lastError
      };
    }
  };
}

module.exports = { createDdns, PROVIDERS };
