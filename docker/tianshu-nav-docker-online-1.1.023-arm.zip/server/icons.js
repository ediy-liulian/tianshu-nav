/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';
// 天枢导航 · 网站图标自动拉取模块
// 拉取顺序：站点根 favicon.ico → 解析首页 HTML <link rel=icon> → 第三方兜底(google s2) → 内置默认
const http = require('http');
const https = require('https');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');
const { DATA_DIR } = require('./db');

const ICON_DIR = path.join(DATA_DIR, 'icons', 'auto');
const TIMEOUT = 6000;
const MAX_BYTES = 1024 * 1024; // 1MB
const ALLOWED_TYPES = ['image/png', 'image/x-icon', 'image/vnd.microsoft.icon', 'image/jpeg', 'image/webp', 'image/svg+xml', 'image/gif'];
// 完整浏览器 UA：部分站点（如百度）对非浏览器 UA 直接返回跳转页
const DEFAULT_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36';

// 判断是否内网/局域网地址（IP 或局域网主机名）
function isLanAddr(host) {
  return /^\d{1,3}(\.\d{1,3}){3}$/.test(host) // 纯 IP
    || /^(localhost|nas|router|home|dsm|freenas|truenas|synology|群晖)$/i.test(host)
    || host.endsWith('.local') || host.endsWith('.lan') || host.endsWith('.home')
    || host.startsWith('192.168.') || host.startsWith('10.')
    // R179：原写法是 startsWith('172.2') / startsWith('172.3')，会把 172.200.x.x–172.255.x.x
    //   与 172.30–172.39（均为公网）误判成内网 ⇒ 协议补成 http:// ⇒ 公网站点抓不到图标。
    //   172.16.0.0/12 的准确范围是第二段 16–31，用正则精确匹配。
    || /^172\.(1[6-9]|2\d|3[01])\./.test(host)
    || host.split('.').length === 1;
}

// R179（审计 P2-006）：链路本地 / 云元数据地址一律不抓取。
// 为什么不堵整个内网：内网 favicon 抓取是导航产品的核心功能（NAS / 路由器 / 群晖），
//   审计报告 §5.2 也认定「内网抓取为设计功能」，堵了整个产品就没用了。
// 但下面这几类地址不对应任何导航场景，却能读到实例凭据，因此单独阻断：
//   169.254.0.0/16        链路本地（AWS / GCP / Azure / 腾讯云的填充地址段）
//   169.254.169.254       各云厂商元数据服务（可读临时凭据 / 实例身份）
//   100.100.100.200       阿里云元数据专用地址
//   fd00:ec2::254         AWS IPv6 元数据
//   fe80::/10             IPv6 链路本地
//   metadata(.google.internal) / instance-data  元数据主机名
// 阻断点放在 fetchUrl（唯一出网口）：重定向、候选源、<link rel=icon>、跳转页全都经过它，
//   在这里判一次即全覆盖，不会出现「302 跳到元数据地址」绕过的路径。
const META_HOST = /^(metadata|metadata\.google\.internal|instance-data|metadata\.azure\.com)$/i;
function isBlockedHost(host) {
  const h = String(host || '').toLowerCase().replace(/^\[|\]$/g, '');
  if (!h) return true;
  if (META_HOST.test(h)) return true;
  if (h === '100.100.100.200') return true;
  if (h === 'fd00:ec2::254' || h === '::') return true;
  if (/^169\.254\.\d{1,3}\.\d{1,3}$/.test(h)) return true;   // IPv4 链路本地
  if (/^fe[89ab][0-9a-f]:/i.test(h)) return true;             // IPv6 链路本地 fe80::/10
  return false;
}
// URL 规范化：裸域名自动补协议——IP / 局域网主机名补 http://（内网服务以 http 为主），公网域名补 https://
function normalizeUrl(raw) {
  let u = String(raw || '').trim();
  if (!u) return '';
  if (!/^[a-z][a-z0-9+.-]*:\/\//i.test(u)) {
    const hostPart = u.split('/')[0].split(':')[0];
    u = (isLanAddr(hostPart) ? 'http://' : 'https://') + u;
  }
  try {
    const p = new URL(u);
    if (!p.hostname) return '';
    return u;
  } catch { return ''; }
}
// 候选源：域名 [https://www.x, https://x, http://x]；IP/局域网 [http://ip, https://ip]（http 优先）
function hostCandidates(url) {
  let u;
  try { u = new URL(url); } catch { return [url]; }
  const h = u.hostname;
  const isIp = /^\d{1,3}(\.\d{1,3}){3}$/.test(h);
  if (isIp || isLanAddr(h)) {
    const port = u.port ? ':' + u.port : '';
    return [...new Set([`http://${h}${port}`, `https://${h}${port}`, u.origin])];
  }
  const out = [];
  if (h.split('.').length === 2 && !h.startsWith('www.')) out.push(`https://www.${h}`);
  out.push(`https://${h}`, `http://${h}`);
  return [...new Set(out)];
}

function getExt(ct) {
  if (ct.includes('png')) return '.png';
  if (ct.includes('jpeg') || ct.includes('jpg')) return '.jpg';
  if (ct.includes('webp')) return '.webp';
  if (ct.includes('svg')) return '.svg';
  if (ct.includes('gif')) return '.gif';
  return '.ico';
}

function fetchUrl(url, { acceptHtml = false } = {}) {
  return new Promise((resolve) => {
    // R179（审计 P2-006）：出网前先判目标是链路本地 / 云元数据地址，命中即当作抓取失败。
    // 所有抓取路径（重定向 302、候选源、icon href、跳转页）都从这里出去，判一次全覆盖。
    let _host = '';
    try { _host = new URL(url).hostname; } catch { return resolve(null); }
    if (isBlockedHost(_host)) return resolve(null);
    let settled = false;
    // 总超时兜底：node http 的 timeout 选项不覆盖 DNS 解析阶段，公网域名 DNS 慢/不可达时
    // 会长期占用 libuv 线程池，进而拖垮整个服务。此处 8s 兜底保证任何情况都有界返回。
    const timer = setTimeout(() => done(null), 8000);
    function done(v) { if (!settled) { settled = true; clearTimeout(timer); resolve(v); } }
    let mod;
    try { mod = url.startsWith('https') ? https : http; } catch { return done(null); }
    let req;
    try {
      req = mod.get(url, { headers: { 'User-Agent': DEFAULT_UA, Accept: acceptHtml ? 'text/html,*/*' : '*/*' }, timeout: TIMEOUT, rejectUnauthorized: false }, (res) => {
        if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
          res.resume();
          let next;
          try { next = new URL(res.headers.location, url).toString(); } catch { return done(null); }
          return done(fetchUrl(next, { acceptHtml }));
        }
        if (res.statusCode !== 200) { res.resume(); return done(null); }
        const ct = (res.headers['content-type'] || '').split(';')[0].trim().toLowerCase();
        const chunks = [];
        let size = 0;
        res.on('data', (c) => {
          size += c.length;
          if (size > MAX_BYTES) { req.destroy(); done(null); return; }
          chunks.push(c);
        });
        res.on('end', () => {
          let buf = Buffer.concat(chunks);
          if (!buf.length) return done(null);
          // 解压 gzip / deflate（主流站点首页基本都压缩传输，不解压将无法解析 title 与图标 link）
          const enc = (res.headers['content-encoding'] || '').toLowerCase();
          try {
            if (enc.includes('gzip')) buf = zlib.gunzipSync(buf);
            else if (enc.includes('deflate')) buf = zlib.inflateSync(buf);
          } catch {}
          if (!acceptHtml && !ALLOWED_TYPES.includes(ct)) return done(null);
          done({ buf, ct });
        });
        res.on('error', () => done(null));
      });
    } catch { return done(null); }
    req.on('error', () => done(null));
    req.on('timeout', () => { req.destroy(); done(null); });
  });
}

function parseIconLink(html, baseUrl) {
  const links = [...html.matchAll(/<link[^>]*rel=["']?(?:shortcut\s+)?icon["']?[^>]*>/gi)];
  for (const m of links) {
    const href = m[0].match(/href=["']([^"']+)["']/i);
    if (href) return new URL(href[1], baseUrl).toString();
  }
  // 兜底：任意含 icon 的 link
  const any = [...html.matchAll(/<link[^>]*href=["']([^"']+)["'][^>]*>/gi)];
  for (const m of any) {
    if (/icon/i.test(m[0])) return new URL(m[1], baseUrl).toString();
  }
  return null;
}

// 全局时限：单次站点探测 / 图标拉取的总耗时上限（含 DNS、重定向、多候选源串行尝试）
function withDeadline(promise, ms = 12000, fallback = null) {
  return Promise.race([promise, new Promise((r) => setTimeout(() => r(fallback), ms))]);
}

async function fetchFavicon(url) {
  let u;
  try { u = new URL(url); } catch { return null; }
  // 依次尝试各候选源（www 优先回退），任一命中即返回
  for (const origin of hostCandidates(u.toString())) {
    let r = await fetchUrl(`${origin}/favicon.ico`);
    if (!r) {
      const html = await fetchUrl(`${origin}/`, { acceptHtml: true });
      if (html) {
        const iconUrl = parseIconLink(html.buf.toString('utf8'), origin);
        if (iconUrl) r = await fetchUrl(iconUrl);
      }
    }
    if (r && r.buf && r.buf.length) return r;
  }
  return null;
}

// 解析 HTML 中的跳转地址（location.replace / location.href / meta refresh），无则返回空
function parseRedirect(text, baseUrl) {
  let m = /(?:location\.replace\s*\(\s*|location\.href\s*=\s*|window\.location\s*=\s*)["']([^"']+)["']/i.exec(text);
  if (!m) m = /<meta[^>]+http-equiv=["']?refresh["']?[^>]+content=["']?[^"']*url=([^"']+)["']?/i.exec(text);
  if (!m) return '';
  try { return new URL(m[1], baseUrl).toString(); } catch { return ''; }
}

// 站点信息探测：拉取首页 HTML，解析 <title> 与 favicon（新增站点一键回填用）
async function probeSite(rawUrl) {
  const url = normalizeUrl(rawUrl);
  if (!url) return null;
  let u;
  try { u = new URL(url); } catch { return null; }
  return withDeadline((async () => {
    const origins = hostCandidates(u.toString());
    let title = '', iconResult = null;
    for (const origin of origins) {
      let html = await fetchUrl(`${origin}/`, { acceptHtml: true });
      if (html) {
        let text = html.buf.toString('utf8');
        // 跳转页跟随一次（百度等站点对非交互 UA 返回 location.replace 跳转页）
        const redir = parseRedirect(text, origin);
        if (redir && !/<title[^>]*>[\s\S]*?<\/title>/i.test(text)) {
          const h2 = await fetchUrl(redir, { acceptHtml: true });
          if (h2) { html = h2; text = h2.buf.toString('utf8'); }
        }
        const tm = /<title[^>]*>([\s\S]*?)<\/title>/i.exec(text);
        if (tm) title = (tm[1].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim()).slice(0, 120);
        if (!iconResult) {
          const iconUrl = parseIconLink(text, origin);
          if (iconUrl) iconResult = await fetchUrl(iconUrl);
        }
      }
      // favicon.ico 兜底：无论是否已拿到标题，都尝试当前源，避免拿到 title 就漏掉图标
      if (!iconResult) iconResult = await fetchUrl(`${origin}/favicon.ico`);
      // 标题与图标都已取得则提前结束
      if (title && iconResult) break;
    }
    if (!iconResult && !title) return null;
    let filename = '';
    if (iconResult && iconResult.buf && iconResult.buf.length) {
      const ext = getExt(iconResult.ct);
      const key = crypto.createHash('md5').update(url).digest('hex');
      filename = `${key}${ext}`;
      try { fs.writeFileSync(path.join(ICON_DIR, filename), iconResult.buf); } catch { filename = ''; }
    }
    return { ok: true, title, filename };
  })(), 12000, null);
}

// 主入口：返回 {filename, ok}，缓存到 data/icons/；失败返回 null
async function ensureIcon(siteUrl, force = false) {
  const url = normalizeUrl(siteUrl);
  if (!url) return { ok: false };
  const key = crypto.createHash('md5').update(url).digest('hex');
  if (!force) {
    const existing = fs.readdirSync(ICON_DIR).find((f) => f.startsWith(key));
    if (existing) return { filename: existing, ok: true, cached: true };
  }
  let r = await withDeadline(fetchFavicon(url), 12000, null);
  if (!r) {
    // 3) 第三方兜底（google s2 仅作最后尝试，受全局时限约束，失败不影响结果）
    try {
      const host = new URL(url).hostname;
      r = await withDeadline(fetchUrl(`https://www.google.com/s2/favicons?domain=${host}&sz=64`), 5000, null);
    } catch { r = null; }
  }
  if (!r || !r.buf || !r.buf.length) return { ok: false };
  const ext = getExt(r.ct);
  const filename = `${key}${ext}`;
  fs.writeFileSync(path.join(ICON_DIR, filename), r.buf);
  return { filename, ok: true };
}

// 静态图标文件路由（读 <dir>/<filename>，dir 由调用方限定；lib=true 走图库/上传宽松命名）
function serveIcon(req, res, filename, dir = ICON_DIR, lib = false) {
  // auto 通道：自动抓取图标命名 = md5(url)+ext（32 位 hex，严格）
  const STRICT = /^[0-9a-f]{32}\.(png|jpg|jpeg|webp|svg|gif|ico)$/i;
  // library/upload 通道：内置示例 sample-*.svg、上传 `${Date.now()}_xxxxxx.ext`
  const LIB = /^[A-Za-z0-9_][A-Za-z0-9_.-]{0,79}\.(png|jpg|jpeg|webp|svg|gif|ico)$/;
  const re = lib ? LIB : STRICT;
  // R94-2：白名单 + basename 二次校验（防目录穿越：拒绝 .. / 路径分隔符）
  if (!re.test(filename) || path.basename(filename) !== filename) {
    return res.status(404).end();
  }
  const p = path.join(dir, filename);
  if (!fs.existsSync(p)) return res.status(404).end();
  const ct = { png: 'image/png', jpg: 'image/jpeg', jpeg: 'image/jpeg', webp: 'image/webp', svg: 'image/svg+xml', gif: 'image/gif', ico: 'image/x-icon' }[filename.split('.').pop().toLowerCase()] || 'application/octet-stream';
  res.setHeader('Content-Type', ct);
  res.setHeader('Cache-Control', 'public, max-age=86400');
  fs.createReadStream(p).pipe(res);
}

module.exports = { ensureIcon, serveIcon, probeSite, ICON_DIR };
