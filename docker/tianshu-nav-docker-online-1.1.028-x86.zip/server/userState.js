/**
 * @copyright EDIY工作室 (https://www.ediy.net)
 * @license 内部专有 / 见 LICENSE
 */
'use strict';











module.exports = {
  // 置 1：仅登录接口发现默认密码、管理员重置密码后调用
  setDefaultPwd(db, userId) {
    db.prepare('UPDATE users SET pwd_default = 1 WHERE id = ?').run(userId);
  },
  // 置 0：仅本人成功改密后调用
  clearDefaultPwd(db, userId) {
    db.prepare('UPDATE users SET pwd_default = 0 WHERE id = ?').run(userId);
  }
};
