# 天枢导航 · Docker 离线部署包 v1.1.029

镜像已内置（无需联网拉取）。

1. 解压本包；
2. 执行 `sh install.sh`（或 `docker compose up -d`）；
3. 浏览器打开 `http://<本机IP>:16080`。

- 数据在 `./data`，升级前请先备份该目录；
- 默认管理员账号 `admin`，首次登录会强制改密；
- 升级用 `sh update.sh`（等同「删容器 + 重新 install」，不动 `./data`）。

© EDIY工作室 · https://www.ediy.net
